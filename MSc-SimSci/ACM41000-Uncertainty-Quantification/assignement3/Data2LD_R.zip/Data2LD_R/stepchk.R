stepchk <- function(step, cvec, deltac, limwrd, ind, 
                    climit=rbind(matrix(50,1,npar),matrix(-50,1,npar)), 
                    active=1:npar, dbgwrd=FALSE) {
  #STEPCHK checks the step along a line for producing parameters within the
  #  limits specified by BOT and TOP
  #  LIMWRD    Logical variable permitting detection that parameter
  #               was on the boundary two steps <- a row
  
  #  Last modified 22 November 2015
  
  npar <- length(deltac)
  
  bot <- t(climit[1,])
  top <- t(climit[2,])
  
  # if (step is too small, return with flag ind <- 1
  
  if (step < 1e-7) {
    ind <- 1
    return(list(step = step, ind = ind, limwrd = limwrd))
  }
  
  #  ensure that step does not go beyond lower limit on parameters
  
  stepi   <- step*deltac
  if (any(stepi[active] < bot[active]-cvec[active])) {
    index   <- active[stepi[active] < bot[active]-cvec[active] & 
                      deltac[active] != 0]
    stepnew <- min((bot[index]-cvec[index])/deltac[index])
    if (dbgwrd) {
      cat("\nLower limit reached, old step, new step: ") 
      cat(step)
      cat(",  ")
      cat(stepnew)
      cat("\n")
    } 
    step <- stepnew
    #  check whether lower limit has been reached twice in a row
    if (limwrd[1]) {
      ind <- 1
      return(list(step = step, ind = ind, limwrd = limwrd))
    } else {
      limwrd[1] <- TRUE
    } #
  } else {
    limwrd[1] <- FALSE
  } 
  if (step < 1e-7) {
    ind <- 1
    return(list(step = step, ind = ind, limwrd = limwrd))
  } 
  
  #  ensure that step does not go beyond upper limit on parameters
  
  stepi <- step*deltac
  if (any(stepi[active] > top[active]-cvec[active])) {
    index   <- active[stepi[active] > top[active]-cvec[active] & 
                      deltac[active] != 0]
    stepnew <- min((top[index]-cvec[index])/deltac[index])
    if (dbgwrd) {
      cat("\nUpper limit reached, old step, new step: ") 
      cat(step)
      cat(",  ")
      cat(stepnew)
      cat("\n")
    } 
    step <- stepnew
    #  check whether upper limit has been reached twice in a row
    if (limwrd[2]) {
      ind <- 1
      return(list(step = step, ind = ind, limwrd = limwrd))
    } else {
      limwrd[2] <- TRUE
    } 
  } else {
      limwrd[2] <- FALSE
  } 
  return(list(step = step, ind = ind, limwrd = limwrd))
}