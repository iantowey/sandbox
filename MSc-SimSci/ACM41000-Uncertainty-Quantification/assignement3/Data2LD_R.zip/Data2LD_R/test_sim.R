setwd("/Users/michellecarey/Dropbox/Lsmooth_R")
dyn.load("loop.so")

x = c(1,1,1,1);
y = c(3,3,3,3);
r = c(1,1,1,1);
s = c(2,2,2,2);
w = rep(1,256);

source('~/Dropbox/Lsmooth_R/InnerLoop.R')
InnerLoop(x, y, r, s , w)