//
//  code.c
//  CLoop 
//
//  Last updated by Michelle Carey 16 July 2015
//
//

#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>

/* The gateway function */
SEXP loop(SEXP NLHS, SEXP PLHS,
                SEXP NRHS, SEXP PRHS, SEXP WVEC)
{
    int ncols1 = ncols(NLHS);
    int ncols2 = ncols(PLHS);
    int ncols3 = ncols(NRHS);
    int ncols4 = ncols(PRHS);
    
    int nrows1 = nrows(NLHS);

    PROTECT(NLHS =coerceVector(NLHS,REALSXP));
    PROTECT(PLHS =coerceVector(PLHS,REALSXP));
    PROTECT(NRHS =coerceVector(NRHS,REALSXP));
    PROTECT(PRHS =coerceVector(PRHS,REALSXP));
    PROTECT(WVEC =coerceVector(WVEC,REALSXP));
    
    /* variable declarations here */
    SEXP PTR;
    PROTECT(PTR =allocVector(REALSXP,ncols1*ncols2*ncols3*ncols4));
    
    for (int p = 0; p < (ncols1*ncols2*ncols3*ncols4); p++)
    {
      REAL(PTR)[p]=0;
    }
    
    for (int i = 0; i < ncols1; i++)
    {
        int mn1 = i*nrows1;
        
        for (int j = 0; j < ncols2; j++)
        {
            int mn2 = j*nrows1;
            
            for (int k = 0; k < ncols3; k++)
            {
                int mn3 = k*nrows1;
                
                for (int l = 0; l < ncols4; l++)
                {
                    int mn4 = l*nrows1;
                    
                    for (int m = 0; m < nrows1; m++)
                    {
                        double wv   = REAL(WVEC)[m];
                        double arri = REAL(NLHS)[m + mn1];
                        double arrj = REAL(PLHS)[m + mn2];
                        double arrk = REAL(NRHS)[m + mn3];
                        double arrl = REAL(PRHS)[m + mn4];
                        
                        int index = i*ncols4*ncols3*ncols2
                        + j*ncols4*ncols3
                        + k*ncols4
                        + l;
                        
                        REAL(PTR)[index] += arri*arrj*arrk*arrl*wv;
                        
                    }
                }
                
            }
        }
    }
    
    UNPROTECT(6);
    return PTR;
        
}
