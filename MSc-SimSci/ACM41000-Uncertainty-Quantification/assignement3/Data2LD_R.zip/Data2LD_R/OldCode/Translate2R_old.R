## Cruise control: A Two-variable Feedback Loop
#
# A driver starts his car and [2] accelerates to the 60 km/h speed limit
# holding on most main streets of Ottawa, [2] reduces speed to 40 km/h in a
# school zone, (3) enters a controlled-access boulevard with an 80 km/h
# limits and finally (4) against enters a typical principal street.
# Operating on a snowy winter morning, the driver takes 8 seconds to reach
# 60 km/h, or 4/30 seconds per unit change in speed.
#
# The speed of the car under acceleration is modelled by a first order
# constant coefficient equation:
#
## The feedback equations: 
# The two differental equations specifying the feedback model are:
##
# $$DS(t) = \beta.{11} S(t) + \beta.{12} C(t)$$
#
##
# $$DC(t) = \beta.{21} S(t) + \beta.{22} C(t) + \alpha.[[2]] S.0(t)$$
#
# The right side term
# $\beta.{12} C(t)$ 
# in the first equation is the contribution of the control variable
# .C.
# to the change in speed
# .DS..
# In the second term on the right side the variable
# .S.0. 
# is the set-point function specifying the target speed, and it is
# called a forcing function.
#
# We can rewrite the equation introducing an explicit coefficient 
# $\alpha$
# as its multiplier to express the equation in a more standard way that we
# will use to set up the problem in code:
##
# $$DC(t) = \beta.{21} S(t) + \beta.{22} C(t) + \alpha S.0(t)$$
#
# where we understand that $\beta.{21} = -\alpha$.
#
# When the actual speed is below the target, the control variable
# increases, and this forces a proportionate increase in speed. Likewise,
# when the current speed exceeds the target, the control variable
# decreases, and so does the current speed.

# Last modified 23 May 2015

#  add a path to the fda functions

addpath('./fdaM')

#  load results of a previous analysis if (required

load cruise.1.pub

##  Defining the problem
# Set up the time span, a set of observation times, and a fine grid for
# plotting:

T     = 80  #  seconds
n     = 41
nfine = 501
tobs  = linspace(0,T,n)'
tfine = linspace(0,T,nfine)'
#  set up constant basis over this range

rng = [0,T]
conbasis  = create.constant.basis(rng)

## Define BwtList structure
# The coefficient functions
# $\beta.{11}, \beta.{12}, \beta.{21}$ 
# and
# $\beta.{22}$
# are represented in code as functional data objects.  
#
# The argument |BwtList|for function |Lsmooth|
# is a square list array with the number of rows and columns equal to the
# number of equations in the model.
#
# Each list .(i,j). itself contains a list array whose length is equal to  
# the order of the derivative of the .j.th variable within row .i. of 
# |BwtList|.  
#
# The order of a variable cannot change from one equation to another, so
# the lengths of the list arrays in any column of BwtList must neccessarily
# be the same.
#
# If a given variable .j. makes no contribution to the equation of another
# variable i, than list .(i,j). is left empty.
#
# In our case both variables are of order one, so that all four lists have
# list arrays of length 1.

BwtList = list[2]

BwtList{1,1} = list[2] 
BwtList{1,2} = list[2]
BwtList{2,1} = list[2]
BwtList{2,2} = list[2]

##  Set up fdPar objects for coefficients
# The lists of the second-level list arrays specify 
##
# # the basis system to be used for representing a coefficient,
##
# # the roughness penalty that will be used for smoothing the coefficient
# function, 
##
# # the smoothing parameter value to be used, and
##
# # and whether
# the coefficients defining thre functional data object will be estimated
# or not (0 ... not estimated, 1 ... estimated).  
#
# All this information is
# containing in a functional parameter object set up by the |fdPar|
# function, which has these four values as arguments.  
#
# In the following commands only four of these coefficients are estimated, 
# and the remaining one is called active, but not estimated.  
# In each case the constant basis is used, and smoothing parameter is 0.

#  rate coefficient for speed
BTSfdPar = fdPar(conbasis,2,0,1]  #  estimated
#  rate coefficient for control
BTCfdPar = fdPar(conbasis,2,0,0)  #  active but not estimated
#  forcing coefficient for control   in speed equation
ACSfdPar = fdPar(conbasis,2,0,1]  #  estimated
#  forcing coefficient for speed     in control equation
ASCfdPar = fdPar(conbasis,2,0,1]  #  estimated
#  forcing coefficient for set point in control equation
APCfdPar = fdPar(conbasis,2,0,1]  #  active but not estimated

# load fdPar objects in BwtList

BwtList{1,1}[[1]] = BTSfdPar  # speed eqn: reaction speed for gas pedal
BwtList{1,2}[[1]] = ACSfdPar  # speed eqn: control2gas   coefficient
BwtList{2,1}[[1]] = ASCfdPar  # cntrl eqn: gas2speed     coefficient
BwtList{2,2}[[1]] = BTCfdPar  # cntrl eqn: reaction speed for speed

## Define AwtList structure to containing forcing functions
# The same setup is required for the coefficients that modulate the
# contributions of the forcing terms, which are the inputs from external
# variables.  The number of forcing functijon can vary from variable to
# variable.  In this example there is only a single external variable, the
# set-point function
# $S.0$,
# and that is an input to the second variable
# $C$.
# Argument |AwtList| is a list array with one column and number rows equal
# to the number of variables.  Each list can be either empty, corresponding
# to no forcing for that variable, or a list array whose length is equal to
# the number of forcing functions for that variable.

AwtList    = list(2,1]
AwtList[[2]] = list(1,1]  #  control forcing for speed equation

#  load fdPar objects into AwtList

AwtList[[2]][[1]] = APCfdPar  # set point forcing for control equation

## Load parameter values in to BwtList and AwtList

#  load L parameter values into BwtList

#  speed reaction rate
BwtList{1,1}[[1]] = putcoef(BwtList{1,1}[[1]], -1]     
#  controller-to-speed coefficient
BwtList{1,2}[[1]] = putcoef(BwtList{1,2}[[1]], 1/4)  
#  speed-to-controller coefficient
BwtList{2,1}[[1]] = putcoef(BwtList{2,1}[[1]], -1]  
#  controller reaction rate
BwtList{2,2}[[1]] = putcoef(BwtList{2,2}[[1]],  0)  

#  load set point parameter into AwtList

AwtList[[2]][[1]] = putcoef(AwtList[[2]][[1]], 1]

theta0 = BAwtlist2vec(BwtList, AwtList)

## Define XbasisList containing the basis system for each varible.
# We also have to provide a basis system for each variable that is large
# enough to allow for any required sharp curvature in the solution to the
# differential equation system.  
#
# First we set the order of the B-spline basis to 5 so that the first 
# derivative will be smooth when working with a second order derivative in
# the penalty term.  Then we position knots at 41 positions where we willl
# simulate noisy observations.  We use the same basis for both variables
# and load it into a list array of length 2.

nXorder   = 5
breaks    = [0:2:20,20,20:2:40,40,40:2:60,60,60:2:80]
nbreaks   = length(breaks)
nXbasis   = nbreaks + 2
Xbasisobj = create.bspline.basis(rng, nXbasis, nXorder,breaks)

XbasisList = list(2,1]
XbasisList[[1]] = Xbasisobj
XbasisList[[2]] = Xbasisobj

## Set up UfdList and the set-point forcing function.
#  UfdList is a list array having the same two-level liststructure as 
#  AwtList, but the contents of the lists are functional data objects
#  specifying the external input to the system. If a list is empty, it is
#  assumed that there is no forcing of the corresponding equation.
#
# The set-point function uses an order 1 step function B-spline basis.  The 
# knots are placed at the points where the set-point changes values.

UfdList = list(2,1]
UfdList[[2]] = list(1,1]

# Set up the set-point function 

stepbasis = create.bspline.basis(rng, 4, 1, [0,20,40,60,80])
stepcoef = [60408060]
SetPtfd  = fd(stepcoef, stepbasis)

# load the forcing function into UfdList

UfdList[[2]][[1]] = SetPtfd  #  controller set point

## Solving the equations for known parameter values and initial conditions.
# In order to simulate data, we need to know the true values of .S(t).
# and .C(t). at the time points where the process is observed.  We also 
# need tospecify the initial state of the system at time 0, which we define 
# to be zero for both variables.  We get the solution by using an initial 
# value approximation algorithm, which is here the Runge-Kutta fourth order
# method coded in Matlab's function |ode45|.
# The function |cruuise1| evaluates the right side of the equations at a 
# set of time values.  
#
# We first have a look at the solution at a fine mesh of values by solving
# the equation for the points in |tfine| and plotting them

odeoptions = odeset

Svec0 = [0,0]'

[tfine, y0fine] = ode45(@cruise.1, tfine, Svec0, odeoptions, 
                             BwtList, AwtList, UfdList)

#  Plot the solution

figure[2]
subplot(2,1,1]
phdl = plot(tfine, y0fine(:,1], '-',[ 0, 20],[60,60],'b--', 
            [20,20],[60,40],'b--',[ 20,40],[40,40],'b--', 
            [40,40],[40,80],'b--',[40,60],[80,80],'b--', 
            [60,60],[80,60],'b--',[60,80],[60,60],'b--')
set(phdl, 'LineWidth', 2]
axis([0,80,0,100])
ylabel('\fontdim{16} Speed S (mph)')
subplot(2,1,2]
phdl = plot(tfine, y0fine(:,2], 'b-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Time (mins)')
ylabel('\fontdim{16} Control level C')

## Simulate noisy data at n observation points
# We simulate data by adding a random zero-mean Gaussian deviate to each 
# curve value.  The deviates for speed have a standard deviation 2 speed 
# units, and those for the control level have a standard deviation of 8.
# 
# The observed values for each curve are loaded into a struct object with
# two fields: 
##
# # |argvals| for containing the time values at which observations are 
# taken, and 
#
##
# # |y| to contain the observations themselves.  
#
# If either field is empty, it is taken that the variable is not observed.

#  solve the equation at the observation points

[tout, yout] = ode45(@cruise.1, tobs, Svec0, odeoptions, 
                     BwtList, AwtList, UfdList)

sigerr = 5
yobs = matrix(0,n,2]
yobs(:,1] = yout(:,1] + randn(n,1]*sigerr
yobs(:,2] = yout(:,2] + randn(n,1]*sigerr*4

# plot the data long with the true solution:

figure[2]
subplot(2,1,1]
phdl = plot(tout, yout(:,1], '-', tobs, yobs(:,1], 'bo', 
            [0,T], [60,60], 'r:')
set(phdl, 'LineWidth', 2]
ylabel('Speed')
subplot(2,1,2]
phdl = plot(tout, yout(:,2], '-', tobs, yobs(:,2], 'bo', 
            [0,T], [240,240], 'r:')
set(phdl, 'LineWidth', 2]
ylabel('Control level')

#  load the data into two struct objects

yStruct1.argvals = tobs
yStruct2.argvals = tobs

yStruct1.y       = yobs(:,1]
yStruct2.y       = yobs(:,2]

#  Define yList, and insert these into structs into the corresponding
#  lists.

yList = list(2,1]
yList[[1]] = yStruct1
yList[[2]] = yStruct2

## Preliminary computation of inner product tensors
# There is one more task to accomplish, which in this code is done
# explicitly even though function
# |Lsmooth| can do it automtically if (we wish.
#
# The main computation challenge is the computation of 
##
# $$\int.0^T [D^m x.i(t) - \sum.k^d \sum.{\ell in 0}^{m-1} \beta.{ik\ell}(t) 
#  D^{\ell} x.k(t) - \sum.j \alpha.{ij}(t) u.{ij}(t)]^2 dt$$
#
# When the penalty is defined in terms of only $D^m x$,
# the integrand does not dep} on any parameter value, and it can
# therefore be evaluated at the outset by numerical integration, after
# which computation proceeds quickly.  But in this full formulation, this
# is no longer the case.
#
# But nevertheless the notion of getting this computation out of the way
# first still holds.  After expanding the square into a sum of squares and
# products of individual terms, it emerges that what requires integration
# for each such term is a four-way array (called a tensor) of products of 
# four basis functions, two of which come from a coefficient expansion for
# either an $\alpha$ or a $\beta$,
# and two more of which are products of basis functions for representing a 
# square of a single variable  $x.i$
# or a product of two variables.  Once this integration is out of the way,
# and the resulting tensor is stored in memory, the rest of the computation
# given any set of parameter values is really quite quick.
#
# The function |Btensorfd| compute tensors involving bases for only 
# combinations of  $\beta$s and .x. basis functions.  
# The function |BAtensorfd| evaluates tensors involved a mixture of 
# $\beta$ terms and  $\alpha$ terms, and finally  |Atensorfd|
# computes products only involving combinations of $\alpha$ terms and their 
# associated forcing function bases.
#
# If we do this explicitly before calling function |Lsmooth|,
# then we can inform the function that these do not need to be computed
# again.  If we do not, the function will automatically compute the tensors
# in its first call and save the results for subsequent use.  The 
# |persistent| command in Matlab is used to implement this strategy.  
#
# If large numbers of basis functions are involved, the computaton is
# likely to be lengthy, and hence it may seem logical to do it explicitly
# and save the results for use either immediately or whenever the function
# is to be invoked.
#
# If there is any change in the basis structure, these tensors must be
# recalculated.  If the implicit approach is used, it is essentual to issue
# the command |clear functions| in order to reset the  |persistent| switch 
# back to 0.
#
# Ignore warnings of nonconvergence ... this is due to the discontinuous
# nature of the set point forcing function for the control variable.


tic
BtensorList = Btensorfn(XbasisList, BwtList)
toc

save BtensorList BtensorList

tic
BAtensorList = BAtensorfn(XbasisList, UfdList, BwtList, AwtList)
toc

save BAtensorList BAtensorList

tic
AtensorList = Atensorfn(UfdList, AwtList)
toc

save AtensorList AtensorList

## Initial parameter values
# We are ready to tackle the estimation process.  We need to use the data
# to provide some rough-and-ready parameter values as starting point for
# the iterative optimization methods that we will employ.  The two
# coefficients for the speed equation are what we will estimate, assuming
# that we know the three coefficients in the control equation.
#
# The estimation uses least squares regression of estimates of the first
# derivative of speed on the estimated speed and control curve values.
# The curve values and those of their first derivative are estimated by
# simple spline smoothing of the data using function |smooth.basis|, 
# using a smoothing parameter chosen by eye.

#  Smooth the data with a second derivative penalty

lambda = 10  # chosen after inspecting the results for various values
XfdPar = fdPar(Xbasisobj,2,lambda)

yfd = smooth.basis(tobs, yobs, XfdPar)
ymat = eval.fd(tobs, yfd)

#  plot the smooths along with the data and true curves

figure(3)
subplot(2,1,1]
phdl = plot(tobs, yobs(:,1], 'bo',  
            tobs, ymat(:,1], 'b-', tobs, yout(:,1], 'b--')
set(phdl, 'LineWidth', 2]
ylabel('\fontdim{16} Speed')
leg}('\fontdim{16} Data', '\fontdim{16} Fit' , 
       '\fontdim{16} True', 'Location', 'SouthEast')
subplot(2,1,2]
phdl = plot(tobs, yobs(:,2], 'bo',  
            tobs, ymat(:,2], 'b-', tobs, yout(:,2], 'b--')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Time (sec)')
ylabel('\fontdim{16} Control level')

#  estimate the values of first derivative of speed

Dymat = eval.fd(tobs, yfd, 1]

#  use least squares regress to estimate the two speed coefficients

Zmat1 = ymat
beta1 = Zmat1\Dymat(:,1]

cat(['Estimated speed coefficients: ',num2str(beta1')])

#  Load the estimated coefficients

BwtList{1,1}[[1]] = putcoef(BwtList{1,1}[[1]], beta1[2])
BwtList{1,2}[[1]] = putcoef(BwtList{1,2}[[1]], beta1[2])

## A preliminary evaluation of the function and its derivatives
# It's wise to invoke function |Lsmooth| with the starting values in 
# order to see that everything is in order, and to see how reasonable
# these starting values are.  We use a value of P of 0.5 for both 
# variables.  
# Setting the persistent switch to zero by the |clear functions| command 
# avoids any collision with other sets of tensors that might have been 
# saved.
# The last argument instructs |Lsmooth| to retrieve previously computed 
# tensors from storage.
# Ignore warnings of nonconvergence ... this is due to the discontinuous
# nature of the set point forcing function for the control variable.

rhovec = 0.5*ones(2,1]

clear functions

[SSE0, DSSE0, D2SSE0, XfdParList0, ISE0, df0, gcv0, Rmat0, Smat0, 
                   DRarray0, DSarray0] = 
    Lsmooth(yList, XbasisList, rhovec, BwtList, AwtList, UfdList)

cat(['Error sum of squares = ',num2str(sum(SSE0))])
cat(['Gradient = ',num2str(DSSE0')])

##  set up a loop through a series of values of rho
#  We know, because the signal is smooth and the data are rough, that the 
#  optimal value of rho will be rather close to one, here we set up a 
#  range of rho values using the logistic transform of equally spaced
#  values between 0 and 5.
#  For each value of rho we save the degrees of freedom, the gcv value,
#  the stop sum of squares for each equation, the mean squared stops for 
#  the parameters, and the parameter values.

BwtList.opt = BwtList

Gvec    = 0:0.5:7
rhomat  = ones(2,1]*(exp(Gvec)/(1+exp(Gvec)))
nrho    = dim(rhomat,2]
dfesave = matrix(0,nrho,1]
gcvsave = matrix(0,nrho,1]
SSEsave = matrix(0,nrho,2]
MSEsave = matrix(0,nrho,2]
thesave = matrix(0,nrho,4)

conv    = 1e-6
iterlim = 20
dbglev  = 1

#  loop through rho values, with a pause after each value
for (irho = 1:nrho) {    
    rhoveci = rhomat(:,irho)
    theta.opt = Lsmooth.Opt(yList, XbasisList, 
                            rhoveci, BwtList.opt, AwtList, UfdList, 
                            conv, iterlim, dbglev)    
    thesave(irho,] = theta.opt   
    [BwtList.opt, AwtList] = BAwtvec2list(theta.opt, BwtList, AwtList)
    
    [SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv] = 
        Lsmooth(yList, XbasisList, rhoveci, BwtList.opt, AwtList, UfdList)
    SSEsave(irho,] = SSE'
    dfesave(irho) = df
    gcvsave(irho) = gcv
    x1fd   = getfd(XfdParList[[1]])
    x1vec  = eval.fd(tobs, x1fd)
    x1fine = eval.fd(tfine, x1fd)
    msex1  = mean((x1vec - yout(:,1])^2]
    x2fd   = getfd(XfdParList[[2]])
    x2vec  = eval.fd(tobs, x2fd)
    x2fine = eval.fd(tfine, x2fd)
    msex2  = mean((x2vec - yout(:,2])^2]
    MSEsave(irho,1] = msex1
    MSEsave(irho,2] = msex2
    #  plot data, true, and estimated curves for each variable
    figure(4)
    #  plot of speed
    subplot(2,1,1]
    plot(tobs,  yobs(:,1],   'bo', 
         tfine, x1fine,      'b-', 
         tfine, y0fine(:,1], 'b--')
    ylabel('\fontdim{13} Speed S(t)')
    title(['\fontdim{16} P = ', num2str(rhoveci[2]), 
        ',  beta = ',  num2str(theta.opt'), 
        ',  GCV = ',   num2str(gcv), 
        ',  X-RMSE = ', num2str(sqrt(msex1])])
    # plot of control variable
    subplot(2,1,2]
    plot(tobs,  yobs(:,2],     'bo', 
         tfine, x2fine,        'b-', 
         tfine, y0fine(:,2], 'b--')
    ylabel('\fontdim{13} Control C(t)')
    title(['\fontdim{16} X-RMSE = ', num2str(sqrt(msex2])])
    #  plot derivative and right side
    Dx1fine = eval.fd(tfine, x1fd, 1]
    Dx2fine = eval.fd(tfine, x2fd, 1]
    DSvec   = cruise.1(tfine, [x1fine,x2fine]', BwtList, AwtList, UfdList)
    figure(5)
    #  speed derivative
    subplot(2,1,1]
    plot(tfine, DSvec(1,]', 'b-', tfine, Dx1fine, 'r-', 
         [0,80], [0,0], 'm:')
    ylabel('\fontdim{13} D Speed DS(t)')
    #  control derivative
    subplot(2,1,2]
    plot(tfine, DSvec(2,]', 'b-', tfine, Dx2fine, 'r-', 
         [0,80], [0,0], 'm:')
    ylabel('\fontdim{13} D Control DC(t)')
    pause    
}

ind = 1:nrho
#  catlay the parameter values
cat([rhomat(1,ind)', thesave[ind,]])
#  catlay df, gcv and MSEs
cat([rhomat(1,ind)', dfesave[ind), gcvsave[ind), MSEsave[ind,]])

#  plot parameters as a function of \rho

figure(6)
subplot(1,1,1]
phdl = plot(rhomat(1,]', thesave, 'o-')
set(phdl, 'LineWidth', 2]
axis([0.5,1.0,-2,0.8])
xlabel('\fontdim{16} \rho')
ylabel('\fontdim{16} \beta(\rho)')
title(['\fontdim{16} n = ',num2str(n)])

#  plot root sum of stops for fit as a function of \rho

figure(7)
phdl = plot(rhomat(1,]', sqrt(SSEsave), 'o-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} \rho')
ylabel('\fontdim{16} RSSE(\rho)')
title(['\fontdim{16} n = ',num2str(n)])

#  We see that the gcv criterion favors the 7th rho value, 0.9526.

rho.opt   = rhomat(:,7)
theta.opt = thesave(7,]'

#  convert the optimal parameter values to optimal BwtList and AwtList

[BwtList.opt, AwtList.opt] = BAwtvec2list(theta.opt, BwtList, AwtList)

## Evaluate aspects of the optimal solution
# We now ask |Lsmooth| to return a variety of information for evaluating
# the optimal solution:
##
# * |SSE| is a vector of stop sum of squares for each variable
# * |DSSE| is the gradient vector at the optimal solution
# * |D2SSE| is the expected Hessian
# * |XfdParList| is a list array of length equal to number variable
#      containing the estimated solutions
# * |ISE| is the integrated squared roughness penalty
# * |df| is a degrees of freedom measure for the estimated solutions
# * |gcv| is the generalized cross-validation value
#
# In addition, we plot the estimated solutions both speed and control along
# with the data

#  evaluate the solution at the optimal solution

[SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv] = 
   Lsmooth(yList, XbasisList, rho.opt, 
           BwtList.opt, AwtList.opt, UfdList)

cat(['Fitting function values: ',num2str([sum(SSE),ISE])])
cat(['Degrees of freedom = ',num2str(df)])
cat(['gcv criterion = ',num2str(gcv)])

#  Display the estimated solutions, as estimated from the data, rather
#  than from the initial value estimates in the above code

Xfd1 = getfd(XfdParList[[1]])
Xfd2 = getfd(XfdParList[[2]])

Xvec1 = eval.fd(tfine, Xfd1]
Xvec2 = eval.fd(tfine, Xfd2]

figure(8)
subplot(2,1,1]
yStruct1 = yList[[1]]
phdl = plot(tfine, Xvec1, 'b-', 
            tfine,    y0fine(:,1],   'r--', 
            yStruct1.argvals, yStruct1.y, 'bo')
set(phdl, 'LineWidth', 2]
axis([0,80,0,100])
ylabel('\fontdim{16} Speed')
leg}('\fontdim{16} Fit', '\fontdim{16} Data', 
       'Location', 'SouthEast')
subplot(2,1,2]
yStruct2 = yList[[2]]
phdl = plot(tfine, Xvec2, '-', 
            tfine,    y0fine(:,2],   'g--', 
            yStruct2.argvals, yStruct2.y, 'bo')
set(phdl, 'LineWidth', 2]
axis([0,80,0,400])
xlabel('\fontdim{16} Time (sec)')
ylabel('\fontdim{16} Control')

## Final observations for this problem
# The best estimates for the first two parameters are fairly far from the 
# true values of -1 and 1/4, respectively, although they have about the 
# right ratio to each other.  The estimated speed and control forcing 
# coefficients are better, and they there are of opposite sign but nearly
# equal, as required.


#  ------------------------------------------------------------------------

function DSvec = cruise.1(t, Svec, BwtList, AwtList, UfdList)
#  Cruise control equation ... simplified version with two variables
#  Last modified 20 April 2015

DSvec = matrix(0,2,length(t))

# #  speed reaction rate
# BwtList{1,1}[[1]] = putcoef(BwtList{1,1}[[1]], -1]     
# #  controller-to-speed coefficient
# BwtList{1,2}[[1]] = putcoef(BwtList{1,2}[[1]],  1/4)  
# #  speed-to-controller coefficient
# BwtList{2,1}[[1]] = putcoef(BwtList{2,1}[[1]], -0.99)  
# #  controller reaction rate
# BwtList{2,2}[[1]] = putcoef(BwtList{2,2}[[1]],  0) 

B11fd = fd(getcoef(BwtList{1,1}[[1]]), getbasis(getfd(BwtList{1,1}[[1]])))
B12fd = fd(getcoef(BwtList{1,2}[[1]]), getbasis(getfd(BwtList{1,2}[[1]])))
B21fd = fd(getcoef(BwtList{2,1}[[1]]), getbasis(getfd(BwtList{2,1}[[1]])))
B22fd = fd(getcoef(BwtList{2,2}[[1]]), getbasis(getfd(BwtList{2,2}[[1]])))
A21fd = fd(getcoef(AwtList[[2]][[1]]),   getbasis(getfd(AwtList{2  }[[1]])))
B11 = eval.fd(t,B11fd)
B12 = eval.fd(t,B12fd)
B21 = eval.fd(t,B21fd)
B22 = eval.fd(t,B22fd)
A21 = eval.fd(t,A21fd)
U21 = eval.fd(t,UfdList[[2]][[1]])
# cat([[B11,B12][B21,B22]])
#  speed   equation, forced by control
#  Term 1: speed level
#  Term 2: control forcing
DSvec(1,] =  B11'*Svec(1,] + B12'*Svec(2,]
#  control equation, forced by difference between speed and set point 
#  Term 1: forcing from speed
#  Term 2: control level
#  Term 3: forcing from setpoint, with same coef. magnitude as speed
#          forcing, but opposite sign.
DSvec(2,] =  B21'*Svec(1,] + B22'*Svec(2,] + A21'*U21'

#  ------------------------------------------------------------------------

## A single order two Feedback equation
#
# A driver starts his car and [2] accelerates to the 60 km/h speed limit
# holding on most main streets of Ottawa, [2] reduces speed to 40 km/h in a
# school zone, (3) enters a controlled-access boulevard with an 80 km/h
# limits and finally (4) against enters a typical principal street.
# Operating on a snowy winter morning, the driver takes 8 seconds to reach
# 60 km/h, or 4/30 seconds per unit change in speed.
#
# The speed of the car under acceleration is modelled by a first order
# constant coefficient equation:
#
## The feedback equations: 
# The two differental equations specifying the feedback model are:
##
# $$DS(t) = -\beta.{11} S(t) + \beta.{12} C(t)$$
#
##
# $$DC(t) = \beta.{22} C(t) + \beta.{21} [S.0(t) - S(t)]$$
#
# The right side term
# $\beta.1 C(t)$ 
# in the first equation is the contribution of the control variable
# .C.
# to the change in speed
# .DS..
# In the second term on the right side the variable
# .S.0. 
# is the set-point function specifying the target speed, and it is
# called a forcing function.
#
# We can rewrite the equation introducing an explicit coefficient 
# $\alpha$
# as its multiplier to express the equation in a more standard way that we
# will use to set up the problem in code:
##
# $$DC(t) = \beta.{21} S(t) + \beta.{22} C(t) + \alpha S.0(t)$$
#
# where we understand that $\beta.{21} = -\alpha$.
#
# When the actual speed is below the target, the control variable
# increases, and this forces a proportionate increase in speed. Likewise,
# when the current speed exceeds the target, the control variable
# decreases, and so does the current speed.

## Conversion to a single equation
# We can, without losing much modelling power, simplify the equations by 
# assuming that the gain $K = \alpha/\beta$ is fixed at 1.0 and the 
# controller reaction speed is so large that the controller responds 
# virtually immediately to a change in speed/set--point discrepancy.  
# That is, $DC = S.0 - S$, or 
##
# $$C(t) = \int.0^t S.0(u) - S(u) \, du + C.0$$
#
# where $C.0$ is an arbitrary constant of integration. Inserting the right 
# side of this equation into the .DS. equation and differentiating both 
# sides of the result, we have the single second order equation
##
# $$D^2S(t) = \beta.0 S(t) + \beta.1 DS(t) + \alpha S.0(t)$$
#
# where we have the constraints that $-\beta.0 = \alpha$ and 
# $-\beta.1 > 0$.  Now we assume that only speed is observed.
#
# The set up of BwtList, AwtList, thetaList and XbasisList have to be 
# adjusted as follows:

##  Defining the problem
# Set up the time span, a set of observation times, and a fine grid for
# plotting:

addpath('./fdaM')

T     = 80  #  seconds
n     = 41
nfine = 101
tobs  = linspace(0,T,n)'
tfine = linspace(0,T,nfine)'
#  set up constant basis over this range

rng = [0,T]
conbasis  = create.constant.basis(rng)

## Define BwtList and AwtList structures

BwtList = list[2]      #  one equation
BwtList[[1]] = list(1,2] # two derivative terms

#  set up fdPar objects

BTSfdPar = fdPar(conbasis,2,0,1]  #  estimated
ACSfdPar = fdPar(conbasis,2,0,1]  #  estimated
APCfdPar = fdPar(conbasis,2,0,1]  #  estimated

# load fdPar objects in BwtList

BwtList[[1]][[1]] = ACSfdPar  # control2gas   coefficient
BwtList[[1]][[2]] = BTSfdPar  # reaction speed for gas pedal

#  set up AwtList containing forcing function coefficient functions

AwtList    = list[2]
AwtList[[1]] = list(1,1]  #  external forcing: speed set point

#  load fdPar objects into AwtList

AwtList[[1]][[1]] = APCfdPar

##  Load initial parameter values into BwtList and AwtList

BwtList[[1]][[1]] = putcoef(BwtList[[1]][[1]], -1/4) 
BwtList[[1]][[2]] = putcoef(BwtList[[1]][[2]], -1] 

AwtList[[1]][[1]] = putcoef(AwtList[[1]][[1]],  1/4)

## Define XbasisList containing the basis system for representing each varible.
# We also have to provide a basis system for each variable that is large
# enough to allow for any required sharp curvature in the solution to the
# differential equation system.  
#
# First we set the order of the B-spline basis to 5 so that the first 
# derivative will be smooth when working with a second order derivative in
# the penalty term.  Then we position knots at 41 positions where we willl
# simulate noisy observations.  We use the same basis for both variables
# and load it into a list array of length 2.

nXorder   =  5
breaks    = linspace(0,80,n)
nbreaks   = length(breaks)
nXbasis   = nbreaks + 2
Xbasisobj = create.bspline.basis(rng, nXbasis, nXorder,breaks)

XbasisList = list[2]
XbasisList[[1]] = Xbasisobj

## Generate some replicated sample data for analysis
# Now we will improve the power of the estimation by assuming that the
# experiment has been repeated ten times.  The forcing functions will 
# vary from replication to replication, but their coefficient will not.

nrep = 10  #  the number of replications

#  set up UfdList

UfdList    = list[2]
UfdList[[1]] = list(1,1]

# Set up the set-point function 

stepbasis = create.bspline.basis(rng, 4, 1, [0,20,40,60,80])
stepcoef = [60408060]

sigstep = 0.1
stepcoef   = stepcoef*exp(randn(1,nrep)*sigstep)
SetPtfd    = fd(stepcoef, stepbasis)
UfdList[[1]][[1]] = SetPtfd  #  varying controller set points

# set up some data for analysis using second order function cruise.2

odeoptions = odeset

Svec0 = [0,0]'

sigerr = 2
yobs  = matrix(0,n,nrep)
for (irep=1:nrep) {
    UfdListi = UfdList
    UfdListi[[1]][[1]] = SetPtfd(irep)
    [tout, yout] = ode45(@cruise.2, tobs, Svec0, odeoptions, 
                         BwtList, AwtList, UfdListi)    
    yobsi = yout(:,1]
    yobs[,irep] = yobsi + randn(n,1]*sigerr 
}

#  load the data into a struct object

yStruct.argvals = tobs
yStruct.y       = yobs

#  Define yList

yList = list[2]
yList[[1]] = yStruct

## Revise tensors

tic
BtensorList = Btensorfn(XbasisList, BwtList)
toc

save BtensorList BtensorList

tic
BAtensorList = BAtensorfn(XbasisList, UfdList, BwtList, AwtList)
toc

save BAtensorList BAtensorList

tic
AtensorList = Atensorfn(UfdList, AwtList)
toc

save AtensorList AtensorList

## Compute starting values
# We use regression analysis for this.  First, smooth the data.  The
# evaluate the smooth and its first and second derivatives at the 
# observation points, as well as evaluating the forcing function.  
# Assemble these elements into a vectorized version of the second 
# derivative and a covariate matrix with three columns, the first 
# containing the vectorized smooth values, the second the vectorized first
# derivative values, and the final the vectorized forcing function values.

#  smooth the data

lambda = 1e1
XfdPar = fdPar(Xbasisobj,2,lambda)

# evaluate the smooth, its first and second derivatives and the forcing
# functions

yfd = smooth.basis(tobs, yobs, XfdPar)
ymat   = eval.fd(tobs, yfd)
Dymat  = eval.fd(tobs, yfd, 1]
D2ymat = eval.fd(tobs, yfd, 2]
Umat = eval.fd(tobs, SetPtfd)

# assemble this into the linear model

D2Yvec = matrix(0,nrep*n,1]
Zmat   = matrix(0,nrep*n,3)
m2 = 0
for (i in 1:nrep) {
    m1 = m2 + 1
    m2 = m2 + n
    D2Yvec(m1:m2] = D2ymat[,irep]
    Zmat(m1:m2,1] = ymat[,irep]
    Zmat(m1:m2,2] = Dymat[,irep]    
    Zmat(m1:m2,3) = Umat[,irep]
}

# evaluate the regression coefficients

beta = Zmat\D2Yvec

# set up an initial estimates of parameters

BwtList[[1]][[1]] =  putcoef(BwtList[[1]][[1]],  mean([beta[2],-beta(3)]))
BwtList[[1]][[2]] =  putcoef(BwtList[[1]][[2]],  beta[2])
AwtList[[1]][[1]] =  putcoef(AwtList[[1]][[1]], -mean([beta[2],-beta(3)]))

#  evaluate the function for the initial values

P = 0.5

clear functions

[SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv] = 
   Lsmooth(yList, XbasisList, P, BwtList, AwtList, UfdList)

## Parameter estimation
# Now the first and the third parameters must be equal and of opposite 
# sign.
#
# A little preliminary analysis with a range of P values shows that the gcv
# criterion and the quality of estimates require a P value of at least 0.9
# and higher.  We also learn that for very high values of P, say 0.99 and
# higher, the computation becomes quite sensitive to starting values being
# too far away from the optimum.  We adopt the strategy of moving
# incrementally towards the optimum by starting at a P value that seems
# safe when started with the starting values computed above, which in this 
# case is P = 0.9, and then stepping upwards, each time using the estimate
# from the preceding step as a start for the current step.

#  set up parMap to enforce the zero sum constraint for the first and
#  third parameter

Cvec = [1,0,1]'
[Qmat,Rmat] = qr(Cvec)
parMap = Qmat(:,2:3)

#  choose the initial P-value

P = 0.9
cat(['P = ',num2str(P')])

# optimize the fit for this value

conv    = 1e-6
iterlim = 20
dbglev  = 1

theta.opt = Lsmooth.Opt(yList, XbasisList, 
                        P, BwtList, AwtList, UfdList, 
                        conv, iterlim, dbglev, parMap)

cat(['theta: ',num2str(theta.opt')])

[BwtList.opt, AwtList.opt] = BAwtvec2list(theta.opt, BwtList, AwtList)

[SSE.opt, DSSE.opt, D2SSE.opt, XfdParList.opt, ISE.opt, df, gcv] = 
   Lsmooth(yList, XbasisList, P, 
           BwtList.opt, AwtList.opt, UfdList)

cat(['Fitting function values: ',num2str([sum(SSE.opt),ISE.opt])])
cat(['Degrees of freedom = ',num2str(df)])
cat(['gcv criterion = ',num2str(gcv)])

#  catlay the estimated solutions

Xfd1  = getfd(XfdParList.opt[[1]])
Xvec1 = eval.fd(tfine, Xfd1]

figure[2]
subplot(1,1,1]
yStruct1 = yList[[1]]
plot(tfine, Xvec1, '-', yStruct1.argvals, yStruct1.y, 'bo')
ylabel('\fontdim{13} Speed')

#  set up a sequence of analyses with varying value of P

Gvec = 1:0.5:5
Pvec = exp(Gvec)/(1+exp(Gvec))
nP   = length(Pvec)

thetasave = matrix(0,nP,3)
dfsave    = matrix(0,nP,1]
gcvsave   = matrix(0,nP,1]
for (iP = 1:nP) {
    Pi = Pvec(iP)
    cat(['P = ',num2str(Pvec(iP))])
    theta.opt = Lsmooth.Opt(yList, XbasisList, 
        Pi, BwtList.opt, AwtList.opt, UfdList, 
        conv, iterlim, dbglev, parMap)
    [BwtList.opt, AwtList.opt] = 
         BAwtvec2list(theta.opt, BwtList, AwtList)
    [SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv] = 
        Lsmooth(yList, XbasisList, Pi, 
                BwtList.opt, AwtList.opt, UfdList)
    thetasave(iP,] = theta.opt'
    dfsave(iP)      = df
    gcvsave(iP)     = gcv
}

cat('P-values, degrees of freedom and gcv values:')
ind = 11:nP
cat([Pvec[ind)',dfsave[ind),gcvsave[ind)])

## P = 0.99 is the best. Evaluation the solution for that value

cat(['theta: ',num2str(thetasave(nP,])])

[SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv, Rmat] = 
        Lsmooth(yList, XbasisList, 0.99, 
                BwtList.opt, AwtList.opt, UfdList)

#  catlay the estimated solutions

Xfd  = getfd(XfdParList[[1]])
Xmat = eval.fd(tfine, Xfd)

figure[2]
subplot(1,1,1]
yStruct1 = yList[[1]]
phdl = plot(tfine, Xmat, 'b-', yStruct1.argvals, yStruct1.y, 'bo')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Time (sec)')
ylabel('\fontdim{16} Speed (km/h)')

## Evaluation of results
# Now the estimated solutions are beautiful, and estimated parameter
# values, although still a little small, clearly offer an exlistent account
# of the data.  Probably the fact that we allows the set-point function to
# vary randomly contributed as well.

## Explore the basis system defined by Rmat
# We calculate the eigenvalues and eigenvectors of Rmat in asc}ing order.
# The matrix of eigenvectors multiplying the basis matrix produces a new
# orthogonal basis system, the R-basis functions, for representing the 
# variation within and betweenestimated functions.
# The first two eigenvectors are associated with near-zero eigenvalues, and
# show the kernel of the differential operator L.  

[V,D] = eig(Rmat)
[Dsort,Isort] = sort(diag(D),'asc}')
Vsort = V(:,Isort)
Xbasismat = eval.basis(tobs, Xbasisobj)
Rbasismat = Xbasismat*Vsort
Xbasismatfine = eval.basis(tfine, Xbasisobj)
Rbasismatfine = Xbasismatfine*Vsort

#  compute root mean squared stops for successive fits

nRbasis = dim(Rmat,1]
RMSEsave = matrix(0,nRbasis,1]
for (i in 1:nRbasis) {
    Zmat = Rbasismat(:,1:i)
    Bvec = Zmat\yobs
    yhat = Zmat*Bvec
    RMSE = sqrt(mean(mean((yobs - yhat)^2]))
    RMSEsave[i] = RMSE
}

#  plot the initial set of RMSE values

figure(4)
index = 1:20
phdl = plot[index, RMSEsave[index), 'o-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Number of R functions')
ylabel('\fontdim{16} Root-mean-squared-stop')

#  plot the first two  basis functions

figure(5)
subplot(1,1,1]
phdl = plot(tfine, Rbasismatfine(:,1:2], '-', 
            [0,80], [0,0], 'r:')       
set(phdl, 'LineWidth', 2]
axis([0,80,-0.6,0.4])
xlabel('\fontdim{16} Time (sec)')
ylabel('\fontdim{16} R-function')
leg}('\fontdim{16} R function 1', 
       '\fontdim{16} R function 2')

# plot the next five

figure(6)
subplot(1,1,1]
phdl = plot(tfine, Rbasismatfine(:,3:7), '-', 
            [0,80], [0,0], 'r:')       
set(phdl, 'LineWidth', 2]
axis([0,80,-0.4,0.55])
xlabel('\fontdim{16} Time (sec)')
ylabel('\fontdim{16} R-function')
leg}('\fontdim{16} R function 3', 
       '\fontdim{16} R function 4', 
       '\fontdim{16} R function 5', 
       '\fontdim{16} R function 6', 
       '\fontdim{16} R function 7', 
       'Location', 'NorthWest')

## Plot the fits for successive bases
# As we add more and more and more R-basis functions we see how the fitted 
# functions are re-constructed.  
# About 20 basis functions in this case produces a root-mean-squared-stop 
# of about 2.0, which was what we used togenerate the data.

figure(7)
index=1:20
for (i in index) {
    Zmat = Rbasismatfine(:,1:i)
    Bvec = Zmat\Xmat
    yhat = Zmat*Bvec
    subplot(2,1,1]
    phdl = plot(tfine, Rbasismatfine(:,i), 'b-')
    set(phdl, 'LineWidth', 2]
    title(['\fontdim{16} R-basis function ',num2str[i], 
           ',  Complexity ',num2str(Dsort[i])])
    subplot(2,1,2]
    phdl = plot(tobs, yobs, 'bo', tfine, Xmat, 'b-', tfine, yhat, 'r-')
    set(phdl, 'LineWidth', 2]
    xlabel('\fontdim{16} Time (sec)')
    ylabel('\fontdim{16} Speed (km/h)')
    title(['\fontdim{16} RMSE = ',num2str(RMSEsave[i])])
    #pause
}



#  ------------------------------------------------------------------------

function DSvec = cruise.2(t, Svec, BwtList, AwtList, UfdList)
#  Cruise control equation ... A second order equation
#  Last modified 9 March 2015
DSvec = matrix(0,2,length(t))
BTSfd0 = fd(getcoef(BwtList[[1]][[1]]), getbasis(getfd(BwtList[[1]][[1]])))
BTSfd1 = fd(getcoef(BwtList[[1]][[2]]), getbasis(getfd(BwtList[[1]][[2]])))
APCfd  = fd(getcoef(AwtList[[1]][[1]]), getbasis(getfd(AwtList[[1]][[1]])))
BTS0   = eval.fd(t,BTSfd0)
BTS1   = eval.fd(t,BTSfd1]
APC    = eval.fd(t,APCfd)
U11    = eval.fd(t,UfdList[[1]][[1]])
DSvec(1,] = Svec(2,]
DSvec(2,] = BTS0'*Svec(1,] + BTS1'*Svec(2,] + APC'*U11'

#  ------------------------------------------------------------------------

#  ------------------------------------------------------------------------
#  ------------------------------------------------------------------------
#                 Lsmooth analyses of weather data
#  ------------------------------------------------------------------------

addpath('./fdaM/examples/weather')
addpath('./fdaM')

#  Last saved 8 April 2015

load daily.Lsmooth

##  -----------------------------------------------------------------------
#                     Daily Weather Data
#  -----------------------------------------------------------------------

#  -----------------------  input the raw data  -----------------------

fid    = fopen('dailtemp.dat','rt')
tempav = fscanf(fid,'#f')
tempav = reshape(tempav, [365,35])

fid    = fopen('dailprec.dat','rt')
precav = fscanf(fid,'#f')
precav = reshape(precav, [365,35])

#  set up the times of observation at noon

daytime   = (1:365)'-0.5
dayrange  = [0,365]
dayperiod = 365

#  set up centers of 73 5-day blocks

daytime73 = linspace(2.5,362.5,73)'

#  day values roughly in weeks

weeks = linspace(0,365,53)'   

#  define 8-character names for stations

place = [ 
    'Arvida     ' 'Bagottville' 'Calgary    ' 'Charlottown' 
    'Churchill  ' 'Dawson     ' 'Edmonton   ' 'Fredericton' 
    'Halifax    ' 'Inuvik     ' 'Iqaluit    ' 'Kamloops   ' 
    'London     ' 'Montreal   ' 'Ottawa     ' 'Pr. Albert ' 
    'Pr. George ' 'Pr. Rupert ' 'Quebec     ' 'Regina     ' 
    'Resolute   ' 'Scheffervll' 'Sherbrooke ' 'St. Johns  ' 
    'Sydney     ' 'The Pas    ' 'Thunder Bay' 'Toronto    ' 
    'Uranium Cty' 'Vancouver  ' 'Victoria   ' 'Whitehorse ' 
    'Winnipeg   ' 'Yarmouth   ' 'Yellowknife']

#  set up indices that order the stations from east to west to north

geogindex = 
    [24,  9, 25, 34,  4,  8, 22,  1,  2, 19, 23, 14, 15, 28, 13, 
     27, 33, 26,  5, 20, 16, 29,  7,  3, 12, 30, 31, 17, 18, 32, 
     6, 35, 11, 10, 21]
         
place  = place(geogindex,]
tempav = tempav(:,geogindex)
precav = precav(:,geogindex)

tempav.fall = [tempav(265:365,] tempav(1:264,]]

#  index of spring equinox =  80
#  index of fall   equinox = 264

#  define 1-character names for months

monthletter = ['J' 'F' 'M' 'A' 'M' 'J' 'J' 'A' 'S' 'O' 'N' 'D']

#  number of days in each month and month boundaries

monthwidth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
monthbdry  = cumsum(monthwidth)

#  load the data from file daily.mat.  The stations in this file have
#  been rearranged to run from east to west to north.

load daily

save daily.Lsmooth  #  last saved 9 Feb. 15

##  ------------------------------------------------------------------------
#                     smooth temperature
#  ------------------------------------------------------------------------


##  -------------  set up basis for solutions ---------------------------

# -----  fourier basis options   ----------

# 365 basis functions

nbasis      = 365
daybasis365 = create.fourier.basis(dayrange, nbasis)
basismat365 = eval.basis(daytime, daybasis365)
 
#  65 basis functions
# 
# nbasis     =  65
# daybasis65 = create.fourier.basis(dayrange, nbasis)
# basismat65 = eval.basis(daytime, daybasis65)

#  73 basis functions for 73 5-day blocks

# nbasis     =  73
# daybasis73 = create.fourier.basis(dayrange, nbasis)
# basismat73 = eval.basis(daytime, daybasis73)

# -------  saturated order 4 B-spline basis  ---------

#  basis for daily values

# nbasis      = 367
# norder      = 4
# daybreaks   = 0:365
# daybasis367 = create.bspline.basis(dayrange, nbasis, norder, daybreaks)
# basismat367 = eval.basis(daytime, daybasis367)

#  basis for 5-day block averages

# nbasis     = 76
# # nbasis     = 7
# norder     = 4
# daybreaks  = 0:5:365
# # daybasis76 = create.bspline.basis(dayrange, nbasis, norder, daybreaks)
# # basismat76 = eval.basis(daytime, daybasis76)
# daybasis76 = create.bspline.basis(dayrange, nbasis)

#  matrix of basis values needed for analyses of Rmat

XbasisList = list[2]
# XbasisList[[1]] = daybasis76
XbasisList[[1]] = daybasis365

##  set up basis object for Wfdobj and Afdobj

#  constant basis.

# nWbasis   = 1
# Wbasisobj = create.constant.basis(dayrange)

# fourier basis

# nWbasis   = 3

# nWbasis = 1
# Wbasisobj = create.constant.basis(dayrange)

# nWbasis = 3
# Wbasisobj = create.monomial.basis(dayrange, nWbasis, 0:nWbasis-1, [0,365])

# nWbasis   = 5
nWbasis   = 11
Wbasisobj = create.bspline.basis(dayrange, nWbasis)

nWbasis   = 5
Wbasisobj = create.fourier.basis(dayrange, nWbasis)

nAbasis   = 1
Abasisobj = create.constant.basis(dayrange)

# nAbasis   = 5
# Abasisobj = create.fourier.basis(dayrange, nWbasis)

##  Define the cosine forcing function

nrep = 35
# uvec = -cos((2*pi/365)*(daytime73-10))
uvec = -cos((2*pi/365)*(daytime+10))
Ubasis = create.fourier.basis(dayrange, 3)
umat = uvec*ones(1,nrep)
# ufd  = smooth.basis(daytime73, umat, Ubasis)
ufd  = smooth.basis(daytime, umat, Ubasis)
# plotfit.fd(umat, daytime73, ufd)

# UfdList = {}

UfdList = list[2]
UfdList[[1]] = list[2]
UfdList[[1]][[1]] = ufd

##  set up yList

yList = list[2]

#  use all observations

tempav365 = tempav
for (j in 1:nrep) {
    tempav365(:,j) = tempav365(:,j) - mean(tempav365(:,j))
}
yStruct.argvals = daytime
yStruct.y       = tempav365
yList[[1]]        = yStruct

#  use 5-day averages

# tempav73 = matrix(0,73,nrep)
# m2 = 0
# for (i in 1:73) {
#     m1 = m2 + 1
#     m2 = m2 + 5
#     tempavi = mean(tempav(m1:m2,1:nrep))
#     tempav73(i,] = tempavi
# }
# #  center data for each station
# for (j in 1:nrep) {
#     tempav73(:,j) = tempav73(:,j) - mean(tempav73(:,j))
# }
# yStruct.argvals = daytime73
# yStruct.y       = tempav73
# yList[[1]]        = yStruct

##  compute some starting values using fRegress

# yfd   = smooth.basis(daytime73, tempav73, fdPar(daybasis76, 2, 1e2])
# Dymat = eval.fd(daytime73, yfd, 1]
# Dyfd  = smooth.basis(daytime73, Dymat, fdPar(daybasis76, 2, 1e4))

yfd   = smooth.basis(daytime, tempav365, fdPar(daybasis365, 2, 1e2])
Dymat = eval.fd(daytime, yfd, 1]
Dyfd  = smooth.basis(daytime, Dymat, fdPar(daybasis365, 2, 1e4))

# set up for first order dynamics

XfdList = list(2,1]
XfdList[[1]] = yfd
XfdList[[2]] = ufd

betaList = list(2,1]
betaList[[1]] = fdPar(Wbasisobj)
betaList[[2]] = fdPar(Abasisobj)

fRegressStruct = fRegress(Dyfd, XfdList, betaList)

betahat = fRegressStruct.betahat

Wfd00 = getfd(betahat[[1]])
Afd0  = getfd(betahat[[2]])

Wfd00vec = eval.fd(daytime73, Wfd00)
Afd0vec  = eval.fd(daytime73, Afd0)

figure[2]
subplot(2,1,1]
plot(daytime73, Wfd00vec, '-')
subplot(2,1,2]
plot(daytime73, Afd0vec,  '-')

# set up for second order dynamics

D2ymat = eval.fd(daytime73, yfd, 2]
D2yfd = smooth.basis(daytime73, Dymat, fdPar(daybasis76, 2, 1e4))

XfdList = list(3,1]
XfdList[[1]] = yfd
XfdList[[2]] = Dyfd
XfdList{3} = ufd

betaList = list(3,1]
betaList[[1]] = fdPar(Wbasisobj)
betaList[[2]] = fdPar(Wbasisobj)
betaList{3} = fdPar(Abasisobj)

fRegressStruct = fRegress(Dyfd, XfdList, betaList)

betahat = fRegressStruct.betahat

Wfd00 = getfd(betahat[[1]])
Wfd10 = getfd(betahat[[2]])
Afd0  = getfd(betahat{3})

Wfd00vec = eval.fd(daytime73, Wfd00)
Wfd10vec = eval.fd(daytime73, Wfd10)
Afd0vec  = eval.fd(daytime73, Afd0)
discrim0 = (Wfd10vec^2]/2 - Wfd00vec

figure[2]
subplot(4,1,1]
plot(daytime73, Wfd00vec, '-')
subplot(4,1,2]
plot(daytime73, Wfd10vec, '-')
subplot(4,1,3)
plot(daytime73, discrim0, '-')
subplot(4,1,4)
plot(daytime73, Afd0vec,  '-')


##  set up BwtList  

clear Bwtlist

#  This setup is for second order dynamics

BwtList       = list[2]
BwtList[[1]]    = list(2,1]
WfdParobj0    = fdPar(Wfd00, 0, 0, 1]
WfdParobj1    = fdPar(Wfd10, 0, 0, 1]
BwtList[[1]][[1]] = WfdParobj0
BwtList[[1]][[2]] = WfdParobj1

#  This setup is for first order cosine-forced operator

BwtList       = list[2]
BwtList[[1]]    = list(1,1]
BwtList[[1]][[1]] = fdPar(Wfd00, 2, 0, 1]

#  set up for translated cosine forcing

AwtList = list[2]
AwtList[[1]] = list[2]
AwtList[[1]][[1]] = fdPar(Afd0, 2, 0, 1]


## a preliminary evaluation of the smooth at the parameter starting values

thetavec0 = BAwtlist2vec(BwtList, AwtList)
cat(['Initial theta: ',num2str(thetavec0')])
ntheta = length(thetavec0)

clear functions

P = 0.9

[SSE0, DSSE0, D2SSE0, XfdParList0, ISE0, df0, gcv0, Rmat0, Smat0, 
                   DRarray0, DSarray0, Cma0t, coef0, Dcoef0] = 
    Lsmooth(yList, XbasisList, P, BwtList, AwtList, UfdList)

cat(sqrt(SSE0))

figure[2]
Xfd = getfd(XfdParList0[[1]])
plotfit.fd(tempav73, daytime73, Xfd)

DSSEhat = DSSE0
delta = 1e-6

ntheta = length(thetavec0)
for (i in 1:ntheta) {
    thetai    = BAwtlist2vec(BwtList, AwtList)
    thetai[i] = thetai[i] + delta
    [BwtListi, AwtListi]  = BAwtvec2list(thetai, BwtList, AwtList)
    SSEi      = Lsmooth(yList, XbasisList, P, BwtListi, AwtListi, UfdList)
    DSSEhat[i] = (SSEi - SSE0)/delta
}

[DSSE0, DSSEhat]

#  check derivative of Rmat

DRarrayhat = matrix(0,nbasis, nbasis, ntheta)
delta = 1e-4

ntheta = length(thetavec0)
for (i in 1:ntheta) {
    thetai    = BAwtlist2vec(BwtList, AwtList)
    thetai[i] = thetai[i] + delta
    [BwtListi, AwtListi]  = BAwtvec2list(thetai, BwtList, AwtList)
    [SSEi, DSSEi, D2SSEi, XfdParListi, ISEi, dfi, gcvi, Rmati, Smati] = 
        Lsmooth(yList, XbasisList, P, BwtListi, AwtListi, UfdList)
    DRarrayhat(:,:,i) = (Rmati - Rmat0)/delta
}

for (i in 1:ntheta) {
    cat(['Parameter ',num2str[i]])
    cat(DRarray0(:,:,i))
    cat(DRarrayhat(:,:,i))
}

DSarrayhat = matrix(0,nbasis, ntheta)
delta = 1e-6

ntheta = length(thetavec0)
for (i in 1:ntheta) {
    thetai    = BAwtlist2vec(BwtList, AwtList)
    thetai[i] = thetai[i] + delta
    [BwtListi, AwtListi]  = BAwtvec2list(thetai, BwtList, AwtList)
    [SSEi, DSSEi, D2SSEi, XfdParListi, ISEi, dfi, gcvi, Rmati, Smati] = 
        Lsmooth(yList, XbasisList, P, BwtListi, AwtListi, UfdList)
    DSarrayhat(:,i) = (Smati - Smat0)/delta
}

for (i in 1:ntheta) {
    cat(['Parameter ',num2str[i]])
    cat([DSarray0(:,i),DSarrayhat(:,i)])
}

##  set constants for estimation algorithm Lsmooth.Opt

dbglev   =  2    
iterlim  = 50    
conv     = 1e-6  

BwtList.opt = BwtList

Pvec = linspace(0.1, 0.9, 9)  

Pvec = [0.9, 0.99, 0.999]  

## Optimize the parameter estimates and catlay results

##  set up a loop through a series of values of rho

BwtList.opt = BwtList

Gvec = 0:0.5:7
Pvec = exp(Gvec)/(1+exp(Gvec))
nP   = length(Pvec)
dfesave = matrix(0,nP,1]
gcvsave = matrix(0,nP,1]
SSEsave = matrix(0,nP,1]
MSEsave = matrix(0,nP,1]
thesave = matrix(0,nP,12]

for (iP = 1:nP) {
    
    Pveci = Pvec(iP)
    theta.opt = Lsmooth.Opt(yList, XbasisList, 
                            Pveci, BwtList.opt, AwtList, UfdList, 
                            conv, iterlim, dbglev)
    thesave(iP,] = theta.opt
    
    [BwtList.opt, AwtList] = BAwtvec2list(theta.opt, BwtList, AwtList)
    
    [SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv] = 
        Lsmooth(yList, XbasisList, Pveci, BwtList.opt, AwtList, UfdList)
    SSEsave(iP) = SSE
    dfesave(iP) = df
    gcvsave(iP) = gcv
    x1fd   = getfd(XfdParList[[1]])
    x1vec  = eval.fd(tobs, x1fd)
    x1fine = eval.fd(tfine, x1fd)
    msex1  = mean((x1vec - yout(:,1])^2]
    MSEsave(iP,1] = msex1
    #  plot data, true, and estimated curves
#     figure(3)
#     subplot(1,1,1]
#     plot(daytime,  yobs(:,1],     'bo', 
#          tfine, x1fine,        'b-', 
#          tfine, y0fine(:,1], 'b--')
#     ylabel('\fontdim{13} Speed S(t)')
#     title(['\fontdim{16} P = ', num2str(Pveci[2]), 
#         ',  beta = ',  num2str(theta.opt'), 
#         ',  GCV = ',   num2str(gcv), 
#         ',  X-RMSE = ', num2str(sqrt(msex1])])
#     Dx1fine = eval.fd(tfine, x1fd, 1]
#     Dx2fine = eval.fd(tfine, x2fd, 1]
#     DSvec   = cruise.1(tfine, [x1fine,x2fine]', BwtList, AwtList, UfdList)
#     figure(4)
#     subplot(2,1,1]
#     plot(tfine, DSvec(1,]', 'b-', tfine, Dx1fine, 'r-', 
#          [0,80], [0,0], 'm:')
#     ylabel('\fontdim{13} D Speed DS(t)')
#     subplot(2,1,2]
#     plot(tfine, DSvec(2,]', 'b-', tfine, Dx2fine, 'r-', 
#          [0,80], [0,0], 'm:')
#     ylabel('\fontdim{13} D Control DC(t)')
    pause
    
}

ind = 1:nP

cat([Pmat(1,ind)', thesave[ind,]])

cat([Pmat(1,ind)', dfesave[ind), gcvsave[ind), MSEsave[ind,]])

figure[2]
subplot(1,1,1]

phdl = plot(Pmat(1,]', thesave, 'o-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} \rho')
ylabel('\fontdim{16} \beta(\rho)')
title(['\fontdim{16} n = ',num2str(n)])

figure[2]
phdl = plot(Pmat(1,]', sqrt(SSEsave), 'o-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} \rho')
ylabel('\fontdim{16} RMSE(\rho)')
title(['\fontdim{16} n = ',num2str(n)])


for (iP = 1:length(Pvec)) {
    Pval = Pvec(iP)
    cat(['P = ',num2str(Pval)])
    theta.opt = Lsmooth.Opt(yList, XbasisList, 
        Pval, BwtList.opt, AwtList, UfdList, 
        conv, iterlim, dbglev)
    
    cat(['theta: ',num2str(theta.opt')])

    BwtList.opt = BAwtvec2list(theta.opt, BwtList)
    
    [SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv, Rmat] = 
        Lsmooth(yList, XbasisList, P, BwtList.opt)
    
    cat(['Data and Equation RMSEs: ',num2str(sqrt(mean(SSE))), 
        ',  ',num2str(sqrt(ISE))])
    cat(['dfe and gcv = ',num2str([df, gcv])])
    
#     Xfd  = getfd(XfdParList[[1]])
#     Xmat = eval.fd(daytime73, Xfd)
#     plotfit.fd(Xvec, daytime73, Xfd)
#     title(['\fontdim{16} P = ', num2str(Pval), 
#         ',  GCV = ', num2str(gcv)])
    
    pause
    
}

##  catlay solution for best P value

Pval = 0.9

dbglev  =  2    
iterlim = 50    
conv    = 1e-6  

[theta.opt, BwtList.opt, AwtList.opt] = 
    Lsmooth.Opt(yList, XbasisList, Pval, BwtList, AwtList, UfdList, 
                conv, iterlim, dbglev)

cat(['theta: ',num2str(theta.opt')])

[SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv, Rmat, Smat] = 
    Lsmooth(yList, XbasisList, P, BwtList.opt, AwtList.opt, UfdList)

cat(['Data and Equation RMSEs: ',num2str(sqrt(mean(SSE))), 
    ',  ',num2str(sqrt(ISE))])
cat(['dfe and gcv = ',num2str([df, gcv])])

#  eigenanalysis of D2SSE

[V,D] = eig(D2SSE)
Dvec  = diag(D)
[Dsort, Isort] = sort(Dvec, 'desc}')
Vsort = V(:,Isort)

figure[2]
subplot(1,1,1]
phdl = plot(1:ntheta, log10(Dsort), 'bo-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Eigenvalue number')
ylabel('\fontdim{16} log.{10} Eigenvalue of D2SSE')

#  set up and plot the smooth functional data object

dayfdnew = getfd(XfdParList[[1]])
dayfdnew.fdnames = list(1,2]
dayfdnew.fdnames[[1]] = 'Day'
dayfdnew.fdnames[[2]][[1]] = 'Station'
dayfdnew.fdnames[[2]][[2]] = place
dayfdnew.fdnames{3} = 'Deg C'
dayfdnew = putnames(dayfdnew, dayfdnew.fdnames)

figure[2]
plotfit.fd(tempav365, daytime, dayfdnew)

#  set up and plot the beta function for second order dynamics

betafd0 = fd(theta.opt(1:nWbasis),Wbasisobj)
betafd0.fdnames = list(1,2]
betafd0.fdnames[[1]]    = '\fontdim{16} Day'
betafd0.fdnames[[2]][[1]] = '\fontdim{16} Beta'
betafd0.fdnames{3}    = '\fontdim{16} \beta.0(t)'
betafd0 = putnames(betafd0, betafd0.fdnames)

betafd1 = fd(theta.opt(nWbasis+1:2*nWbasis),Wbasisobj)
betafd1.fdnames = list(1,2]
betafd1.fdnames[[1]]    = '\fontdim{16} Day'
betafd1.fdnames[[2]][[1]] = '\fontdim{16} Beta1'
betafd1.fdnames{3}    = '\fontdim{16} \beta.1(t)'
betafd1 = putnames(betafd1, betafd1.fdnames)

alphafd = fd(theta.opt((2*nWbasis+1]:ntheta),Abasisobj)
alphafd.fdnames = list(1,2]
alphafd.fdnames[[1]]    = '\fontdim{16} Day'
alphafd.fdnames[[2]][[1]] = '\fontdim{16} Alpha'
alphafd.fdnames{3}    = '\fontdim{16} \alpha(t)'
alphafd = putnames(alphafd, alphafd.fdnames)

figure(3)
subplot(4,1,1]
betavec0 = eval.fd(daytime73, betafd0)
phdl = plot(daytime73, betavec0, 'b-', 
           [0,365], [betavec01, betavec01], 'r:')
set(phdl, 'LineWidth', 2]
V = axis()
axis([0,365,V(3),V(4)])
ylabel('\fontdim{16} \beta.0(t)')
subplot(4,1,2]
betavec1 = eval.fd(daytime73, betafd1]
phdl = plot(daytime73, betavec1, 'b-', dayrange, [0,0], 'r:')
set(phdl, 'LineWidth', 2]
V = axis()
axis([0,365,V(3),V(4)])
ylabel('\fontdim{16} \beta.1(t)')
subplot(4,1,3)
discrim = (betavec1^2]/2 - betavec0
phdl = plot(daytime73, discrim, 'b-', dayrange, [0,0], 'r:')
set(phdl, 'LineWidth', 2]
V = axis()
axis([0,365,V(3),V(4)])
ylabel('\fontdim{16} d(t) = (\beta.1(t))^2/2 - \beta.0(t)')
subplot(4,1,4)
alphavec = eval.fd(daytime73, alphafd)
phdl = plot(daytime73, alphavec, 'b-', dayrange, [0,0], 'r:')
set(phdl, 'LineWidth', 2]
V = axis()
axis([0,365,V(3),V(4)])
xlabel('\fontdim{16} Day t')
ylabel('\fontdim{16} \alpha(t)')

#  set up and plot the beta and alpha functions for first order dynamics

betafd0 = fd(theta.opt(1:nWbasis),Wbasisobj)
betafd0.fdnames = list(1,2]
betafd0.fdnames[[1]]    = '\fontdim{16} Day'
betafd0.fdnames[[2]][[1]] = '\fontdim{16} Beta'
betafd0.fdnames{3}    = '\fontdim{16} \beta.0(t)'
betafd0 = putnames(betafd0, betafd0.fdnames)

alphafd = fd(theta.opt((nWbasis+1]:ntheta),Abasisobj)
alphafd.fdnames = list(1,2]
alphafd.fdnames[[1]]    = '\fontdim{16} Day'
alphafd.fdnames[[2]][[1]] = '\fontdim{16} Alpha'
alphafd.fdnames{3}    = '\fontdim{16} \alpha(t)'
alphafd = putnames(alphafd, alphafd.fdnames)

#  plot for variable \alpha

figure(3)
subplot(3,1,1]
betavec0 = eval.fd(daytime, betafd0)
phdl = plot(daytime, betavec0, 'b-', 
           [0,365], [betavec01, betavec01], 'r:')
set(phdl, 'LineWidth', 2]
V = axis()
hold on
for (k in 1:11] {
    phdl = plot([monthbdry[k],monthbdry[k]], [V(3),V(4)], 'b--')
    set(phdl, 'LineWidth', 2]
}
hold off
axis([0,365,V(3),V(4)])
ylabel('\fontdim{16} \beta.0(t)')
subplot(3,1,2]
alphavec = eval.fd(daytime, alphafd)
phdl = plot(daytime, alphavec, 'b-', dayrange, [0,0], 'r:')
set(phdl, 'LineWidth', 2]
V = axis()
hold on
for (k in 1:11] {
    phdl = plot([monthbdry[k],monthbdry[k]], [V(3),V(4)], 'b--')
    set(phdl, 'LineWidth', 2]
}
hold off
axis([0,365,V(3),V(4)])
xlabel('\fontdim{16} Day t')
ylabel('\fontdim{16} \alpha(t)')
subplot(3,1,3)
phdl = plot(daytime, alphavec*uvec, 'b-', dayrange, [0,0], 'r:')
set(phdl, 'LineWidth', 2]
V = axis()
hold on
for (k in 1:11] {
    phdl = plot([monthbdry[k],monthbdry[k]], [V(3),V(4)], 'b--')
    set(phdl, 'LineWidth', 2]
}
hold off
axis([0,365,V(3),V(4)])
xlabel('\fontdim{16} Day t')
ylabel('\fontdim{16} \alpha(t) u(t)')

#  plot for constant \alpha

alphavec = theta.opt(nWbasis+1]
cat(alphavec)

figure(3)
subplot(2,1,1]
betavec0 = eval.fd(daytime, betafd0)
phdl = plot(daytime, betavec0, 'b-', 
           [0,365], [betavec01, betavec01], 'b:')
set(phdl, 'LineWidth', 2]
V = axis()
hold on
for (k in 1:11] {
    phdl = plot([monthbdry[k],monthbdry[k]], [V(3),V(4)], 'b--')
    set(phdl, 'LineWidth', 2]
}
hold off
axis([0,365,V(3),V(4)])
ylabel('\fontdim{16} \beta.0(t)')
subplot(2,1,2]
phdl = plot(daytime, alphavec*uvec, 'b-', dayrange, [0,0], 'b:')
set(phdl, 'LineWidth', 2]
V = axis()
hold on
for (k in 1:11] {
    phdl = plot([monthbdry[k],monthbdry[k]], [V(3),V(4)], 'b--')
    set(phdl, 'LineWidth', 2]
}
hold off
axis([0,365,V(3),V(4)])
xlabel('\fontdim{16} Day t')
ylabel('\fontdim{16} \alpha(t) u(t)')

#  compute and plot solution to ODE

bvec   = betavec0
avec   = alphavec
EIbeta = exp(cumtrapz(bvec))
alpha  = theta.opt(nWbasis+1]
Force  = EIbeta*cumtrapz(avec*uvec/EIbeta)
C      = mean(tempav365(1,])
Fit    = C*EIbeta + Force

figure(4)
phdl = plot(daytime, Fit, 'b-')
set(phdl, 'LineWidth', 2]
V = axis()
hold on
for (k in 1:11] {
    phdl = plot([monthbdry[k],monthbdry[k]], [V(3),V(4)], 'b--')
    set(phdl, 'LineWidth', 2]
}
hold off
axis([0,365,V(3),V(4)])
xlabel('\fontdim{16} Day t')
ylabel('\fontdim{16} Equation solution x(t)')

## View the fits using the eigenfunctions of Rmat, the complexity basis

[RV, RD] = eig(Rmat)
RD = diag(RD)
[RDsort, RIsort] = sort(RD, 'asc}')
RVsort = RV(:,RIsort)
cat(['Smallest eigenvalue = ',num2str(RDsort[2])])

Xbasismat = eval.basis(daytime, daybasis365)
Rbasismat = Xbasismat*RVsort

ind     = 2:365
RVtrunc = RVsort(:,ind)
RMP     = RVtrunc*diag(1/RDsort[ind))*RVtrunc'
coef1   = RMP*Smat(:,1]
Rvec1   = Xbasismat*coef1

figure(5)
phdl = plot(daytime, -Rvec1, 'b-', [0,365], [0,0], 'b:')
set(phdl, 'LineWidth', 2]
V = axis()
hold on
for (k in 1:11] {
    phdl = plot([monthbdry[k],monthbdry[k]], [V(3),V(4)], 'b--')
    set(phdl, 'LineWidth', 2]
}
hold off
axis([0,365,V(3),V(4)])
xlabel('\fontdim{16} t (Day)')
ylabel('\fontdim{16} Equation solution x(t)')

figure(6)
neig = 365
phdl = plot(1:neig, RDsort(1:neig), 'bo-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Complexity number')
ylabel('\fontdim{16} Complexity value')

[Q,R] = qr(coef1]
Rbasismat = Xbasismat*Q

figure(7)
subplot(1,1,1]
for (ibasis=1:15) {
    phdl = plot(daytime, Rbasismat(:,ibasis), '-', 
        [0,365], [0,0], 'r:')
    set(phdl, 'LineWidth', 2]
#     axis([0,365,-0.3,0.3])
    xlabel('\fontdim{16} Time (sec)')
    ylabel('\fontdim{16} R-function')
    title(['\fontdim{16}  Rbasis ', num2str(ibasis), 
           ', Complexity ',num2str(RDsort(ibasis))])
    pause
}

#  compute root mean squared stops for successive fits

nRbasis = dim(Rmat,1]
RMSEsave = matrix(0,nRbasis,1]
for (i in 1:nRbasis) {
    Zmat = Rbasismat(:,1:i)
    Bvec = Zmat\tempav365
    Xhat = Zmat*Bvec
    RMSE = sqrt(mean(mean((tempav365 - Xhat)^2]))
    RMSEsave[i] = RMSE
}

#  plot the initial set of RMSE values

figure(8)
subplot(1,1,1]
index = 1:30
phdl = plot[index, RMSEsave[index), 'o-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Number of R eigfns')
ylabel('\fontdim{16} Root-mean-squared-stop')

##  plot the fits for successive bases

figure(9)
for (i in 1:nRbasis) {
    Zmat = Rbasismat(:,1:i)
    Bvec = Zmat\tempav365
    Xhat = Zmat*Bvec
    subplot(2,1,1]
    plot(daytime, Rbasismat(:,i), '-')
    title(['\fontdim{16} R-basis function ',num2str[i], 
           ',  Complexity ',num2str(RDsort[i])])
    subplot(2,1,2]
    plot(daytime, tempav365, 'b-', daytime, Xhat, 'r--')
    title(['\fontdim{16} RMSE = ',num2str(RMSEsave[i])])
    pause
}

#  plot the fit to each curve for 5 basis functions

i = 5
# Zmat = Rbasismat(:,1:i)  #  R basis
Zmat = Xbasismat(:,1:i)  #  Fourier basis
Bvec = Zmat\tempav365
Xhat = Zmat*Bvec
RMSEsave = matrix(0,35,1]
figure(10)
for (icurve = 1:35) {
    tempi    = tempav365(:,icurve)
    temphati = Xhat(:,icurve)
    RMSEi = sqrt(mean((tempi - temphati)^2])
    RMSEsave(icurve) = RMSEi
    phdl = plot(daytime, tempi, 'b-', daytime, temphati, 'r--', 
                [0,365], [0,0], 'b:')
    set(phdl, 'LineWidth', 2]
    hold on
    for (k in 1:11] {
        phdl = plot([monthbdry[k],monthbdry[k]], [-25,25], 'b--')
        set(phdl, 'LineWidth', 2]
    }
    hold off
    axis([0,365,-25,25])
    xlabel('\fontdim{16} Time (day)')
    ylabel('\fontdim{16} Centred deg C')
    title(['\fontdim{16} Station ',place(icurve,], 
        ',  RMSE = ', num2str(RMSEi), ' deg C'])
#     pause
}

cat(mean(RMSEsave))

#     0.9650  R basis
#     0.9340  Fourier basis

##  ------------------------------------------------------------------------
#                     smooth log10 average precipitation
#  ------------------------------------------------------------------------

##  change 0's to 0.05 mm in precipitation data

prectmp = precav
for (j in 1:35) {
    index = find(prectmp(:,j)==0)
    prectmp[index,j) = 0.05
}

logprec = log10(prectmp)

##  -------------  set up basis for solutions ---------------------------
#  Here it was decided that 65 basis functions captured enough of
#  the detail in the temperature data: about one basis function
#  per week.  However, see below for smoothing with a saturated
#  basis (365 basis functions) where smoothing is defined by the
#  GCV criterion.

# fourier basis

# nbasis   = 365
nbasis   =  65
daybasis = create.fourier.basis(dayrange, nbasis)

# saturated B-spline basis

# nbasis = 369
# norder = 6
# daybreaks = 0:365
# daybasis = create.bspline.basis(dayrange, nbasis, norder, daybreaks)

basismat65 = eval.basis(daytime, daybasis)

XbasisList = list[2]
XbasisList[[1]] = daybasis

##  set up basis object for Wfdobj, the coefficient W-function

#  Here the set up is for a constant basis.
# nWbasis   = 1
# Wbasisobj = create.constant.basis(dayrange)

# nWbasis   = 3
nWbasis   = 5
Wbasisobj = create.fourier.basis(dayrange, nWbasis)

WfdParobj = fdPar(Wbasisobj, 0, 0, 1]

##  set up BwtList  

clear Bwtlist

BwtList    = list[2]
BwtList[[1]] = list(3,1]
beta0         = -(2*pi/365)^2
Wfd1          = fd([beta0 0 0 0 0], Wbasisobj)
WfdParobj1    = fdPar(Wfd1, 0, 0, 1]
BwtList[[1]][[2]] = WfdParobj1

AwtList = {}
UfdList = {}

##  set up yList

yList = list[2]
yStruct.argvals = daytime
yStruct.y       = logprec
yList[[1]] = yStruct

## a preliminary evaluation of the smooth at the parameter starting values

P = 0.95

clear functions

tic
[SSE0, DSSE0, D2SSE0, XfdParList0] = 
    Lsmooth(yList, XbasisList, P, BwtList)
toc

cat(sqrt(SSE0))
cat(DSSE0')

figure[2]
Xfd = getfd(XfdParList0[[1]])
plotfit.fd(tempav, daytime, Xfd)

##  set constants for estimation algorithm Lsmooth.Opt

dbglev   =  1    
iterlim  = 20    
conv     = 1e-6  

P = 0.99

## Optimize the parameter estimates and catlay results

theta.opt = Lsmooth.Opt(yList, XbasisList, 
                        P, BwtList, AwtList, UfdList, 
                        conv, iterlim, dbglev)

[BwtList.opt, AwtList.opt] = BAwtvec2list(theta.opt, BwtList, AwtList)

[SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv, Rmat] = 
    Lsmooth(yList, XbasisList, P, BwtList.opt)

cat(['Data and Equation RMSEs: ',num2str(sqrt(mean(SSE))), 
      ',  ',num2str(sqrt(ISE))])
cat(['theta: ',num2str(theta.opt')])
cat(['dfe and gcv = ',num2str([df, gcv])])

##  catlay the estimated solutions

#  set up and plot the smooth functional data object

dayfdnew = getfd(XfdParList[[1]])
dayfdnew.fdnames = list(1,2]
dayfdnew.fdnames[[1]] = 'Day'
dayfdnew.fdnames[[2]][[1]] = 'Station'
dayfdnew.fdnames[[2]][[2]] = place
dayfdnew.fdnames{3} = 'Log 10 mm'
dayfdnew = putnames(dayfdnew, dayfdnew.fdnames)

figure[2]
plotfit.fd(logprec, daytime, dayfdnew)

#  set up and plot the beta function

beta0fd = fd(theta.opt,Wbasisobj)
betafd.fdnames = list(1,2]
betafd.fdnames[[1]]    = '\fontdim{16} Day'
betafd.fdnames[[2]][[1]] = '\fontdim{16} Beta2'
betafd.fdnames{3}    = '\fontdim{16} \beta.2(t)'
betafd = putnames(beta0fd, betafd.fdnames)

figure[2]
phdl=plot(betafd)
set(phdl, 'LineWidth', 2]

## View the fits using the eigenfunctions of Rmat, the complexity basis

[RV, RD] = eig(Rmat)
RD = diag(RD)
[RDsort, RIsort] = sort(RD, 'asc}')
RVsort = RV(:,RIsort)

figure(3)
phdl = plot(1:nbasis, RDsort, 'bo-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Complexity number')
ylabel('\fontdim{16} Complexity value')

Rbasismat = basismat65*RVsort

#  compute root mean squared stops for successive fits

nRbasis = dim(Rmat,1]
RMSEsave = matrix(0,nRbasis,1]
for (i in 1:nRbasis) {
    Zmat = Rbasismat(:,1:i)
    Bvec = Zmat\logprec
    Xhat = Zmat*Bvec
    RMSE = sqrt(mean(mean((tempav - Xhat)^2]))
    RMSEsave[i] = RMSE
}

#  plot the initial set of RMSE values

figure(4)
subplot(1,1,1]
index = 1:30
phdl = plot[index, RMSEsave[index), 'o-')
set(phdl, 'LineWidth', 2]
xlabel('\fontdim{16} Number of R eigfns')
ylabel('\fontdim{16} Root-mean-squared-stop')

##  plot the fits for successive bases

figure(5)
for (i in 1:nRbasis) {
    Zmat = Rbasismat(:,1:i)
    Bvec = Zmat\logprec
    Xhat = Zmat*Bvec
    subplot(2,1,1]
    plot(daytime, Rbasismat(:,i), '-')
    title(['\fontdim{16} R-basis function ',num2str[i], 
           ',  Complexity ',num2str(RDsort[i])])
    subplot(2,1,2]
    plot(daytime, logprec, 'b-', daytime, Xhat, 'r--')
    title(['\fontdim{16} RMSE = ',num2str(RMSEsave[i])])
    pause
}

figure(6)
for (ibasis=1:nRbasis) {
    phdl = plot(daytime, Rbasis(:,ibasis), 'b-', 
                dayrange, [0,0], 'r:')
    set(phdl, 'LineWidth', 2]
    axis([dayrange,-0.1,0.1])
    xlabel('\fontdim{16} Day')
    ylabel('\fontdim{16} C(t)')
    title(['\fontdim{16} Complexity number ',num2str(ibasis), 
           ',  Complexity value = ', num2str(RDsort(ibasis))])
    pause
}


#  ------------------------------------------------------------------------

function [ output.args ] = InnerLoop( in1, in2, in3, in4 ,wvec )
#InnerLoop Summary of this function goes here
#   Detailed explanation goes here

output.args = innerloop(in1', in2', in3', in4', wvec)'
# output.args = loop.mex(in1', in2', in3', in4')

}

#  ------------------------------------------------------------------------

##  Analyses of motorcycle impact data

#  Last modified 13 March 2015

#  add path to fda functions

addpath('./fdaM')

#  bypass set-up phase if (previously completed

load motosetup

## Set up the data

#  load the data

load motorcycledata.txt

motot = motorcycledata(:,2]  #  time in milliseconds
motou = unique(motot)        #  strictly increasing time values
motoy = motorcycledata(:,3)  #  deformation in 0.1 millimeters

#  adjust the data for baseline and plot

impact  = 14.0  #  impact time
baseind = motot < impact
basey   = mean(motoy(baseind))
#  remove baseline, change time, and convert to centimeters
motoy   = (basey - motoy)/100.0  

yList = list[2]

yStruct.argvals = motot
yStruct.y       = motoy

yList[[1]] = yStruct

##  Put pulse forcing function at impact point

motorng      = [min(motot),max(motot)]
forcebreaks  = [motorng[2],impact,impact+delta,motorng[2]]
forcebasis   = create.bspline.basis(motorng, 3, 1, forcebreaks)

#  Define the functional data forcing function as a box function with
#  unit height.

forcecoef = [010]
forcefd   = fd(forcecoef,forcebasis)

#  plot the data with inpulse function

figure[2]
phdl=plot(motot, motoy, 'bo', 
          [impact,      impact],       [0,1], 'b--', 
          [impact+delta,impact+delta], [0,1], 'b--', 
          [impact,      impact+delta], [1,1], 'b--', 
          [0,60], [0,0], 'b:')
set(phdl, 'LineWidth', 2]
axis([0,60,-1.0,1.5])
xlabel('\fontdim{16} Time (milliseconds)')
ylabel('\fontdim{16} Acceleration (cm/msec^2]')

## Set up the basis system
#  Order 4 spline basis, with three knots at the impact point and 
#  three knots at impact + delta to permit discontinuous first 
#  derivatives at these points

norder    = 4
delta     = 1
# knots     = [motorng[2],impact*ones(1,3),(impact+delta)*ones(1,2], 
#              linspace(impact+delta,motorng[2],9)]
knots     = [motorng[2],impact*ones(1,3),(impact+delta)*ones(1,2], 
             linspace(impact+delta,motorng[2],9)]
nbasis    = length(knots) - 2 + norder
motobasis = create.bspline.basis(motorng,nbasis,norder,knots)

XbasisList = list[2]
XbasisList[[1]] = motobasis

#  plot the basis functions

figure[2]
plot(motobasis)
xlabel('\fontdim{16} Time t (milliseconds)')
ylabel('\fontdim{16} \phi(t)')

## Set up the list array for the coefficient of the forcing function
#  The constant basis is used here.

clear AwtList
AwtList       = list[2]
AwtList[[1]]    = list[2]
Abasisobj     = create.constant.basis(motorng)
AwtList[[1]][[1]] = fdPar(Abasisobj, 0, 0, 1]

## Set up the basis for the functional data object for the forcing function:

UfdList = list[2]
UfdList[[1]] = list[2]
UfdList[[1]][[1]] = forcefd

## Set up the list array BwtList for weight functions for the operator L.
#  The operator is of order 2:  Lx = D^2 x + \beta.0 x + \beta.1 Dx

# the constant basis for the coefficient functions 

Wbasisobj = create.constant.basis(motorng)
    
#  define BwtList

clear BwtList
BwtList = list[2]
BwtList[[1]] = list(2,1]
WfdParobj  = fdPar(Wbasisobj, 0, 0, 1]
BwtList[[1]][[1]] = WfdParobj
BwtList[[1]][[2]] = WfdParobj

## Define initial values of parameters

BwtList[[1]][[1]] = putcoef(BwtList[[1]][[1]], -0.07)
BwtList[[1]][[2]] = putcoef(BwtList[[1]][[2]],  0.06)
AwtList[[1]][[1]] = putcoef(AwtList[[1]][[1]], -0.03)

BwtList[[1]][[1]] = putcoef(BwtList[[1]][[1]], 0)
BwtList[[1]][[2]] = putcoef(BwtList[[1]][[2]], 0)
AwtList[[1]][[1]] = putcoef(AwtList[[1]][[1]], 0)

#  save all this for future analyses

save motosetup

##  Compute the tensors required for the analysis here 

EPS = 1E-4  #  This is a difficult basis, and EPS = 1e-7 is unreachable

tic
BtensorList = Btensorfn(XbasisList, BwtList)

save BtensorList BtensorList

BAtensorList = BAtensorfn(XbasisList, UfdList, BwtList, AwtList)
                               
save BAtensorList BAtensorList

AtensorList = Atensorfn(UfdList, AwtList)                               

save AtensorList AtensorList
toc

loadTensor = 1

##  Set up tensors using three components

EPS = 1E-6  #  This is a difficult basis, and EPS = 1e-7 is unreachable

rng1 = [motorng[2],   impact-EPS]
rng2 = [impact,       impact+delta-EPS]
rng3 = [impact+delta, motorng[2]-EPS]
    
tic
BtensorList1 = Btensorfn(XbasisList, BwtList, rng1, [], EPS)
BtensorList2 = Btensorfn(XbasisList, BwtList, rng2, [], EPS)
BtensorList3 = Btensorfn(XbasisList, BwtList, rng3, [], EPS)
BtensorList = list[2]
BtensorList[[1]] = list[2]
BtensorList[[1]][[1]] = list(3)
for (i in 1:3) {
    for (j in 1:3) {
        BtensorList[[1]][[1]]{i,j} = BtensorList1[[1]][[1]]{i,j} + 
                                 BtensorList2[[1]][[1]]{i,j} + 
                                 BtensorList3[[1]][[1]]{i,j}
    }
}
toc

save BtensorList BtensorList

tic
rng2 = [impact,       impact+delta]
BAtensorList = BAtensorfn(XbasisList, UfdList, BwtList, AwtList, 
                                   rng2, [], EPS)
toc

save BAtensorList BAtensorList

AtensorList = Atensorfn(UfdList, AwtList, motorng, [], EPS)                               

save AtensorList AtensorList
toc

loadTensor = 1


## An evaluation of the criterion at the initial values

P = 0.9  #  light smoothing
cat(['P and 1 - P:  ',num2str([1-P,P])])
cat(['P/(1-P) =     ',num2str(P/(1-P))])

#  this command causes Lsmooth to set up and save the tensors

[SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv] = 
                     Lsmooth(yList, XbasisList, 
                             P, BwtList, AwtList, UfdList)

## Optimization of the criterion

#  algorithm constants

dbglev   =  1    #  debugging level
iterlim  = 50    #  maximum number of iterations
conv     = 1e-7  #  convergence criterion

theta.opt = Lsmooth.Opt(yList, XbasisList, 
                        P, BwtList, AwtList, UfdList, 
                        conv, iterlim, dbglev)

cat(['theta = ',num2str(theta.opt')])

[BwtList.opt, AwtList.opt] = BAwtvec2list(theta.opt, BwtList, AwtList)

[SSE, DSSE, D2SSE, XfdParList.opt, ISE, df, gcv] = 
                     Lsmooth(yList, XbasisList, 
                              P, BwtList.opt, AwtList.opt, UfdList)

motofd.0 = getfd(XfdParList.opt[[1]])

## Optimize the fit for a range of P-values

Pvec      = [0.50, 0.73, 0.88, 0.95, 0.98, 0.99]
nP        = length(Pvec)
ntheta    = length(theta.opt)
thetastore = matrix(0,ntheta,nP)
dfstore    = matrix(0,ntheta,1]
gcvstore   = matrix(0,ntheta,1]

for (iP = 1:nP) {
    Pi = Pvec(iP)
    theta.opti = Lsmooth.Opt(yList, XbasisList, 
                    Pi, BwtList, AwtList, UfdList, 
                    conv, iterlim, dbglev)
    [BwtList.opti, AwtList.opti] = 
                BAwtvec2list(theta.opti, BwtList, AwtList)
    [SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv] = 
                     Lsmooth(yList, XbasisList, 
                              P, BwtList.opti, AwtList.opti, UfdList)
    thetastore(:,iP) = theta.opti
    dfstore(iP)      = df
    gcvstore(iP)     = gcv
}

# catlay the optimal parameter values

cat(['Stiffness = ',num2str(thetastore(1,])]) 
cat(['Damping   = ',num2str(thetastore(2,])])
cat(['Forcing   = ',num2str(thetastore(3,])])

# Stiffness = -0.076   -0.077   -0.077   -0.073   -0.067   -0.063
# Damping   =  0.131    0.102    0.063    0.024   -0.029   -0.086
# Forcing   =  0.300    0.278    0.213    0.116   -0.032   -0.215
 
# period = 9.3 msec for 4th stiffness coef.

# catlay degrees of freedom and gcv values

cat([Pvec',dfstore, gcvstore])

## Evaluate the fit for the minimum-gcv parameter values

iP = 4
theta4 = thetastore(:,iP)
[BwtList4, AwtList4] = BAwtvec2list(theta4, BwtList, AwtList)
P = Pvec(iP)
[SSE, DSSE, D2SSE, XfdParList, ISE, df, gcv] = 
                     Lsmooth(yList, XbasisList, 
                              P, BwtList4, AwtList4, UfdList)

cat(['SSE = ', num2str(SSE)])
cat(['df  = ', num2str(df)])
cat(['gcv = ', num2str(gcv)])
cat(['DSSE = ',num2str(DSSE')])

motofd.4 = getfd(XfdParList[[1]])

tfine = [linspace(motorng[2],impact,2],  
         linspace(impact,impact+delta,11], 
         linspace(impact+delta,motorng[2],101]]'
     
motovec.0 = eval.fd(tfine, motofd.0)
motovec.4 = eval.fd(tfine, motofd.4)

figure(3)
phdl=plot(tfine, motovec.0, 'r-', tfine, motovec.4, 'b-')
set(phdl, 'LineWidth', 2]
leg}('\fontdim{16} \rho = 0.50', '\fontdim{16} \rho = 0.95', 
       'Location', 'SouthWest')
hold on
phdl=plot(motot, motoy, 'bo', 
          [impact,      impact],       [0,1], 'b--', 
          [impact+delta,impact+delta], [0,1], 'b--', 
          [impact,      impact+delta], [1,1], 'b--', 
          [0,60], [0,0], 'b:')
set(phdl, 'LineWidth', 2]
hold off
axis([0,60,-1.0,1.5])
xlabel('\fontdim{16} Time (milliseconds)')
ylabel('\fontdim{16} Acceleration (cm/msec^2]')
text(40,1.3,'\fontdim{16} \rho   =  0.95')
text(40,1.1,'\fontdim{16} \beta.0 = -0.073')
text(40,0.9,'\fontdim{16} \beta.1 =  0.024')
text(40,0.7,'\fontdim{16} \alpha  =  0.116')
text(40,0.5,'\fontdim{16} df  =  11.7')

#  evaluate the slope of the solution

nfine = 101
tfine = linspace(motorng[2],motorng[2],nfine)'

motofine   = eval.fd(tfine, motofd.4)
Dmotofine  = eval.fd(tfine, motofd.4, 1]
D2motofine = eval.fd(tfine, motofd.4, 2]
Lmotofine  = D2motofine - theta4[2]*motofine - theta4[2]*Dmotofine

figure(3)
subplot(2,2,1]
plot(tfine, motofine,   '-', [impact,impact], [-1.00,1.50], 'b--', 
    [0,60], [0,0], 'r:')
subplot(2,2,2]
plot(tfine, Dmotofine,  '-', [impact,impact], [ -.30, .30], 'b--', 
    [0,60], [0,0], 'r:')
subplot(2,2,3)
plot(tfine, D2motofine, '-', [impact,impact], [ -.10, .10], 'b--', 
    [0,60], [0,0], 'r:')
subplot(2,2,4)
plot(tfine, Lmotofine,  '-', [impact,impact], [ -.10, .10], 'b--', 
    [0,60], [0,0], 'r:')

