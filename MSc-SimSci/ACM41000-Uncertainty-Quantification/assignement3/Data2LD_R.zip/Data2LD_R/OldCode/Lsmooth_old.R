Lsmooth <- function(yList, XbasisList, Pvec, BwtList, 
                    AwtList=NULL, UfdList=NULL, loadTensor=FALSE) {
  #  LSMOOTH smooths data using a linear differential operator that dep}s
  #  on unknown parameters in list arrays BWTLIST and AWTLIST.  
  #  The coefficients defining the smoothing function are functions of the 
  #  unknown parameters in a parameter cascade.  
  #  The inner optimization is achieved by a call to function SMOOTH.BASIS 
  #  using a functional parameter object defined by the parameters.
  #
  #  The highest order of derivative can vary from one equation to another,
  #  and in particular can be larger than 1.
  #  Each right side may contain contributions from all variables in the
  #  equation.  Morever, these contributions may be from all permissible
  #  derivatives of each equation, wher "permissible" means up to one less 
  #  than the highest order in the variable.
  #  In addition, each equation may be forced by a number of forcing terms
  #  that can vary from equation to equation.
  #  The linear differential equation is of the form
  #      D^m x.i = sum.k^d sum.j^{m.k} beta.{kj} D^{j-1} x.k + 
  #                sum.{\ell}^{M.i} \alpha.{\ell,i} u.{\ell,i}, 
  #      i in 1,...,d
  #  where
  #  and where each coefficient is expanded in terms of its own number of
  #  B-spline basis functions:
  #      \beta.{ij}(t)      = \bbold.{ij}'     \phibold.{ij}(t),
  #      \alpha.{\ell,i}(t) = \abold.{\ell,i}' \psibold.{\ell,i}(t)
  #
  #  This version approximates the integrals in the penalty terms by using 
  #  inprod.basis to compute the cross-product matrices for the  
  #  \beta-coefficient basis functions and the corresponding derivative of 
  #  the x-basis functions,and the cross-product matrices for the 
  #  \alpha-coefficients and the corresponding U functions.  
  #  These are computed upon the first call to Lsmooth4, and then retained 
  #  for subsequent calls by using the persistent command.  See lines about 
  #  560 to 590 for this code.
  #
  #  Arguments:
  #
  #  YLIST     ... A list array of length NVAR.  Each list contains in turn
  #                a struct object with fields:
  #                  "argvals" is a vector of length n.i of observation times
  #                  "y" contains a matrix with n.i rows and NREP columns.
  #                The number of columns must be the same for all variables,
  #                except tat, if (a list is empty, that variable is taken to 
  #                be not observed.
  #
  #  XBASISLIST... A list aray of length NVAR. Each list contain a 
  #                functional data object or a BASIS object.  The numbers
  #                and nature of the bases in these objects may vary from
  #                variable to variable.              
  #
  #  PVEC      ... A vector of length NVAR containing values in [0,1].  
  #                The data sums of squares are weighted by P and 
  #                the roughness penalty by 1-P.
  #
  #  BWTLIST   ... A NVAR by NVAR list array.  
  #                Each list entry BwtList{i,j} may contain a list array of 
  #                length NDERIV.i containing fdPar objects for the 
  #                coefficient functions in the autonomous linear 
  #                differential operator.  If not, it must be empty.
  #                Empty entries in BwtList correspond to contributions to
  #                the model for that row's equation that are not present in
  #                model.
  #                The length of a list in any entry BwtList{i,j} is the 
  #                order of the equation, that is, if (the list is length m, 
  #                the left side of the equation is D^m x.  Consequently,
  #                the lengths of all lists within any column of BwtList
  #                must be the same, or any list is empty, all others in 
  #                that column must also be empty.  
  #                The kth list BwtList{i,j}{k} of list array BwtList{i,j} 
  #                may contain a functional parameter object of the fdPar 
  #                class, specifying the weight coefficint \beta.{ijk}(t) 
  #                for the derivative of order k-1 of variable j in the 
  #                ith equation.  
  #                If the list does not contain an fdPar object, then it 
  #                must beempty, and corresponds to a missing contribution 
  #                from variable j to the ith equation.  
  #                If the "estimate" field of the fdPar object is nonzero, 
  #                the coefficients are estimated but, if (zero, they are 
  #                held constant.  
  #
  #  AWTLIST   ... A list array of length NVAR, each list of which contains
  #                in turn a list array length NFORCE.i, where NORCE.i is 
  #                the number of forcing functions for variable i.  
  #                Each list Awtlist{i}{\ell} of which
  #                contains fdPar objects for each coefficient function
  #                \alpha.{\ell,i}, 
  #
  #  UFDLIST   ... A list array of length NVAR, each list of which in turn
  #                contains a list array of length NFORCE.I each list of 
  #                which in turn contains a functional data object with 
  #                either:
  #                   NREP replications for the forcing functions u.{\ell,i}
  #                or
  #                   one replication, in which it is assumed that this
  #                   forcing function is common to all replications.
  #
  #  LOAD.TENSOR ... If nonzero, attempt to load the list arrays
  #                BtensorList, BAtensorList and AtensorList.  These must
  #                have set up before any call to Lsmooth and saves as 
  #                .mat files with names BtensorList.mat, BAtensorList.mat
  #                and AtensorList.mat.  
  #                For information on how these are set up, see the functions 
  #                Btensorfn, BAtensorfn and Atensorfn.
  
  #  Last modified 11 June 2015
  
  #  ------------------------------------------------------------------------
  #                         Set up analysis
  #  ------------------------------------------------------------------------
  
  #  persistent BtensorList BAtensorList AtensorList basismatList
  
  #  ------------------------------------------------------------------------
  #       Check BwtList and extract information about the system from it
  #  ------------------------------------------------------------------------
  
  if (!is.list(BwtList)) {
    stop('BWTLIST is not a list array.')
  }
  
  nvar = dim(BwtList)[1]
  
  #  check structure of BwtList and set up vector of derivative orders
  
  nderivvec = BwtListCheck(BwtList)
  
  #    Check AwtList and extract vector of numbers of forcing functions
  
  if (!is.null(AwtList)) {
    nforce = AwtListCheck(AwtList,nvar)
  } else { 
    nforce = 0
  }
  
  #  ------------------------------------------------------------------------
  #  Construct list array allKeyList for both fixed and estimated parameter 
  #  vectors in the the homogeneous forcing terms of the equations.
  #  Also construct estKeyList for just the estimated parameter vectors,
  #  which are numbered by equation and sequentially within equations
  #  Each list in the key list array list [[1]] contains a matrix with four  
  #      columns:  for {ix}, for [[jx]], vector length, and position in the 
  #      parameter vector of the first coefficient in the coefficient vector.
  #  Each list in the key list array list [[2]] contains a matrix with three  
  #      columns:  for [[jforce]], vector length, and position in the
  #      parameter vector of the first coefficient in the coefficient vector.
  #  ------------------------------------------------------------------------
  
  allKeyList = list(nvar,2)
  estKeyList = list(nvar,2)
  npar2 = 0
  for (ivar in 1:nvar) {
    allMatH = NULL
    estMatH = NULL
    for (ix in 1:nvar) {
      for (jx in 1:nderivvec[ix]) {
        WfdParx  = BwtList[[ivar,ix]][[jx]]
        if (!is.null(WfdParx)) {
          nbasisx = getnbasis(getbasis(getfd(WfdParx)))
          allMatH  = c(allMatH, c(ix,jx,nbasisx))
          if (WfdParx$estimate) {
            npar1 = npar2 + 1
            npar2 = npar2 + nbasisx
            estMatH  = c(estMatH, c(ix,jx,nbasisx, npar1))
          }
        }
      }
    }
  }
  allKeyList[[ivar,1]] = allMatH
  estKeyList[[ivar,1]] = estMatH
  if (!is.null(AwtList) && !is.null(AwtList[[ivar]])) {
    allMatF = NULL
    estMatF = NULL
    for (jforce in 1:nforce[ivar]) {
      AfdParj = AwtList[[ivar]][[jforce]]
      if (!is.null(AfdParj)) {
        nbasisj = AfdParj$fd$basis$nbasis
        allMatF = c(allMatF, c(jforce, nbasisj))
        if (AfdParj$estimate) {
          npar1 = npar2 + 1
          npar2 = npar2 + nbasisj
          estMatF = c(estMatF, c(jforce, nbasisj, npar1))
        }
      }
    }
    allKeyList[[ivar,2]] = allMatF
    estKeyList[[ivar,2]] = estMatF
  }
  
  #  Display structures of equations
  
  if (is.null(BtensorList)) {
    for (ivar in 1:nvar) {
      cat(' ')
      cat('---------  Homogeneous KeyList matrices for variable ', ivar,':')
      cat('  (var index, deriv. index, no. basis fns., starting pos.)')
      cat('Active coefficient functions:')
      cat(num2str(allKeyList[[ivar,1]]))
      if (!is.null(estKeyList[[ivar,1]])) {
        cat('Estimated homogeneous coefficient functions:')
        cat(num2str(estKeyList[[ivar,1]]))
      }
    }
  }
  
  if (is.null(BAtensorList) && !is.null(AwtList) && !is.null(UfdList)) {
    for (ivar in 1:nvar) {
      cat(' ')
      cat('---------  Forcing KeyList matrices for variable ',ivar,':')
      cat('  (var index, no. basis fns., start pos.)')
      cat('Active forcing coefficient functions:')
      if (!is.null(allKeyList[[ivar,2]])) {
        cat(num2str(allKeyList[[ivar,2]]))
        cat('Estimated forcing coefficient functions:')
        cat('\n')
        if (!is.null(estKeyList[[ivar,2]])) {
          cat(num2str(estKeyList[[ivar,2]]))
        } else {
          cat('None\n')
        }
      } else {
        cat('None')
      }
    }
  }
  
  #  ------------------------------------------------------------------------
  #                        Check YLIST
  #  ------------------------------------------------------------------------
  
  yList   = yListcheck(yList, nvar)
  nrep    = yList$nrep
  nvec    = yList$nvec
  dataWrd = yList$dataWrd
  
  #  ------------------------------------------------------------------------
  #                        Check XBASISLIST
  #  ------------------------------------------------------------------------
  
  #  Retrieve basis object for each variable from XBASISLIST and install it
  #  in Xbasis List.
  #  And set up a vector NCOEFVEC containing number of coefficients used
  #  for the expansion of each variable
  
  if (!is.list(XbasisList)) {
    stop('XBASISLIST is not a list array.')
  }
  
  if (length(XbasisList) != nvar) {
    stop('XBASISLIST is not of length NVAR.')
  }
  
  errwrd = 0
  ncoefvec = matrix(0,nvar,1)
  for (ivar in 1:nvar) {
    Xbasisi = XbasisList[[ivar]]
    if (!isa.basis(Xbasisi)) {
      warning(paste('XBASIS is not a BASIS object for variable ',ivar,'.'))
      errwrd = 1
    } else {
      ncoefvec[ivar] = Xbasisi$nbasis
      XbasisList[[ivar]] = Xbasisi
    }
  }
  if (errwrd) {
    stop('One or more terminal stop encountered in XBASISLIST.')
  }
  
  #  get the width of the time domain
  
  Xrange = XbasisList[[1]]$rangeval
  T      = Xrange[2] - Xrange[2]
  
  #  ------------------------------------------------------------------------
  #                        check UfdList
  #  ------------------------------------------------------------------------
  
  if (!is.null(UfdList)) {
    if (!is.list(UfdList)) {
      stop('UFDLIST is not a list array.')
    }
    errwrd = 0
    for (ivar in 1:nvar) {
      if (!is.null(UfdList[[ivar]])) {
        UfdListi = UfdList[[ivar]]
        if (!is.list(UfdListi)) {
          warning(paste('UFDLIST[[',ivar,']] is not a list array.'))
        }
        ndimi = dim(UfdListi)
        nrowi = ndimi[1]
        ncoli = ndimi[2]
        if (nrowi != nforce[ivar]) {
          warning(paste('AWTLIST and UFDLIST are not the ', 
                        'same length for variable ',num2str[ivar],'.'))
          errwrd = 1
        }
        for (jforce in 1:nforce[ivar]) {
          Ufdij   = UfdListi[[jforce]]
          Ucoefij = Ufdij$coef
          if (dim(Ucoefij)[2] != nrep) {
            warning(paste('UFDLIST does not have NREP columns ', 
                          'for variable ',ivar,'.'))
            cat(paste(dim(Ucoefij)[2], nrep))
            cat('\n')
            errwrd = 1
          }
        }
      }
    }
    if (errwrd) {
      stop('One or more terminal stop encountered in UFDLIST.')
    }
  }
  
  #  compute nthetaL and ntheta
  
  nthetaL = 0
  ntheta  = 0
  for (ivar in 1:nvar) {
    for (iv in 1:nvar) {
      for (jv in 1:nderivvec[iv]) {
        WfdParv = BwtList[[ivar,iv]][[jv]]
        if (!is.null(WfdParv)) {
          estimatev = WfdParv$estimate
          if (estimatev) {
            nWbasisv = WfdParv$fd$basis$nbasis
            nthetaL  = nthetaL + nWbasisv
            ntheta   = ntheta  + nWbasisv
          }
        }
      }
    }
    if (!is.null(UfdList) && !is.null(AwtList)) {
      if (!is.null(UfdList[[ivar]]) && !is.null(AwtList[[ivar]])) {
        for (jforce in 1:nforce[ivar]) {
          AfdParj = AwtList[[ivar]][[jforce]]
          if (!is.null(AfdParj)) {
            estimatej = AfdParj$estimate
            if (estimatej) {
              nAbasisj = AfdParj$fd$basis$nbasis
              ntheta   = ntheta + nAbasisj
            }
          }
        }
      }
    }
  }
  
  #  check Pvec
  
  if (length(Pvec) != nvar) {
    stop('PVEC not of length NVAR.')
  }
  for (ivar in 1:nvar) {
    if (Pvec[ivar] > 1 || Pvec[ivar] < 0) {
      stop(paste('P is not in [0,1] for variable ',ivar,'.'))
    }
  }
  
  #  set up list array for matrices of basis function values
  
  basismatList = list(nvar,1)
  for (ivar in 1:nvar) {
    if (!is.null(yList[[ivar]])) {
      yStructi  = yList[[ivar]]
      Xbasisi   = XbasisList[[ivar]]
      basismati = eval.basis(yStructi.argvals, Xbasisi)
      basismatList[[ivar]] = basismati
    }
  }
  
  #  ------------------------------------------------------------------------
  #  Compute crossproduct matrices for tensor products of 
  #  D^j X-basis functions and W-basis functions, j in 0,...,nderivvec 
  #  if (not already set up
  #  ------------------------------------------------------------------------
  
  # if (is.null(BtensorList)) {
  #   if (loadTensor) {
  #     load BtensorList
  #     BtensorListcheck(BtensorList, BwtList)
  #   } else {
  #     tic
  #     BtensorList = Btensorfn(XbasisList, BwtList)
  #     toc
  #     save BtensorList BtensorList
  #   }
  # }
  # 
  # if (!is.null(AwtList) && is.null(BAtensorList) && sum(nforce) > 0) {
  #   if (loadTensor) {
  #     load BAtensorList
  #     BAtensorListcheck(BAtensorList, BwtList, AwtList)
  #   } else {
  #     tic
  #     BAtensorList = BAtensorfn(XbasisList, UfdList, BwtList, AwtList)
  #     toc
  #     save BAtensorList BAtensorList
  #   }
  # }
  # 
  # if (!is.null(AwtList) && is.null(AtensorList) && sum(nforce) > 0) {
  #   if (loadTensor) {
  #     load AtensorList
  #     AtensorListcheck(AtensorList, AwtList)
  #   } else {
  #     tic
  #     AtensorList = Atensorfn(UfdList, AwtList)
  #     toc
  #     save AtensorList AtensorList
  #   }
  # }
  
  #  ------------------------------------------------------------------------
  #                  Compute coefficient matrix Bmat
  #  ------------------------------------------------------------------------
  
  nsum     = sum(nvec)
  ncoefsum = sum(ncoefvec)
  Bmat     = matrix(0,ncoefsum,ncoefsum)
  basismat = matrix(0,nsum,ncoefsum)
  ymat     = matrix(0,nsum,nrep)
  m2 = 0
  n2 = 0
  for (ivar in 1:nvar) {
    m1  = m2 + 1
    m2  = m2 + ncoefvec[ivar]
    ind = m1:m2
    if (dataWrd[ivar]) {
      n1   = n2 + 1
      n2   = n2 + nvec[ivar]
      indn = n1:n2
      yStructi   = yList[[ivar]]
      ymat[indn,] = yStructi$y
      basismati  = basismatList[[ivar]]
      Bmat[ind,ind] = (1-Pvec[ivar])*crossprod(basismati)/nvec[ivar]
      basismat[indn,ind] = basismati
    }
  }
  
  #  ------------------------------------------------------------------------
  #                  Compute penalty matrix Rmat(theta)
  #  ------------------------------------------------------------------------
  
  Rmat = matrix(0,ncoefsum,ncoefsum)
  ncoefcum = cumsum(c(0,ncoefvec))
  
  m2 = 0
  for (ivar in 1:nvar) {
    m1  = m2 + 1
    m2  = m2 + ncoefvec[ivar]
    ind = m1:m2
    #  compute first term in expansion, crossproduct of D^m with itself
    nXbasisi = ncoefvec[ivar]
    nderivi  = nderivvec[ivar]
    Btensii  = BtensorList[[ivar]][[ivar,ivar]][[nderivi+1,nderivi+1]]
    Rmatii   = inprodvx(nXbasisi, 1, nXbasisi, 1, 1, 1, Btensii)
    Rmatii   = Pvec[ivar]*Rmatii/T
    Rmat[ind,ind] = Rmat[ind,ind] + Rmatii
    #  compute second term in expansion, vector of cross-products with D^m
    allKeyMati = allKeyList[[ivar,1]]
    nWallkey   = dim(allKeyMati)[1]
    #  compute third term in expansion, matrix of cross-products
    for (ivw in 1:nWallkey) {
      iv   = allKeyMati[ivw,1]
      jv   = allKeyMati[ivw,2]
      indv = ncoefcum[iv]+1:ncoefcum[iv+1]
      nXbasisv = ncoefvec[iv]
      Bvecv    = getcoef(BwtList[[ivar,iv]][[jv]])
      nWbasisv = length(Bvecv)
      for (ixw in 1:nWallkey) {
        ix   = allKeyMati[ixw,1]
        jx   = allKeyMati[ixw,2]
        indx = ncoefcum[ix]+1:ncoefcum[ix+1]
        nXbasisx = ncoefvec[ix]
        Bvecx    = BwtList[[ivar,ix]][[jx]]$coef
        nWbasisx = length(Bvecx)
        Btensvx  = BtensorList[[ivar]][[iv,ix]][[jv,jx]]
        Rmatvx = inprodvx(nXbasisv, nWbasisv, nXbasisx, nWbasisx, 
                          Bvecv, Bvecx, Btensvx)
        Rmatvx = Pvec[ivar]*Rmatvx/T
        Rmat[indv,indx] = Rmat[indv,indx] + Rmatvx
      }
      Btensijv = BtensorList[[ivar]][[ivar,iv]][[nderivi+1, jv]]
      Rmativ = inprodvx(nXbasisi, 1, nXbasisv, nWbasisv, 
                        1, Bvecv, Btensijv)
      Rmativ = Pvec[ivar]*Rmativ/T
      Rmat[ind,indv] = Rmat[ind,indv] - Rmativ
      Rmat[indv,ind] = Rmat[indv,ind] - t(Rmativ)
    }
  }
  
  #  ------------------------------------------------------------------------
  #                  Compute coefficient matrix Cmat
  #  ------------------------------------------------------------------------
  
  Cmat = Bmat + Rmat
  
  #  ------------------------------------------------------------------------
  #                     Set up right side of equation
  #  ------------------------------------------------------------------------
  
  Dmat = matrix(0,ncoefsum,nrep)
  m2 = 0
  for (ivar in 1:nvar) {
    m1  = m2 + 1
    m2  = m2 + ncoefvec[ivar]
    ind = m1:m2
    if (dataWrd[ivar]) {
      yStructi = yList[[ivar]]
      basismati = basismatList[[ivar]]
      yi = yStructi.y
      ni = nvec[ivar]
      Dmat[ind,] = (1-Pvec[ivar])*t(basismati) %*% yi/ni
    }
  }
  
  #--------------------------------------------------------------------------
  #                 Compute the penalty vector S(theta)
  #--------------------------------------------------------------------------
  
  if (!is.null(AwtList) && !is.null(UfdList)) {
    Smat = matrix(0,ncoefsum,nrep)
    m2 = 0
    for (ivar in 1:nvar) {
      m1  = m2 + 1
      m2  = m2 + ncoefvec[ivar]
      ind = m1:m2
      if (!is.null(AwtList[[ivar]]) && !is.null(UfdList[[ivar]])) {
        nXbasisi = ncoefvec[ivar]
        nderivi  = nderivvec[ivar]
        allKeyMati1 = allKeyList[[ivar,1]]
        allKeyMati2 = allKeyList[[ivar,2]]
        nWkey = dim(allKeyMati1)[1]
        nAkey = dim(allKeyMati2)[2]
        for (jforce in 1:nAkey) {
          ja = allKeyMati2[jforce,1]
          Avecj    = AwtList[[ivar]][[ja]]$coef
          Ufdj     = UfdList[[ivar]][[ja]]
          Ubasisj  = Ufdj$basis$
          Ucoefj   = Ufdj$coef
          nUbasisj = Ubasisj$nbasis
          nAbasisj = length(Avecj)
          #  Crossproducts of homogeneous terms with forcing terms
          for (iw in 1:nWkey) {
            ix         = allKeyMati1[iw,1]
            jx         = allKeyMati1[iw,2]
            indx       = ncoefcum[ix]+1:ncoefcum[ix+1]
            nXbasisx   = ncoefvec[ix]
            Bvecx      = getcoef(BwtList[[ivar,ix]][[jx]])
            nWbasisx   = length(Bvecx)
            BAtensxw   = BAtensorList[[ivar,ix]][[ja,jx]]
            Smatr = inprodijx(nXbasisx, nWbasisx, 
                              nUbasisj, nAbasisj, nrep, 
                              Bvecx, Avecj, Ucoefj, BAtensxw) 
            Smatr = Pvec[ivar]*Smatr/T
            Smat[indx,] = Smat[indx,] + Smatr
          }
          #  Crossproducts of D^m with forcing terms
          BAtensxj = BAtensorList[[ivar,ivar]][[ja,nderivi+1]]
          Smatr = inprodijx(nXbasisi, 1, 
                            nUbasisj, nAbasisj, nrep, 
                            1, Avecj, Ucoefj, BAtensxj) 
          Smatr = Pvec[ivar]*Smatr/T
          Smat[ind,] = Smat[ind,] - Smatr
        }
      }
    }
  } else {
    Smat = NULL
  }
  
  
  #  ------------------------------------------------------------------------
  #                  Compute coefficient matrix
  #  ------------------------------------------------------------------------
  
  if (is.null(Smat)) {
    coef = ls(Cmat,Dmat)
  } else {
    coef = ls(Cmat,Dmat-Smat)
  }
  
  #  ------------------------------------------------------------------------
  #                     Compute summary values
  #  ------------------------------------------------------------------------
  
  y2cFac = t(basismat)
  m2 = 0
  n2 = 0
  for (ivar in 1:nvar) {
    m1  = m2 + 1
    m2  = m2 + ncoefvec[ivar]
    ind = m1:m2
    if (dataWrd[ivar]) {
      n1   = n2 + 1
      n2   = n2 + nvec[ivar]
      indn = n1:n2
      y2cFac[ind,indn] = (1-Pvec[ivar])*y2cFac[ind,indn]/nvec[ivar]
    }
  }
  y2cMap = basismat %*% ls(Cmat,y2cFac)
  df = sum(diag(2*y2cMap - y2cMap %*% t(y2cMap)))
  
  #  set up the functional data object for the output smooth of the data 
  
  XfdParList = vector("list",nvar)
  m2 = 0
  for (ivar in 1:nvar) {
    m1  = m2 + 1
    m2  = m2 + ncoefvec[ivar]
    ind = m1:m2
    Xbasisi = XbasisList[[ivar]]
    Xfdobji = fd(coef[ind,],Xbasisi)
    XfdParList[[ivar]] = fdPar(Xfdobji)
  }
  
  #  ------------------------------------------------------------------------
  #  Compute unpenalized stop sum of squares, SSE, the outer objective fn.
  #  loop through number of replications NREP.
  #  SSE is normalized by dividing by NREP and by the sum of the n.i's.
  #  ------------------------------------------------------------------------
  
  xmat = basismat*coef
  
  SSE  = matrix(0,nvar,1)
  SSEtot = 0
  m2 = 0
  for (ivar in 1:nvar) {
    if (dataWrd[ivar]) {
      m1 = m2 + 1
      m2 = m2 + nvec[ivar]
      xmati = xmat[m1:m2,]
      ymati = yList[[ivar]]$y
      rmati = ymati - xmati
      SSEi  = sum(sum(rmati^2))
      SSE[ivar]  = SSEi/nrep/nsum
      SSEtot = SSEtot + SSEi
    } else {
      SSE[ivar] = NULL
    }
  }
  
  #  compute GCV
  
  if (df < nsum) {
    gcv = (SSEtot/nsum)/((nsum - df)/nsum)^2
  } else {
    gcv = NULL
  }
  
  
  #  ------------------------------------------------------------------------
  #  Compute unpenalized stop integrated squares, ISE, the penalty term
  #  loop through number of replications NREP
  #  ------------------------------------------------------------------------
  
  ISE1 = 0
  ISE2 = 0
  ISE3 = 0
  for (irep in 1:nrep) {
    ISE1i = 0
    ISE2i = 0
    ISE3i = 0
    coefi = coef[,irep]
    for (ivar in 1:nvar) {
      ISE1i = ISE1i + t(coefi) %*% Rmat %*% coefi
      if (!is.null(AwtList)       && !is.null(UfdList) && 
          !is.null(UfdList[[ivar]]) && !is.null(AwtList[[ivar]])) {
        ISE2i = ISE2i + 2*t(coefi) %*% Smat[,irep]
        nforcei  = length(AwtList[[ivar]])
        for (jforce in 1:nforcei) {
          AfdParj = AwtList[[ivar]][[jforce]]
          if (!is.null(AfdParj)) {
            Avecj    = AwtList[[ivar]][[jforce]]$coef
            nAbasisj = length(Avecj)
            Ufdj     = UfdList[[ivar]][[jforce]]
            Ubasisj  = Ufdj$basis
            Ucoefj   = Ufdj$coef
            nUbasisj = Ubasisj$nbasis
            for (kforce in 1:nforcei) {
              AfdPark = AwtList[[ivar]][[kforce]]
              if (!is.null(AfdPark)) {
                Aveck    = getcoef(AwtList[[ivar]][[kforce]])
                nAbasisk = length(Aveck)
                Ufdk     = UfdList[[ivar]][[kforce]]
                Ubasisk  = Ufdk$basis
                Ucoefk   = Ufdk$coef
                nUbasisk = Ubasisk$nbasis
                Atensijk = 
                  AtensorList[[ivar]][[jforce,kforce]]
                ncum = cumprod(c(nAbasisk, nUbasisk, 
                                 nAbasisj, nUbasisj))
                for (i in 1:nUbasisj) {
                  for (j in 1:nAbasisj) {
                    for (k in 1:nUbasisk) {
                      for (l in 1:nAbasisk) {
                        ijkl = (i-1)*ncum(3) + 
                          (j-1)*ncum[2] + 
                          (k-1)*ncum[1] + l
                        ISE3i = ISE3i + Pvec[ivar]* 
                          Ucoefj(i,irep)* 
                          Avecj[j]*       
                          Ucoefk(k,irep)* 
                          Aveck[l]*       
                          Atensijk[ijkl]/T
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    #     cat(ISEi)
    ISE1 = ISE1 + ISE1i
    ISE2 = ISE2 + ISE2i
    ISE3 = ISE3 + ISE3i
  }
  ISE1 = ISE1/nrep
  ISE2 = ISE2/nrep
  ISE3 = ISE3/nrep
  ISE = ISE1 + ISE2 + ISE3
  
  #  ------------------------------------------------------------------------
  #  Compute partial derivatives of R with respect to theta 
  #  in parvec(1:nthetaL)
  #  ------------------------------------------------------------------------
  
  DRarray = array(0,c(ncoefsum,ncoefsum,ntheta))
  m2 = 0
  for (ivar in 1:nvar) {
    m1  = m2 + 1
    m2  = m2 + ncoefvec[ivar]
    ind = m1:m2
    nderivi    = nderivvec[ivar]
    nXbasisi   = ncoefvec[ivar]
    nWallkey   = dim(allKeyMati)[1]
    #  select only active coefficients requiring estimation
    estKeyMati = estKeyList[[ivar,1]]
    nWestkey   = dim(estKeyMati)[1]
    #  select all active coefficients
    allKeyMati = allKeyList[[ivar,1]]
    #  loop through active variables within equation ivar 
    #  whose coefficient require estimation
    for (ivw in 1:nWestkey) {
      #  define coefficient of estimated variable and 
      #  it's derivative index
      iv       = estKeyMati[ivw,1]
      jv       = estKeyMati[ivw,2]
      #  the indices of the basis function coefficients for this variable
      indv     = ncoefcum[iv]+1:ncoefcum[iv+1]
      nXbasisv = ncoefvec[iv]       #  number of path basis functions
      nWbasisv = estKeyMati[ivw,3]  #  number of coefficient basis fns.
      npariv1  = estKeyMati[ivw,4]  # starting index in vector theta
      npariv2  = npariv1 + nWbasisv - 1   #  }ing index
      indthv   = npariv1:npariv2  # vector of index values
      #  loop through all active variables within equation ivar
      for (ixw in 1:nWallkey) {
        #  define coefficient of active variable and 
        #  it's derivative index
        ix   = allKeyMati[ixw,1]
        jx   = allKeyMati[ixw,2]
        indx = ncoefcum[ix]+1:ncoefcum[ix+1]
        nXbasisx  = ncoefvec[ix]
        Bvecx     = getcoef(BwtList[[ivar,ix]][[jx]])
        nWbasisx  = length(Bvecx)
        #  get the tensor vector for this pair of coefficients
        #  and derivatives
        Btensvx   = BtensorList[[ivar]][[iv,ix]][[jv,jx]]
        #  compute inner product with respect to the ix dimension
        DRarrayvx = 
          inprodix(nXbasisv, nWbasisv, nXbasisx, nWbasisx, 
                   Bvecx, Btensvx)
        #  rescale the inner product
        DRarrayvx = Pvec[ivar]*DRarrayvx/T
        #  increment the inner product and its transpose for 
        #  the appropriate location in DRarray
        if (iv == ix && jv == jx) {
          DRarray[indv,indv,indthv] = DRarray[indv,indv,indthv] + 
            2*DRarrayvx
        } else {
          DRarray[indv,indx,indthv] = DRarray[indv,indx,indthv] + 
            DRarrayvx
          DRarray[indx,indv,indthv] = DRarray[indx,indv,indthv] + 
            permute(DRarrayvx,c(2,1,3))
        }
      }
      #  partial derivatives wrt Wcoef for cross-products with D^m
      #  here x = ivar, Wbasisx is the constant basis, and 
      #  Bvecx = 1
      #  get the tensor vector for this pair of coefficients
      #  and derivatives
      Btensvi  = BtensorList[[ivar]][[iv,ivar]][[jv,nderivi+1]]
      #  compute inner product with respect to the ix dimension
      DRarrayvi = array(0,c(nXbasisv, nXbasisi, nWbasisv))
      ncum = cumprod(c(1, nXbasisi, nWbasisv, nXbasisv))
      for (i in 1:nXbasisv) {
        for (j in 1:nWbasisv) {
          for (k in 1:nXbasisi) {
            for (l in 1) {
              ijkl = (i-1)*ncum(3) + 
                (j-1)*ncum[2] + 
                (k-1)*ncum[1] + l
              DRarrayvi[i,k,j] = DRarrayvi[i,k,j] + 
                Btensvi[ijkl]
            }
          } 
        }
      }
      #  rescale the inner product
      DRarrayvi = Pvec[ivar]*DRarrayvi/T
      #  decrement the inner product and its transpose for 
      # the appropriate location in DRarray
      if (nWbasisv == 1) {
        DRarray[ind,indv,indthv] = DRarray[ind,indv,indthv] - 
          t(DRarrayvi)
        DRarray[indv,ind,indthv] = DRarray[indv,ind,indthv] - 
          DRarrayvi
      } else {
        DRarrayvit = permute(DRarrayvi,c(2,1,3))
        DRarray[ind,indv,indthv] = DRarray[ind,indv,indthv] - 
          DRarrayvi
        DRarray[indv,ind,indthv] = DRarray[indv,ind,indthv] - 
          DRarrayvit
      }
    }
  }
  
  #  ------------------------------------------------------------------------
  #  Compute partial derivatives of Smat if (required with respect to theta 
  #  in parvec(1:nthetaL)
  #  ------------------------------------------------------------------------
  
  if (!is.null(AwtList) && !is.null(UfdList)) {
    DSarray = array(0,c(ncoefsum,nrep,ntheta))
    m2 = 0
    for (ivar in 1:nvar) {
      m1  = m2 + 1
      m2  = m2 + ncoefvec[ivar]
      ind = m1:m2
      if (!is.null(AwtList[[ivar]]) && !is.null(UfdList[[ivar]])) {
        nXbasisi    = ncoefvec[ivar]
        nderivi     = nderivvec[ivar]
        allKeyMati1 = allKeyList[[ivar,1]]
        allKeyMati2 = allKeyList[[ivar,2]]
        estKeyMati1 = estKeyList[[ivar,1]]
        estKeyMati2 = estKeyList[[ivar,2]]
        nWestkey    = dim(estKeyMati1)[1]
        nAallkey    = dim(allKeyMati2)[1]
        nAestkey    = dim(estKeyMati2)[1]
        #  partial derivatives of product of homogeneous terms
        #  and forcing terms with respect to homogeneous coefficients
        #  loop through all active forcing terms
        for (jforce in 1:nAallkey) {
          ja       = allKeyMati2[jforce,1]
          Avecj    = getcoef(AwtList[[ivar]][[ja]])
          nAbasisj = length(Avecj)
          Ufdj     = UfdList[[ivar]][[ja]]
          Ucoefj   = Ufdj$coef
          Ubasisj  = Ufdj$basis
          nUbasisj = Ubasisj$nbasis
          #  crossproducts of homogeneous terms with forcing terms
          for (iw in 1:nWestkey) {
            ix       = estKeyMati1[iw,1]
            jx       = estKeyMati1[iw,2]
            indx     = ncoefcum[ix]+1:ncoefcum[ix+1]
            nWbasisx = estKeyMati1[iw,3]
            npariv1  = estKeyMati1[iw,4]
            npariv2  = npariv1 + nWbasisx - 1
            indthw   = npariv1:npariv2
            nXbasisx = ncoefvec[ix]
            BAtensxj = BAtensorList[[ivar,ix]][[ja,jx]]
            DBSmatr  = inprodxj(nXbasisx, nWbasisx, 
                                nUbasisj, nAbasisj, 
                                nrep, Avecj, Ucoefj, BAtensxj)
            DBSmatr = Pvec[ivar]*DBSmatr/T
            DSarray[indx,,indthw] = DSarray[indx,,indthw] + 
              DBSmatr
          }
        }
        #  partial derivatives wrt forcing term coefficients for
        #  those forcing terms requiring estimation of their
        #  coefficients
        #  loop through all forcing terms with coefficients to be
        #  estimated
        for (jw in 1:nAestkey) {
          ja = estKeyMati2[jw,1]
          nAbasisj = estKeyMati2[jw,2]
          nparia1  = estKeyMati2[jw,3]
          nparia2  = nparia1 + nAbasisj - 1
          indtha   = nparia1:nparia2
          nWallkey = dim(allKeyMati1)[1]
          #  partial derivatives of products of homogeneous terms
          #  with forcing terms with respect to forcing coefficients
          for (iw in 1:nWallkey) {
            ix       = allKeyMati1[iw,1]
            jx       = allKeyMati1[iw,2]
            indx     = ncoefcum[ix]+1:ncoefcum[ix+1]
            nXbasisx = ncoefvec[ix]
            Bvecx    = getcoef(BwtList[[ivar,ix]][[jx]])
            nWbasisx = length(Bvecx)
            BAtensxj = BAtensorList[[ivar,ix]][[ja,jx]]
            DASmatr  = inprodjx(nXbasisx, nWbasisx, 
                                nUbasisj, nAbasisj, 
                                nrep, Bvecx, Ucoefj, BAtensxj)               
            DASmatr = Pvec[ivar]*DASmatr/T
            DSarray[indx,,indtha] = DSarray[indx,,indtha] + DASmatr
          }
          #  partial derivatives of cross-products of D^m 
          #  with forcing terms with respect to forcing coefficients
          BAtensxj = BAtensorList[[ivar,ivar]][[ja,nderivi+1]]
          DASmatr  = inprodjx(nXbasisi, 1, 
                              nUbasisj, nAbasisj, 
                              nrep, 1, Ucoefj, BAtensxj)               
          DASmatr = Pvec[ivar]*DASmatr/T
          DSarray[ind,,indtha] = DSarray[ind,,indtha] - DASmatr
        }
      }
    }
  } else {
    DSarray = NULL
  }
  
  #  ---------  Compute the total derivative  ----------------
  
  #  Compute dc/dtheta
  
  ymat = NULL
  for (ivar in 1:nvar) {
    if (dataWrd[ivar]) {
      yStructi   = yList[[ivar]]
      ymat = rbind(ymat, yStructi$y)
    } 
  }
  
  Cmatinv = inv(Cmat)
  
  Dcoef = array(0,c(ncoefsum,ntheta,nrep))
  for (itheta in 1:ntheta) {
    DRmati = DRarray[,,itheta]
    for (irep in 1:nrep) {
      DRi = -DRmati*coef[,irep]
      if (!is.null(AwtList) && !is.null(UfdList)) {
        DSi = DSarray[,irep,itheta]
        Dcoef[,itheta,irep] = Cmatinv %*% (DRi - DSi)
      } else {
        Dcoef[,itheta,irep] = Cmatinv %*% DRi
      }
    }
  }
  
  # total theta-gradient of SSE using implicit function theorem
  
  xmat = basismat*coef
  DSSE  = matrix(0,1,ntheta)
  D2SSE = matrix(0,ntheta)
  
  m2 = 0
  for (ivar in 1:nvar) {
    if (dataWrd[ivar]) {
      m1 = m2 + 1
      m2 = m2 + nvec[ivar]
      basismati = basismat[m1:m2,]
      xmati     = xmat[m1:m2,]
      ymati     = yList[[ivar]]$y
      rmati     = ymati - xmati
      Bmati     = crossprod(basismati)
      for (irep in 1:nrep) {
        Dcoefi = Dcoef[,,irep]
        DSSE  = DSSE  - 2*t(rmati[,irep]) %*% basismati %*% Dcoefi
        D2SSE = D2SSE + 2*t(Dcoefi) %*% Bmati %*% Dcoefi
      }
    }
  }
  
  DSSE  = t(DSSE)/nrep/nsum
  
  D2SSE = D2SSE/nrep/nsum
  
  return(list(SSE=SSE, DSSE=DSSE, D2SSE=D2SSE, XfdParList=XfdParList, ISE=ISE, df=df, 
              gcv=gcv, Rmat=Rmat, Smat=Smat, DRarray=DRarray, DSarray=DSarrat, 
              Cmat=Cmat, coef=coef, Dcoef=Dcoef, y2cMap=y2cMap))
  
}

#  ------------------------------------------------------------------------

inprodix <- function(nXbasisv, nWbasisv, nXbasisx, nWbasisx, Bvecx, Btensvx) {
  DRarrayvx = matrix(0,nXbasisv, nXbasisx, nWbasisv)
  ncum = cumprod(c(nWbasisx, nXbasisx, nWbasisv, nXbasisv))
  for (i in 1:nXbasisv) {
    for (j in 1:nWbasisv) {
      for (k in 1:nXbasisx) {
        for (l in 1:nWbasisx) {
          ijkl = (i-1)*ncum[3] + 
            (j-1)*ncum[2] + 
            (k-1)*ncum[1] + l
          DRarrayvx[i,k,j] = DRarrayvx[i,k,j] + 
            Bvecx[l]*Btensvx[ijkl]
        }
      }
    }
  }
  return(inprodix)
}

#  ------------------------------------------------------------------------

inprodjx <- function(nXbasisx, nWbasisx, nUbasisj, nAbasisj, 
                     nrep, Bvecx, Ucoefj, BAtensxj) {
  ncum = cumprod(c(nAbasisj, nUbasisj, nWbasisx, nXbasisx))
  DASmatr = array(0,c(nXbasisx,nrep,nAbasisj))
  for (irep in 1:nrep) {
    for (i in 1:nXbasisx) {
      for (j in 1:nWbasisx) {
        for (k in 1:nUbasisj) {
          for (l in 1:nAbasisj) {
            ijkl = (i-1)*ncum[3] + 
              (j-1)*ncum[2] + 
              (k-1)*ncum[1] + l
            DASmatr[i,irep,l] = DASmatr[i,irep,l] + 
              Bvecx[j]*BAtensxj[ijkl]* 
              Ucoefj[k,irep]
          }
        }
      }
    }
  }
  return(DASmatr)
}

#  ------------------------------------------------------------------------

inprodxj <- function(nXbasisx, nWbasisx, nUbasisj, nAbasisj, 
                     nrep, Avecj, Ucoefj, BAtensxj) {
  ncum = cumprod(c(nAbasisj, nUbasisj, nWbasisx, nXbasisx))
  DBSmatr = array(0,c(nXbasisx,nrep,nWbasisx))
  # BAtensor = matrix(0,nXbasisx, nWbasisx, nUbasisj, nAbasisj)
  for (irep in 1:nrep) {
    for (i in 1:nXbasisx) {
      for (j in 1:nWbasisx) {
        for (k in 1:nUbasisj) {
          for (l in 1:nAbasisj) {
            ijkl = (i-1)*ncum[3] + 
              (j-1)*ncum[2] + 
              (k-1)*ncum[1] + l
            DBSmatr(i,irep,j) = DBSmatr(i,irep,j) + 
              Avecj[l]*BAtensxj[ijkl]*Ucoefj(k,irep)
          }
        }
      }
    }
  }
  return(DBSmatr)
}

#  ------------------------------------------------------------------------

inprodijx <- function(nXbasisx, nWbasisx, nUbasisj, nAbasisj, 
                      nrep, Bvecx, Avecj, Ucoefj, BAtensxj) {
  ncum = cumprod(c(nAbasisj, nUbasisj, nWbasisx, nXbasisx))
  Smatr = matrix(0,nXbasisx,nrep)
  for (irep in 1:nrep) {
    for (i in 1:nXbasisx) {
      for (j in 1:nWbasisx) {
        for (k in 1:nUbasisj) {
          for (l in 1:nAbasisj) {
            ijkl = (i-1)*ncum[3] + 
              (j-1)*ncum[2] + 
              (k-1)*ncum[1] + l
            Smatr[i,irep] = Smatr[i,irep] + 
              Bvecx[j]*Avecj[l]*BAtensxj[ijkl]* 
              Ucoefj[k,irep]
          }
        }
      }
    }
  }
  return(Smatr)
}

#  ------------------------------------------------------------------------

inprodvx <- function(nXbasisv, nWbasisv, nXbasisx, nWbasisx, 
                     Bvecv, Bvecx, Btensvx) {
  Rmatvx = array(0,c(nXbasisv,nXbasisx))
  ncum   = cumprod(c(nWbasisx, nXbasisx, nWbasisv, nXbasisv))
  for (i in 1:nXbasisv) {
    for (k in 1:nXbasisx) {
      Rmatvx[i,k] = 0
      for (j in 1:nWbasisv) {
        for (l in 1:nWbasisx) {
          ijkl = (i-1)*ncum[3] + 
            (j-1)*ncum[2] + 
            (k-1)*ncum[1] + l
          Rmatvx[i,k] = Rmatvx[i,k] + 
            Btensvx[ijkl]*Bvecv[j]*Bvecx[l]
        }
      }
    }
  }
  return(Rmatvx)
}
