%  ------------------------------------------------------------------------

function DSvec = cruise_1(t, Svec, cruiseCell)
%  Cruise control equation ... simplified version with two variables
%  Last modified 28 June 2015

DSvec = zeros(2,length(t));

% %  speed reaction rate
% cruiseCell{1,1}{1} = putcoef(cruiseCell{1,1}{1}, -1);     
% %  controller-to-speed coefficient
% cruiseCell{1,2}{1} = putcoef(cruiseCell{1,2}{1},  1/4);  
% %  speed-to-controller coefficient
% cruiseCell{2,1}{1} = putcoef(cruiseCell{2,1}{1}, -0.99);  
% %  controller reaction rate
% cruiseCell{2,2}{1} = putcoef(cruiseCell{2,2}{1},  0); 

SStr = cruiseCell{1};
CStr = cruiseCell{2};
SfdS = fd(getcoef(SStr.XCell{1}.WfdPar), getbasis(SStr.XCell{1}.WfdPar));
SfdC = fd(getcoef(SStr.XCell{2}.WfdPar), getbasis(SStr.XCell{2}.WfdPar));
CfdS = fd(getcoef(CStr.XCell{1}.WfdPar), getbasis(CStr.XCell{1}.WfdPar));
CfdC = fd(getcoef(CStr.XCell{2}.WfdPar), getbasis(CStr.XCell{2}.WfdPar));
FfdC = fd(getcoef(CStr.FCell{1}.AfdPar), getbasis(CStr.FCell{1}.AfdPar));
UfdC = CStr.FCell{1}.Ufd;
B11 = eval_fd(t,SfdS);
B12 = eval_fd(t,SfdC);
B21 = eval_fd(t,CfdS);
B22 = eval_fd(t,CfdC);
A21 = eval_fd(t,FfdC);
U21 = eval_fd(t,UfdC);
% disp([[B11,B12];[B21,B22]])
%  speed   equation, forced by control
%  Term 1: speed level
%  Term 2: control forcing
DSvec(1,:) =  B11'.*Svec(1,:) + B12'.*Svec(2,:);
%  control equation, forced by difference between speed and set point 
%  Term 1: forcing from speed
%  Term 2: control level
%  Term 3: forcing from setpoint, with same coef. magnitude as speed
%          forcing, but opposite sign.
DSvec(2,:) =  B21'.*Svec(1,:) + B22'.*Svec(2,:) + A21'.*U21';

%  ------------------------------------------------------------------------

%% Cruise control: A Two-variable Feedback Loop
%
% A driver starts his car and (1) accelerates to the 60 km/h speed limit
% holding on most main streets of Ottawa, (2) reduces speed to 40 km/h in a
% school zone, (3) enters a controlled-access boulevard with an 80 km/h
% limits and finally (4) against enters a typical principal street.
% Operating on a snowy winter morning, the driver takes 8 seconds to reach
% 60 km/h, or 4/30 seconds per unit change in speed.
%
% The speed of the car under acceleration is modelled by a first order
% constant coefficient equation:
%
%% The feedback equations: 
% The two differental equations specifying the feedback model are:
%%
% $$DS(t) = \beta_{11} S(t) + \beta_{12} C(t)$$
%
%%
% $$DC(t) = \beta_{21} S(t) + \beta_{22} C(t) + \alpha_{2} S_0(t)$$
%
% The right side term
% $\beta_{12} C(t)$ 
% in the first equation is the contribution of the control variable
% _C_
% to the change in speed
% _DS_.
% In the second term on the right side the variable
% _S_0_ 
% is the set-point function specifying the target speed, and it is
% called a forcing function.
%
% We can rewrite the equation introducing an explicit coefficient 
% $\alpha$
% as its multiplier to express the equation in a more standard way that we
% will use to set up the problem in code:
%%
% $$DC(t) = \beta_{21} S(t) + \beta_{22} C(t) + \alpha S_0(t)$$
%
% where we understand that $\beta_{21} = -\alpha$.
%
% When the actual speed is below the target, the control variable
% increases, and this forces a proportionate increase in speed. Likewise,
% when the current speed exceeds the target, the control variable
% decreases, and so does the current speed.

% Last modified 26 June 2015

%  add a path to the fda functions

addpath('../fdaM')

%  load results of a previous analysis if required

load cruise_1_pub

%%  Defining the problem
% Set up the time span, a set of observation times, and a fine grid for
% plotting:

T     = 80;  %  seconds
n     = 41;
nfine = 501;
tobs  = linspace(0,T,n)';
tfine = linspace(0,T,nfine)';

%  set up a constant basis over this range;

rng = [0,T];
conbasis  = create_constant_basis(rng);

%% Define XbasisCell containing the basis system for each varible.
% We also have to provide a basis system for each variable that is large
% enough to allow for any required sharp curvature in the solution to the
% differential equation system.  
%
% First we set the order of the B-spline basis to 5 so that the first 
% derivative will be smooth when working with a second order derivative in
% the penalty term.  Then we position knots at 41 positions where we willl
% simulate noisy observations.  We use the same basis for both variables
% and load it into a cell array of length 2.

nXorder = 5;
breaks  = [0:2:20,20,20:2:40,40,40:2:60,60,60:2:80];
nbreaks = length(breaks);
nXbasis = nbreaks + 2;
Xbasis  = create_bspline_basis(rng, nXbasis, nXorder,breaks);

XbasisCell = cell(2,1);
XbasisCell{1} = Xbasis;
XbasisCell{2} = Xbasis;

%% Set up the set-point forcing function.
%  UfdCell is a cell array having the same two-level cellstructure as 
%  AwtCell, but the contents of the cells are functional data objects
%  specifying the external input to the system. If a cell is empty, it is
%  assumed that there is no forcing of the corresponding equation.
%
% The set-point function uses an order 1 step function B-spline basis.  The 
% knots are placed at the points where the set-point changes values.

steporder  = 1;  % step function basis
stepnbasis = 4;  %  four basis functions
stepbasis  = create_bspline_basis(rng, 4, 1, [0,20,40,60,80]);
stepcoef   = [60;40;80;60];  % target speed for each step
SetPtfd    = fd(stepcoef, stepbasis);  % define the set point function

%% Set up cruiseCell
%  The coefficient values used here are for the true system
%  In this version of the model, there are four estimated parameters
%  and one fixed parameter.  The fixed parameter is the coefficent
%  for the controller in the control equation, set to zero to imply
%  a feed back reaction that is proportional speed.

%  S term in S equation
SStrS.variable   = 1;
SStrS.derivative = 0;
SStrS.WfdPar     = fdPar(fd(-1, conbasis), 0, 0, 1);
%  C term in S equation
SStrC.variable   = 2;
SStrC.derivative = 0;
SStrC.WfdPar     = fdPar(fd(1/4,conbasis), 0, 0, 1);
%  S term in C equation
CStrS.variable   = 1;
CStrS.derivative = 0;
CStrS.WfdPar     = fdPar(fd(-1, conbasis), 0, 0, 1);
%  C term in C equation
CStrC.variable   = 2;
CStrC.derivative = 0;
CStrC.WfdPar     = fdPar(fd( 0, conbasis), 0, 0, 0);
% Struct object for set point forcing term in C equation
FStr.AfdPar      = fdPar(fd( 1, conbasis), 0, 0, 1);
FStr.Ufd         = SetPtfd;
% Struct object for the speed equation
SStr.name  = 'Speed';
SStr.order = 1;
SStr.XCell = cell(2,1);
SStr.FCell = {};
SStr.XCell{1} = SStrS;
SStr.XCell{2} = SStrC;
% Struct object for the conrol equation
CStr.name  = 'Control';
CStr.order = 1;
CStr.XCell = cell(2,1);
CStr.FCell = cell(1);
CStr.XCell{1} = CStrS;
CStr.XCell{2} = CStrC;
CStr.FCell{1} = FStr;
%  Cell array for the whole system
cruiseCell = cell(2,1);
cruiseCell{1} = SStr;
cruiseCell{2} = CStr;

%  check the system specification for consistency

cruiseCell = modelcheck(cruiseCell);

%  extract the parameter vector

theta1 = BAwtcell2vec(cruiseCell);

%% Solving the equations for known parameter values and initial conditions.
% In order to simulate data, we need to know the true values of _S(t)_
% and _C(t)_ at the time points where the process is observed.  We also 
% need tospecify the initial state of the system at time 0, which we define 
% to be zero for both variables.  We get the solution by using an initial 
% value approximation algorithm, which is here the Runge-Kutta fourth order
% method coded in Matlab's function |ode45|.
% The function |cruuise1| evaluates the right side of the equations at a 
% set of time values.  
%
% We first have a look at the solution at a fine mesh of values by solving
% the equation for the points in |tfine| and plotting them

odeoptions = odeset;

Svec0 = [0,0]';

[tfine, y0fine] = ode45(@cruise_1, tfine, Svec0, odeoptions, cruiseCell);

%  Plot the solution

figure(1)
subplot(2,1,1)
phdl = plot(tfine, y0fine(:,1), '-',[ 0, 20],[60,60],'b--', ...
            [20,20],[60,40],'b--',[ 20,40],[40,40],'b--', ...
            [40,40],[40,80],'b--',[40,60],[80,80],'b--', ...
            [60,60],[80,60],'b--',[60,80],[60,60],'b--');
set(phdl, 'LineWidth', 2)
axis([0,80,0,100])
ylabel('\fontsize{16} Speed S (mph)')
subplot(2,1,2)
phdl = plot(tfine, y0fine(:,2), 'b-');
set(phdl, 'LineWidth', 2)
xlabel('\fontsize{16} Time (mins)')
ylabel('\fontsize{16} Control level C')

%% Simulate noisy data at n observation points
% We simulate data by adding a random zero-mean Gaussian deviate to each 
% curve value.  The deviates for speed have a standard deviation 2 speed 
% units, and those for the control level have a standard deviation of 8.
% 
% The observed values for each curve are loaded into a struct object with
% two fields: 
%%
% # |argvals| for containing the time values at which observations are 
% taken, and 
%
%%
% # |y| to contain the observations themselves.  
%
% If either field is empty, it is taken that the variable is not observed.

%  solve the equation at the observation points

[tout, yout] = ode45(@cruise_1, tobs, Svec0, odeoptions, cruiseCell);

sigerr = 1;
yobs = zeros(n,2);
yobs(:,1) = yout(:,1) + randn(n,1).*sigerr;
yobs(:,2) = yout(:,2) + randn(n,1).*sigerr*4;

% plot the data long with the true solution:

figure(2)
subplot(2,1,1)
phdl = plot(tout, yout(:,1), '-', tobs, yobs(:,1), 'bo', ...
            [0,T], [60,60], 'r:');
set(phdl, 'LineWidth', 2)
ylabel('Speed')
subplot(2,1,2)
phdl = plot(tout, yout(:,2), '-', tobs, yobs(:,2), 'bo', ...
            [0,T], [240,240], 'r:');
set(phdl, 'LineWidth', 2)
ylabel('Control level')

%  load the data into two struct objects

yStruct1.argvals = tobs;
yStruct2.argvals = tobs;

yStruct1.y       = yobs(:,1);
yStruct2.y       = yobs(:,2);

%  Define yCell, and insert these into structs into the corresponding
%  cells.

yCell = cell(2,1);
yCell{1} = yStruct1;
yCell{2} = yStruct2;

%% Preliminary computation of inner product tensors
% There is one more task to accomplish, which in this code is done
% explicitly even though function
% |Lsmooth| can do it automtically if we wish.
%
% The main computation challenge is the computation of 
%%
% $$\int_0^T [D^m x_i(t) - \sum_k^d \sum_{\ell=0}^{m-1} \beta_{ik\ell}(t) 
%  D^{\ell} x_k(t) - \sum_j \alpha_{ij}(t) u_{ij}(t)]^2 dt$$
%
% When the penalty is defined in terms of only $D^m x$,
% the integrand does not depend on any parameter value, and it can
% therefore be evaluated at the outset by numerical integration, after
% which computation proceeds quickly.  But in this full formulation, this
% is no longer the case.
%
% But nevertheless the notion of getting this computation out of the way
% first still holds.  After expanding the square into a sum of squares and
% products of individual terms, it emerges that what requires integration
% for each such term is a four-way array (called a tensor) of products of 
% four basis functions, two of which come from a coefficient expansion for
% either an $\alpha$ or a $\beta$,
% and two more of which are products of basis functions for representing a 
% square of a single variable  $x_i$
% or a product of two variables.  Once this integration is out of the way,
% and the resulting tensor is stored in memory, the rest of the computation
% given any set of parameter values is really quite quick.
%
% The function |Btensorfd| compute tensors involving bases for only 
% combinations of  $\beta$s and _x_ basis functions.  
% The function |BAtensorfd| evaluates tensors involved a mixture of 
% $\beta$ terms and  $\alpha$ terms, and finally  |Atensorfd|
% computes products only involving combinations of $\alpha$ terms and their 
% associated forcing function bases.
%
% If we do this explicitly before calling function |Lsmooth|,
% then we can inform the function that these do not need to be computed
% again.  If we do not, the function will automatically compute the tensors
% in its first call and save the results for subsequent use.  The 
% |persistent| command in Matlab is used to implement this strategy.  
%
% If large numbers of basis functions are involved, the computaton is
% likely to be lengthy, and hence it may seem logical to do it explicitly
% and save the results for use either immediately or whenever the function
% is to be invoked.
%
% If there is any change in the basis structure, these tensors must be
% recalculated.  If the implicit approach is used, it is essentual to issue
% the command |clear functions| in order to reset the  |persistent| switch 
% back to 0.
%
% Ignore warnings of nonconvergence ... this is due to the discontinuous
% nature of the set point forcing function for the control variable.

tic;
BtensorCell = Btensorfn(XbasisCell, cruiseCell);
toc

save BtensorCell BtensorCell

tic;
BAtensorCell = BAtensorfn(XbasisCell, cruiseCell);
toc

save BAtensorCell BAtensorCell

tic;
AtensorCell = Atensorfn(cruiseCell);
toc

save AtensorCell AtensorCell

%% Initial parameter values
% We are ready to tackle the estimation process.  We need to use the data
% to provide some rough-and-ready parameter values as starting point for
% the iterative optimization methods that we will employ.  The two
% coefficients for the speed equation are what we will estimate, assuming
% that we know the three coefficients in the control equation.
%
% The estimation uses least squares regression of estimates of the first
% derivative of speed on the estimated speed and control curve values.
% The curve values and those of their first derivative are estimated by
% simple spline smoothing of the data using function |smooth_basis|, 
% using a smoothing parameter chosen by eye.

%  Smooth the data with a second derivative penalty

lambda = 10;  % chosen after inspecting the results for various values
XfdPar = fdPar(Xbasis,2,lambda);

yfd = smooth_basis(tobs, yobs, XfdPar);
ymat = eval_fd(tobs, yfd);

%  plot the smooths along with the data and true curves

figure(3)
subplot(2,1,1)
phdl = plot(tobs, yobs(:,1), 'bo', ... 
            tobs, ymat(:,1), 'b-', tobs, yout(:,1), 'b--');
set(phdl, 'LineWidth', 2)
ylabel('\fontsize{16} Speed')
legend('\fontsize{16} Data', '\fontsize{16} Fit' , ...
       '\fontsize{16} True', 'Location', 'SouthEast')
subplot(2,1,2)
phdl = plot(tobs, yobs(:,2), 'bo', ... 
            tobs, ymat(:,2), 'b-', tobs, yout(:,2), 'b--');
set(phdl, 'LineWidth', 2)
xlabel('\fontsize{16} Time (sec)')
ylabel('\fontsize{16} Control level')

%  estimate the values of first derivative of speed

Dymat = eval_fd(tobs, yfd, 1);

%  use least squares regress to estimate the two speed coefficients

Zmat1 = ymat;
beta1 = Zmat1\Dymat(:,1);

disp(['Estimated speed coefficients: ',num2str(beta1')])

%  Load the estimated coefficients

SStrS.variable   = 1;
SStrS.derivative = 0;
SStrS.WfdPar     = fdPar(fd(beta1(1), conbasis), 0, 0, 1);

SStrC.variable   = 2;
SStrC.derivative = 0;
SStrC.WfdPar     = fdPar(fd(beta1(2),conbasis), 0, 0, 1);

SStr.XCell{1} = SStrS;
SStr.XCell{2} = SStrC;

cruiseCell{1} = SStr;

cruiseCell = modelcheck(cruiseCell);

%% A preliminary evaluation of the function and its derivatives
% It's wise to invoke function |Lsmooth| with the starting values in 
% order to see that everything is in order, and to see how reasonable
% these starting values are.  We use a value of P of 0.5 for both 
% variables.  
% Setting the persistent switch to zero by the |clear functions| command 
% avoids any collision with other sets of tensors that might have been 
% saved.
% The last argument instructs |Lsmooth| to retrieve previously computed 
% tensors from storage.
% Ignore warnings of nonconvergence ... this is due to the discontinuous
% nature of the set point forcing function for the control variable.

rhovec = 0.5*ones(2,1);

clear functions

[SSE1, DSSE1, D2SSE1, XfdParCell1, ISE1, df1, gcv1, Rmat1, Smat1, ...
                   DRarray1, DSarray1] = ...
    Lsmooth(yCell, XbasisCell, cruiseCell, rhovec);


%%  set up a loop through a series of values of rho
%  We know, because the signal is smooth and the data are rough, that the 
%  optimal value of rho will be rather close to one, here we set up a 
%  range of rho values using the logistic transform of equally spaced
%  values between 0 and 5.
%  For each value of rho we save the degrees of freedom, the gcv value,
%  the error sum of squares for each equation, the mean squared errors for 
%  the parameters, and the parameter values.

Gvec    = 0:0.5:7;
rhomat  = ones(2,1)*(exp(Gvec)./(1+exp(Gvec)));
nrho    = size(rhomat,2);
dfesave = zeros(nrho,1);
gcvsave = zeros(nrho,1);
SSEsave = zeros(nrho,2);
MSEsave = zeros(nrho,2);
thesave = zeros(nrho,4);

conv    = 1e-6;
iterlim = 20;
dbglev  =  2;

%  loop through rho values, with a pause after each value
for irho = 1:nrho    
    rhoveci = rhomat(:,irho);
    theta_opt = Lsmooth_Opt(yCell, XbasisCell, cruiseCell, rhoveci, ...
                            conv, iterlim, dbglev);    
    thesave(irho,:) = theta_opt;   
    [cruiseCell_opt] = BAwtvec2cell(theta_opt, cruiseCell);
    
    [SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv] = ...
        Lsmooth(yCell, XbasisCell, cruiseCell_opt, rhoveci);
    SSEsave(irho,:) = SSE';
    dfesave(irho) = df;
    gcvsave(irho) = gcv;
    x1fd   = getfd(XfdParCell{1});
    x1vec  = eval_fd(tobs, x1fd);
    x1fine = eval_fd(tfine, x1fd);
    msex1  = mean((x1vec - yout(:,1)).^2);
    x2fd   = getfd(XfdParCell{2});
    x2vec  = eval_fd(tobs, x2fd);
    x2fine = eval_fd(tfine, x2fd);
    msex2  = mean((x2vec - yout(:,2)).^2);
    MSEsave(irho,1) = msex1;
    MSEsave(irho,2) = msex2;
    %  plot data, true, and estimated curves for each variable
    figure(4)
    %  plot of speed
    subplot(2,1,1)
    plot(tobs,  yobs(:,1),   'bo', ...
         tfine, x1fine,      'b-', ...
         tfine, y0fine(:,1), 'b--')
    ylabel('\fontsize{13} Speed S(t)')
    title(['\fontsize{16} P = ', num2str(rhoveci(1)), ...
        ',  beta = ',  num2str(theta_opt'), ...
        ',  GCV = ',   num2str(gcv), ...
        ',  X-RMSE = ', num2str(sqrt(msex1))])
    % plot of control variable
    subplot(2,1,2)
    plot(tobs,  yobs(:,2),     'bo', ...
         tfine, x2fine,        'b-', ...
         tfine, y0fine(:,2), 'b--')
    ylabel('\fontsize{13} Control C(t)')
    title(['\fontsize{16} X-RMSE = ', num2str(sqrt(msex2))])
    %  plot derivative and right side
    Dx1fine = eval_fd(tfine, x1fd, 1);
    Dx2fine = eval_fd(tfine, x2fd, 1);
    DSvec   = cruise_1(tfine, [x1fine,x2fine]', BwtCell, AwtCell, UfdCell);
    figure(5)
    %  speed derivative
    subplot(2,1,1)
    plot(tfine, DSvec(1,:)', 'b-', tfine, Dx1fine, 'r-', ...
         [0,80], [0,0], 'm:')
    ylabel('\fontsize{13} D Speed DS(t)')
    %  control derivative
    subplot(2,1,2)
    plot(tfine, DSvec(2,:)', 'b-', tfine, Dx2fine, 'r-', ...
         [0,80], [0,0], 'm:')
    ylabel('\fontsize{13} D Control DC(t)')
    pause    
end

ind = 1:nrho;
%  display the parameter values
disp([rhomat(1,ind)', thesave(ind,:)])
%  display df, gcv and MSEs
disp([rhomat(1,ind)', dfesave(ind), gcvsave(ind), MSEsave(ind,:)])

%  plot parameters as a function of \rho

figure(6)
subplot(1,1,1)
phdl = plot(rhomat(1,:)', thesave, 'o-');
set(phdl, 'LineWidth', 2)
axis([0.5,1.0,-2,0.8])
xlabel('\fontsize{16} \rho')
ylabel('\fontsize{16} \beta(\rho)')
title(['\fontsize{16} n = ',num2str(n)])

%  plot root sum of errors for fit as a function of \rho

figure(7)
phdl = plot(rhomat(1,:)', sqrt(SSEsave), 'o-');
set(phdl, 'LineWidth', 2)
xlabel('\fontsize{16} \rho')
ylabel('\fontsize{16} RSSE(\rho)')
title(['\fontsize{16} n = ',num2str(n)])

%  We see that the gcv criterion favors the 7th rho value, 0.9526.

rho_opt   = rhomat(:,7);
theta_opt = thesave(7,:)';

%  convert the optimal parameter values to optimal BwtCell and AwtCell

cruiseCell_opt = BAwtvec2cell(theta_opt, cruiseCell);

%% Evaluate aspects of the optimal solution
% We now ask |Lsmooth| to return a variety of information for evaluating
% the optimal solution:
%%
% * |SSE| is a vector of error sum of squares for each variable
% * |DSSE| is the gradient vector at the optimal solution
% * |D2SSE| is the expected Hessian
% * |XfdParCell| is a cell array of length equal to number variable
%      containing the estimated solutions
% * |ISE| is the integrated squared roughness penalty
% * |df| is a degrees of freedom measure for the estimated solutions
% * |gcv| is the generalized cross-validation value
%
% In addition, we plot the estimated solutions both speed and control along
% with the data

%  evaluate the solution at the optimal solution

[SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv] = ...
   Lsmooth(yCell, XbasisCell, cruiseCell_opt, rho_opt);

disp(['Fitting function values: ',num2str([sum(SSE),ISE])])
disp(['Degrees of freedom = ',num2str(df)])
disp(['gcv criterion = ',num2str(gcv)])

%  Display the estimated solutions, as estimated from the data, rather
%  than from the initial value estimates in the above code

Xfd1 = getfd(XfdParCell{1});
Xfd2 = getfd(XfdParCell{2});

Xvec1 = eval_fd(tfine, Xfd1);
Xvec2 = eval_fd(tfine, Xfd2);

figure(8)
subplot(2,1,1)
yStruct1 = yCell{1};
phdl = plot(tfine, Xvec1, 'b-', ...
            tfine,    y0fine(:,1),   'r--', ...
            yStruct1.argvals, yStruct1.y, 'bo');
set(phdl, 'LineWidth', 2)
axis([0,80,0,100])
ylabel('\fontsize{16} Speed')
legend('\fontsize{16} Fit', '\fontsize{16} Data', ...
       'Location', 'SouthEast')
subplot(2,1,2)
yStruct2 = yCell{2};
phdl = plot(tfine, Xvec2, '-', ...
            tfine,    y0fine(:,2),   'g--', ...
            yStruct2.argvals, yStruct2.y, 'bo');
set(phdl, 'LineWidth', 2)
axis([0,80,0,400])
xlabel('\fontsize{16} Time (sec)')
ylabel('\fontsize{16} Control')

%% Final observations for this problem
% The best estimates for the first two parameters are fairly far from the 
% true values of -1 and 1/4, respectively, although they have about the 
% right ratio to each other.  The estimated speed and control forcing 
% coefficients are better, and they there are of opposite sign but nearly
% equal, as required.

%  ------------------------------------------------------------------------

function DSvec = cruise_2(t, Svec, cruiseCell, irep)
%  Cruise control equation ... A second order equation
%  Last modified 2 July 2015
DSvec = zeros(2,length(t));
SStr  = cruiseCell{1};
SfdC  = fd(getcoef(SStr.XCell{1}.WfdPar), getbasis(SStr.XCell{1}.WfdPar));
SfdS  = fd(getcoef(SStr.XCell{2}.WfdPar), getbasis(SStr.XCell{2}.WfdPar));
FfdC  = fd(getcoef(SStr.FCell{1}.AfdPar), getbasis(SStr.FCell{1}.AfdPar));
UfdC  = SStr.FCell{1}.Ufd;
BTS0  = eval_fd(t,SfdC);
BTS1  = eval_fd(t,SfdS);
APC   = eval_fd(t,FfdC);
U11   = eval_fd(t,UfdC(irep));
DSvec(1,:) = Svec(2,:);
DSvec(2,:) = BTS0'.*Svec(1,:) + BTS1'.*Svec(2,:) + APC'.*U11';

%  ------------------------------------------------------------------------

%% A single order two Feedback equation
%
% A driver starts his car and (1) accelerates to the 60 km/h speed limit
% holding on most main streets of Ottawa, (2) reduces speed to 40 km/h in a
% school zone, (3) enters a controlled-access boulevard with an 80 km/h
% limits and finally (4) against enters a typical principal street.
% Operating on a snowy winter morning, the driver takes 8 seconds to reach
% 60 km/h, or 4/30 seconds per unit change in speed.
%
% The speed of the car under acceleration is modelled by a first order
% constant coefficient equation:
%
%% The feedback equations: 
% The two differental equations specifying the feedback model are:
%%
% $$DS(t) = -\beta_{11} S(t) + \beta_{12} C(t)$$
%
%%
% $$DC(t) =  \beta_{22} C(t) + \beta_{21} [S_0(t) - S(t)]$$
%
% The right side term
% $\beta_1 C(t)$ 
% in the first equation is the contribution of the control variable
% _C_
% to the change in speed
% _DS_.
% In the second term on the right side the variable
% _S_0_ 
% is the set-point function specifying the target speed, and it is
% called a forcing function.
%
% We can rewrite the equation introducing an explicit coefficient 
% $\alpha$
% as its multiplier to express the equation in a more standard way that we
% will use to set up the problem in code:
%%
% $$DC(t) = \beta_{21} S(t) + \beta_{22} C(t) + \alpha S_0(t)$$
%
% where we understand that $\beta_{21} = -\alpha$.
%
% When the actual speed is below the target, the control variable
% increases, and this forces a proportionate increase in speed. Likewise,
% when the current speed exceeds the target, the control variable
% decreases, and so does the current speed.

%% Conversion to a single equation
% We can, without losing much modelling power, simplify the equations by 
% assuming that the gain $K = \alpha/\beta$ is fixed at 1.0 and the 
% controller reaction speed is so large that the controller responds 
% virtually immediately to a change in speed/set--point discrepancy.  
% That is, $DC = S_0 - S$, or 
%%
% $$C(t) = \int_0^t S_0(u) - S(u) \, du + C_0$$
%
% where $C_0$ is an arbitrary constant of integration. Inserting the right 
% side of this equation into the _DS_ equation and differentiating both 
% sides of the result, we have the single second order equation
%%
% $$D^2S(t) = \beta_0 S(t) + \beta_1 DS(t) + \alpha S_0(t)$$
%
% where we have the constraints that $-\beta_0 = \alpha$ and 
% $-\beta_1 > 0$.  Now we assume that only speed is observed.
%
% The set up of BwtCell, AwtCell, thetaCell and XbasisCell have to be 
% adjusted as follows:

%%  Defining the problem
% Set up the time span, a set of observation times, and a fine grid for
% plotting:

addpath('../fdaM')

T     = 80;  %  seconds
n     = 41;
nfine = 101;
tobs  = linspace(0,T,n)';
tfine = linspace(0,T,nfine)';
%  set up constant basis over this range;

rng = [0,T];
conbasis  = create_constant_basis(rng);

%% Generate some replicated sample data for analysis
% Now we will improve the power of the estimation by assuming that the
% experiment has been repeated ten times.  The forcing functions will 
% vary from replication to replication, but their coefficient will not.

nrep = 10;  %  the number of replications

stepbasis = create_bspline_basis(rng, 4, 1, [0,20,40,60,80]);
stepcoef = [60;40;80;60];

sigstep = 0.1;
stepcoef   = stepcoef*exp(randn(1,nrep)*sigstep);
SetPtfd    = fd(stepcoef, stepbasis);

%% Define cruiseCell structures

%  First term in S equation
SStr0.variable   = 1;
SStr0.derivative = 0;
SStr0.WfdPar     = fdPar(fd(-1/4, conbasis), 0, 0, 1);
%  Second in term in S equation
SStr1.variable   = 1;
SStr1.derivative = 1;
SStr1.WfdPar     = fdPar(fd(  -1, conbasis), 0, 0, 1);
% Struct object for set point forcing term in C equation
FStr.AfdPar      = fdPar(fd( 1/4, conbasis), 0, 0, 1);
FStr.Ufd         = SetPtfd;
% Struct object for the speed equation
SStr.name  = 'Speed';
SStr.order = 2;
SStr.XCell = cell(2,1);
SStr.FCell = cell(1);
SStr.XCell{1} = SStr0;
SStr.XCell{2} = SStr1;
SStr.FCell{1} = FStr;
%  Cell array for the whole system
cruiseCell = cell(1);
cruiseCell{1} = SStr;

%  check the system specification for consistency

cruiseCell = modelcheck(cruiseCell);

%% Define XbasisCell containing the basis system for representing each varible.
% We also have to provide a basis system for each variable that is large
% enough to allow for any required sharp curvature in the solution to the
% differential equation system.  
%
% First we set the order of the B-spline basis to 5 so that the first 
% derivative will be smooth when working with a second order derivative in
% the penalty term.  Then we position knots at 41 positions where we willl
% simulate noisy observations.  We use the same basis for both variables
% and load it into a cell array of length 2.

nXorder   =  5;
breaks    = linspace(0,80,n);
nbreaks   = length(breaks);
nXbasis   = nbreaks + 2;
Xbasisobj = create_bspline_basis(rng, nXbasis, nXorder,breaks);

XbasisCell = cell(1);
XbasisCell{1} = Xbasisobj;

%% set up some data for analysis using second order function cruise_2

odeoptions = odeset;

Svec0 = [0,0]';

sigerr = 2;
yobs  = zeros(n,nrep);
for irep=1:nrep
    [tout, yout] = ode45(@cruise_2, tobs, Svec0, odeoptions, ...
                         cruiseCell, irep);    
    yobsi = yout(:,1);
    yobs(:,irep) = yobsi + randn(n,1).*sigerr; 
end

%  load the data into a struct object

yStruct.argvals = tobs;
yStruct.y       = yobs;

%  Define yCell

yCell = cell(1);
yCell{1} = yStruct;

%% Compute starting values
% We use regression analysis for this.  First, smooth the data.  The
% evaluate the smooth and its first and second derivatives at the 
% observation points, as well as evaluating the forcing function.  
% Assemble these elements into a vectorized version of the second 
% derivative and a covariate matrix with three columns, the first 
% containing the vectorized smooth values, the second the vectorized first
% derivative values, and the final the vectorized forcing function values.

%  smooth the data

lambda = 1e1;
XfdPar = fdPar(Xbasisobj,2,lambda);

% evaluate the smooth, its first and second derivatives and the forcing
% functions

yfd = smooth_basis(tobs, yobs, XfdPar);
ymat   = eval_fd(tobs, yfd);
Dymat  = eval_fd(tobs, yfd, 1);
D2ymat = eval_fd(tobs, yfd, 2);
Umat = eval_fd(tobs, SetPtfd);

% assemble this into the linear model

D2Yvec = zeros(nrep*n,1);
Zmat   = zeros(nrep*n,3);
m2 = 0;
for i=1:nrep
    m1 = m2 + 1;
    m2 = m2 + n;
    D2Yvec(m1:m2) = D2ymat(:,irep);
    Zmat(m1:m2,1) = ymat(:,irep);
    Zmat(m1:m2,2) = Dymat(:,irep);    
    Zmat(m1:m2,3) = Umat(:,irep);
end

% evaluate the regression coefficients

beta = Zmat\D2Yvec;

% set up an initial estimates of parameters

SStr.XCell{1}.WfdPar = putcoef(SStr.XCell{1}.WfdPar, ...
                                mean([beta(1),-beta(3)]));
SStr.XCell{2}.WfdPar = putcoef(SStr.XCell{2}.WfdPar, ...
                               beta(2));
SStr.FCell{1}.WfdPar = putcoef(SStr.FCell{1}.WfdPar, ...
                               -mean([beta(1),-beta(3)]));

%  evaluate the function for the initial values

P = 0.9;

clear functions

[SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv] = ...
   Lsmooth(yCell, XbasisCell, cruiseCell, P);

SSE
DSSE

%% Parameter estimation
% Now the first and the third parameters must be equal and of opposite 
% sign.
%
% A little preliminary analysis with a range of P values shows that the gcv
% criterion and the quality of estimates require a P value of at least 0.9
% and higher.  We also learn that for very high values of P, say 0.99 and
% higher, the computation becomes quite sensitive to starting values being
% too far away from the optimum.  We adopt the strategy of moving
% incrementally towards the optimum by starting at a P value that seems
% safe when started with the starting values computed above, which in this 
% case is P = 0.9, and then stepping upwards, each time using the estimate
% from the preceding step as a start for the current step.

%  set up parMap to enforce the zero sum constraint for the first and
%  third parameter

Cvec = [1,0,1]';
[Qmat,Rmat] = qr(Cvec);
parMap = Qmat(:,2:3);

%  choose the initial P-value

P = 0.9;
disp(['P = ',num2str(P')])

% optimize the fit for this value

conv    = 1e-6;
iterlim = 50;
dbglev  = 1;

clear functions

theta_opt = Lsmooth_Opt(yCell, XbasisCell, ...
                        cruiseCell, P, conv, iterlim, dbglev, parMap);

disp(['theta: ',num2str(theta_opt')])

cruiseCell_opt = BAwtvec2cell(theta_opt, cruiseCell);

[SSE_opt, DSSE_opt, D2SSE_opt, XfdParCell_opt, ISE_opt, df, gcv] = ...
   Lsmooth(yCell, XbasisCell, cruiseCell, P);

disp(['Fitting function values: ',num2str([sum(SSE_opt),ISE_opt])])
disp(['Degrees of freedom = ',num2str(df)])
disp(['gcv criterion = ',num2str(gcv)])

%  display the estimated solutions

Xfd1  = getfd(XfdParCell_opt{1});
Xvec1 = eval_fd(tfine, Xfd1);

figure(1)
subplot(1,1,1)
yStruct1 = yCell{1};
plot(tfine, Xvec1, '-', yStruct1.argvals, yStruct1.y, 'bo')
ylabel('\fontsize{13} Speed')

%  set up a sequence of analyses with varying value of P

Gvec = 1:0.5:5;
Pvec = exp(Gvec)./(1+exp(Gvec));
nP   = length(Pvec);

thetasave = zeros(nP,3);
dfsave    = zeros(nP,1);
gcvsave   = zeros(nP,1);
for iP = 1:nP
    Pi = Pvec(iP);
    disp(['P = ',num2str(Pvec(iP))])
    theta_opt = Lsmooth_Opt(yCell, XbasisCell, ...
        cruiseCell, Pi, conv, iterlim, dbglev, parMap);
    cruiseCell_opt = BAwtvec2cell(theta_opt, cruiseCell);
    [SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv] = ...
        Lsmooth(yCell, XbasisCell, cruiseCell, Pi);
    thetasave(iP,:) = theta_opt';
    dfsave(iP)      = df;
    gcvsave(iP)     = gcv;
end

disp('P-values, degrees of freedom and gcv values:')
ind = 1:nP;
disp([Pvec(ind)',dfsave(ind),gcvsave(ind)])

%% Evaluation the solution for best gcv value

iP = 7;

disp(['theta: ',num2str(thetasave(iP,:))])

[SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv, Rmat] = ...
        Lsmooth(yCell, XbasisCell, cruiseCell, Pvec(iP));

%  display the estimated solutions

Xfd  = getfd(XfdParCell{1});
Xmat = eval_fd(tfine, Xfd);

figure(2)
subplot(1,1,1)
yStruct1 = yCell{1};
phdl = plot(tfine, Xmat, 'b-', yStruct1.argvals, yStruct1.y, 'bo');
set(phdl, 'LineWidth', 2)
xlabel('\fontsize{16} Time (sec)')
ylabel('\fontsize{16} Speed (km/h)')

%% Evaluation of results
% Now the estimated solutions are beautiful, and estimated parameter
% values, although still a little small, clearly offer an excellent account
% of the data.  Probably the fact that we allows the set-point function to
% vary randomly contributed as well.

%% Explore the basis system defined by Rmat
% We calculate the eigenvalues and eigenvectors of Rmat in ascending order.
% The matrix of eigenvectors multiplying the basis matrix produces a new
% orthogonal basis system, the R-basis functions, for representing the 
% variation within and betweenestimated functions.
% The first two eigenvectors are associated with near-zero eigenvalues, and
% show the kernel of the differential operator L.  

[V,D] = eig(Rmat);
[Dsort,Isort] = sort(diag(D),'ascend');
Vsort = V(:,Isort);
Xbasismat = eval_basis(tobs, Xbasisobj);
Rbasismat = Xbasismat*Vsort;
Xbasismatfine = eval_basis(tfine, Xbasisobj);
Rbasismatfine = Xbasismatfine*Vsort;

%  compute root mean squared errors for successive fits

nRbasis = size(Rmat,1);
RMSEsave = zeros(nRbasis,1);
for i=1:nRbasis
    Zmat = Rbasismat(:,1:i);
    Bvec = Zmat\yobs;
    yhat = Zmat*Bvec;
    RMSE = sqrt(mean(mean((yobs - yhat).^2)));
    RMSEsave(i) = RMSE;
end

%  plot the initial set of RMSE values

figure(4)
index = 1:20;
phdl = plot(index, RMSEsave(index), 'o-');
set(phdl, 'LineWidth', 2)
xlabel('\fontsize{16} Number of R functions')
ylabel('\fontsize{16} Root-mean-squared-error')

%  plot the first two  basis functions

figure(5)
subplot(1,1,1)
phdl = plot(tfine, Rbasismatfine(:,1:2), '-', ...
            [0,80], [0,0], 'r:');       
set(phdl, 'LineWidth', 2)
axis([0,80,-0.6,0.4])
xlabel('\fontsize{16} Time (sec)')
ylabel('\fontsize{16} R-function')
legend('\fontsize{16} R function 1', ...
       '\fontsize{16} R function 2')

% plot the next five

figure(6)
subplot(1,1,1)
phdl = plot(tfine, Rbasismatfine(:,3:7), '-', ...
            [0,80], [0,0], 'r:');       
set(phdl, 'LineWidth', 2)
axis([0,80,-0.4,0.55])
xlabel('\fontsize{16} Time (sec)')
ylabel('\fontsize{16} R-function')
legend('\fontsize{16} R function 3', ...
       '\fontsize{16} R function 4', ...
       '\fontsize{16} R function 5', ...
       '\fontsize{16} R function 6', ...
       '\fontsize{16} R function 7', ...
       'Location', 'NorthWest')

%% Plot the fits for successive bases
% As we add more and more and more R-basis functions we see how the fitted 
% functions are re-constructed.  
% About 20 basis functions in this case produces a root-mean-squared-error 
% of about 2.0, which was what we used togenerate the data.

figure(7)
index=1:20;
for i=index
    Zmat = Rbasismatfine(:,1:i);
    Bvec = Zmat\Xmat;
    yhat = Zmat*Bvec;
    subplot(2,1,1)
    phdl = plot(tfine, Rbasismatfine(:,i), 'b-');
    set(phdl, 'LineWidth', 2)
    title(['\fontsize{16} R-basis function ',num2str(i), ...
           ',  Complexity ',num2str(Dsort(i))])
    subplot(2,1,2)
    phdl = plot(tobs, yobs, 'bo', tfine, Xmat, 'b-', tfine, yhat, 'r-');
    set(phdl, 'LineWidth', 2)
    xlabel('\fontsize{16} Time (sec)')
    ylabel('\fontsize{16} Speed (km/h)')
    title(['\fontsize{16} RMSE = ',num2str(RMSEsave(i))])
    pause
end

%  ------------------------------------------------------------------------

%%%  Analyses of motorcycle impact data

%  Last modified 1 July 2015

%  add path to fda functions

addpath('../fdaM')

%  bypass set-up phase if previously completed

load motosetup

%  Two analyses: 
%    -- Using the full data and a pulse forcing function (here)
%    -- Using the post-impact data and no forcing function  (line 400)

%%               Post- and Pre- impact Analysis


%% Set up the full data

%  load the data

load motorcycledata.txt

motot = motorcycledata(:,2);  %  time in milliseconds
motou = unique(motot);        %  strictly increasing time values
motoy = motorcycledata(:,3);  %  deformation in 0.1 millimeters

%  adjust the data for baseline and plot

impact  = 14.0;  %  impact time
baseind = motot < impact;
basey   = mean(motoy(baseind));

%  remove baseline, change time, and convert to centimeters

motoy   = (basey - motoy)/100.0;  

%  what follows was accidentally superimposed over early resultls:
%  reinstall this from dropbox version

% postind = find(motot >= impact);
% posty   = motoy(postind);
% postt   = motot(postind) - impact;
% postrng = [0, 46];
% 
% yCell = cell(1);
% 
% yStruct.argvals = postt;
% yStruct.y       = posty;
% 
% yCell{1} = yStruct;
% 
% %% lot data
% 
% figure(1)
% phdl=plot(postt, posty, 'bo', [0,46], [0,0], 'b:');
% set(phdl, 'LineWidth', 2)
% axis([0,46,-1.0,1.5])
% xlabel('\fontsize{16} Time (milliseconds)')
% ylabel('\fontsize{16} Acceleration (cm/msec^2)')
% 
% %% Set up the basis system
% %  Order 4 spline basis, with three knots at the impact point and 
% %  three knots at impact + delta to permit discontinuous first 
% %  derivatives at these points
% 
% %  Note:  We can't use too many post-impact knots because the coefficient 
% %  matrix can become singular, possibly due to approximation errors for 
% %  4-tensors.
% 
% norder    = 6;
% delta     = 1;
% nbasis    = 21;
% motobasis = create_bspline_basis(motorng,nbasis,norder,knots);
% 
% XbasisCell = cell(1);
% XbasisCell{1} = motobasis;
% 
% %% Set up the cell array modelCell
% 
% modelCell = cell(1);
% 
% modelStruct.order = 2;
% modelStruct.XCell = cell(2,1);
% modelStruct.FCell = {};
% 
% Wbasisobj = create_constant_basis(motorng);
% WfdParobj = fdPar(Wbasisobj, 0, 0, 1);
% 
% Xterm0Struct.variable   = 1;
% Xterm0Struct.derivative = 0;
% Xterm0Struct.WfdPar     = WfdParobj;
% modelStruct.XCell{1}    = Xterm0Struct;
% 
% Xterm1Struct.variable   = 1;
% Xterm1Struct.derivative = 1;
% Xterm1Struct.WfdPar     = WfdParobj;
% modelStruct.XCell{2}    = Xterm1Struct;
% 
% modelCell{1} = modelStruct;
% 
% modelCell = modelcheck(modelCell);
% 
% %  save all this for future analyses
% 
% save motosetup

%% An evaluation of the criterion at the initial values

P = 0.90;  %  light smoothing;
disp(['P and 1 - P:  ',num2str([1-P,P])])
disp(['P/(1-P) =     ',num2str(P/(1-P))])

%  this command causes Lsmooth to set up and save the tensors

clear functions

[SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv] = ...
                     Lsmooth(yCell, XbasisCell, modelCell, P);

%% Optimization of the criterion

%  algorithm constants

dbglev   =  1;    %  debugging level
iterlim  = 50;    %  maximum number of iterations
conv     = 1e-7;  %  convergence criterion

theta_opt = Lsmooth_Opt(yCell, XbasisCell, ...
                        modelCell, P, conv, iterlim, dbglev);

disp(['theta = ',num2str(theta_opt')])

% [BwtCell_opt, AwtCell_opt] = BAwtvec2cell(theta_opt, BwtCell, AwtCell);
% 
% [SSE, DSSE, D2SSE, XfdParCell_opt, ISE, df, gcv] = ...
%                      Lsmooth(yCell, XbasisCell, ...
%                               P, BwtCell_opt, AwtCell_opt, UfdCell);

[SSE, DSSE, D2SSE, XfdParCell_opt, ISE, df, gcv] = ...
                     Lsmooth(yCell, XbasisCell, ...
                              modelCell, P);

motofd_0 = getfd(XfdParCell_opt{1});

%% Optimize the fit for a range of P-values

Pvec      = [0.50, 0.73, 0.88, 0.95, 0.98, 0.99];
nP        = length(Pvec);
ntheta    = length(theta_opt);
thetastore = zeros(ntheta,nP);
dfstore    = zeros(ntheta,1);
gcvstore   = zeros(ntheta,1);

for iP = 1:nP
    Pi = Pvec(iP);
    theta_opti = Lsmooth_Opt(yCell, XbasisCell, modelCell, Pi, ...
                    conv, iterlim, dbglev);
    modelCell_opti = BAwtvec2cell(theta_opti, modelCell);
    [SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv] = ...
                     Lsmooth(yCell, XbasisCell, modelCell_opti, P);
    thetastore(:,iP) = theta_opti;
    dfstore(iP)      = df;
    gcvstore(iP)     = gcv;
end

% display the optimal parameter values

disp(['Stiffness = ',num2str(thetastore(1,:))]) 
disp(['Damping   = ',num2str(thetastore(2,:))])
disp(['Forcing   = ',num2str(thetastore(3,:))])

% Stiffness = -0.076   -0.077   -0.077   -0.073   -0.067   -0.063
% Damping   =  0.131    0.102    0.063    0.024   -0.029   -0.086
% Forcing   =  0.300    0.278    0.213    0.116   -0.032   -0.215
 
% period = 9.3 msec for 4th stiffness coef.

% display degrees of freedom and gcv values

disp([Pvec',dfstore, gcvstore])

%% Evaluate the fit for the minimum-gcv parameter values

iP = 4;
theta4 = thetastore(:,iP);
modelCell4 = BAwtvec2cell(theta4, modelCell);
P4 = Pvec(iP);
[SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv, Rmat, Smat] = ...
                     Lsmooth(yCell, XbasisCell, modelCell4, P4);

disp(['SSE = ', num2str(SSE)])
disp(['df  = ', num2str(df)])
disp(['gcv = ', num2str(gcv)])
disp(['DSSE = ',num2str(DSSE')])

motofd_4 = getfd(XfdParCell{1});

tfine = [linspace(motorng(1),impact,2), ... 
         linspace(impact,impact+delta,11), ...
         linspace(impact+delta,motorng(2),101)]';
     
motovec_0 = eval_fd(tfine, motofd_0);
motovec_4 = eval_fd(tfine, motofd_4);

figure(3)
phdl=plot(tfine, motovec_0, 'r-', tfine, motovec_4, 'b-');
set(phdl, 'LineWidth', 2)
legend('\fontsize{16} \rho = 0.50', '\fontsize{16} \rho = 0.95', ...
       'Location', 'SouthWest')
hold on
phdl=plot(motot, motoy, 'bo', ...
          [impact,      impact],       [0,1], 'b--', ...
          [impact+delta,impact+delta], [0,1], 'b--', ...
          [impact,      impact+delta], [1,1], 'b--', ...
          [0,60], [0,0], 'b:');
set(phdl, 'LineWidth', 2)
hold off
axis([0,60,-1.0,1.5])
xlabel('\fontsize{16} Time (milliseconds)')
ylabel('\fontsize{16} Acceleration (cm/msec^2)')
text(40,1.3,'\fontsize{16} \rho   =  0.95')
text(40,1.1,'\fontsize{16} \beta_0 = -0.073')
text(40,0.9,'\fontsize{16} \beta_1 =  0.024')
text(40,0.7,'\fontsize{16} \alpha  =  0.116')
text(40,0.5,'\fontsize{16} df  =  11.7')

%  evaluate the slope of the solution

nfine = 101;
tfine = linspace(motorng(1),motorng(2),nfine)';

motofine   = eval_fd(tfine, motofd_4);
Dmotofine  = eval_fd(tfine, motofd_4, 1);
D2motofine = eval_fd(tfine, motofd_4, 2);
Lmotofine  = D2motofine - theta4(1)*motofine - theta4(2)*Dmotofine;

figure(4)
subplot(2,2,1)
plot(tfine, motofine,   '-', [impact,impact], [-1.00,1.50], 'b--', ...
    [0,60], [0,0], 'r:')
subplot(2,2,2)
plot(tfine, Dmotofine,  '-', [impact,impact], [ -.30, .30], 'b--', ...
    [0,60], [0,0], 'r:')
subplot(2,2,3)
plot(tfine, D2motofine, '-', [impact,impact], [ -.10, .10], 'b--', ...
    [0,60], [0,0], 'r:')
subplot(2,2,4)
plot(tfine, Lmotofine,  '-', [impact,impact], [ -.10, .10], 'b--', ...
    [0,60], [0,0], 'r:')

%% Explore the basis system defined by Rmat
% We calculate the eigenvalues and eigenvectors of Rmat in ascending order.
% The matrix of eigenvectors multiplying the basis matrix produces a new
% orthogonal basis system, the R-basis functions, for representing the 
% variation within and betweenestimated functions.
% The first two eigenvectors are associated with near-zero eigenvalues, and
% show the kernel of the differential operator L.  

tobs = motot;
[V,D] = eig(Rmat);
[Dsort,Isort] = sort(diag(D),'ascend');
Vsort = V(:,Isort);
Xbasismat = eval_basis(tobs, motobasis);
Rbasismat = Xbasismat*Vsort;
Xbasismatfine = eval_basis(tfine, motobasis);
Rbasismatfine = Xbasismatfine*Vsort;
Umat = eval_fd(tobs, forcefd);

%  plot the eigenvalues

figure(5)
subplot(1,1,1)
phdl = plot(1:nbasis, log10(Dsort), 'o-');
set(phdl, 'LineWidth', 2)

%  plot the first two  basis functions

figure(5)
subplot(1,1,1)
phdl = plot(tfine, Rbasismatfine(:,1:2), '-', ...
            [0,60], [0,0], 'r:');       
set(phdl, 'LineWidth', 2)
axis([0,60,-0.5,0.5])
xlabel('\fontsize{16} Time (milliseconds)')
ylabel('\fontsize{16} R-function')
legend('\fontsize{16} R function 1', ...
       '\fontsize{16} R function 2')

% plot the next five

figure(6)
subplot(1,1,1)
phdl = plot(tfine, Rbasismatfine(:,3:7), '-', ...
            [0,60], [0,0], 'r:');       
set(phdl, 'LineWidth', 2)
axis([0,60,-0.5,0.55])
xlabel('\fontsize{16} Time (milliseconds)')
ylabel('\fontsize{16} R-function')
legend('\fontsize{16} R function 3', ...
       '\fontsize{16} R function 4', ...
       '\fontsize{16} R function 5', ...
       '\fontsize{16} R function 6', ...
       '\fontsize{16} R function 7', ...
       'Location', 'NorthWest')

%% Plot the fits for successive bases
% As we add more and more and more R-basis functions we see how the fitted 
% functions are re-constructed.  
% About 20 basis functions in this case produces a root-mean-squared-error 
% of about 2.0, which was what we used togenerate the data.

%  compute root mean squared errors for successive fits

nRbasis = size(Rmat,1);
RMSEsave = zeros(nRbasis,1);
for i=1:nRbasis
    Zmat = Rbasismat(:,1:i);
    Bvec = Zmat\motoy;
    yhat = Zmat*Bvec;
    RMSE = sqrt(mean(mean((motoy - yhat).^2)));
    RMSEsave(i) = RMSE;
end

%  plot the iRMSE values

figure(7)
index = 1:nRbasis;
phdl = plot(index, RMSEsave(index), 'o-');
set(phdl, 'LineWidth', 2)
axis([1,17,0,0.6])
xlabel('\fontsize{16} Number of R functions')
ylabel('\fontsize{16} Root-mean-squared-error')

figure(8)
index=1:nRbasis;
for i=index
    Zmat = Rbasismat(:,1:i);
    Bvec = Zmat\motoy;
    yhat = Zmat*Bvec;
    subplot(2,1,1)
    phdl = plot(tfine, Rbasismatfine(:,i), 'b-');
    set(phdl, 'LineWidth', 2)
    title(['\fontsize{16} R-basis function ',num2str(i), ...
        ',  Complexity ',num2str(Dsort(i))])
    subplot(2,1,2)
    phdl = plot(tobs, motoy, 'bo', tobs, yhat, 'r-');
    set(phdl, 'LineWidth', 2)
    xlabel('\fontsize{16} Time (milliseconds)')
    ylabel('\fontsize{16} Acceleration (cm/msec^2)')
    title(['\fontsize{16} RMSE = ',num2str(RMSEsave(i))])
    pause
end






















%%                        Post impact Analysis

%% Set up the post impact data

%  load the data

load motorcycledata.txt

motot = motorcycledata(:,2);  %  time in milliseconds
motou = unique(motot);        %  strictly increasing time values
motoy = motorcycledata(:,3);  %  deformation in 0.1 millimeters

%  adjust the data for baseline and plot

impact  = 14.0;  %  impact time
baseind = motot < impact;
basey   = mean(motoy(baseind));
%  remove baseline, change time, and convert to centimeters
motoy   = (basey - motoy)/100.0;  

postind = find(motot >= impact);
posty   = motoy(postind);
postt   = motot(postind) - impact;
postrng = [0, 56];

yCell = cell(1);

yStruct.argvals = postt;
yStruct.y       = posty;

yCell{1} = yStruct;

%% Set up the basis system
%  Order 4 spline basis, with three knots at the impact point and 
%  three knots at impact + delta to permit discontinuous first 
%  derivatives at these points

%  Note:  We can't use too many post-impact knots because the coefficient 
%  matrix can become singular, possibly due to approximation errors for 
%  4-tensors.

norder    = 6;
delta     = 1;
nbasis    = 21;
postbasis = create_bspline_basis(postrng,nbasis,norder);

XbasisCell = cell(1);
XbasisCell{1} = postbasis;

%% Set up the cell array modelCell

modelCell = cell(1);

modelStruct.order = 2;
modelStruct.XCell = cell(2,1);
modelStruct.FCell = {};

Wbasisobj = create_constant_basis(postrng);
WfdParobj = fdPar(Wbasisobj, 0, 0, 1);

Xterm0Struct.variable   = 1;
Xterm0Struct.derivative = 0;
Xterm0Struct.WfdPar     = WfdParobj;
modelStruct.XCell{1}    = Xterm0Struct;

Xterm1Struct.variable   = 1;
Xterm1Struct.derivative = 1;
Xterm1Struct.WfdPar     = WfdParobj;
modelStruct.XCell{2}    = Xterm1Struct;

modelCell{1} = modelStruct;

modelCell = modelcheck(modelCell);

%  save all this for future analyses

save motosetup

%% An evaluation of the criterion at the initial values

P = 0.90;  %  light smoothing;
disp(['P and 1 - P:  ',num2str([1-P,P])])
disp(['P/(1-P) =     ',num2str(P/(1-P))])

%  this command causes Lsmooth to set up and save the tensors

clear functions

[SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv] = ...
                     Lsmooth(yCell, XbasisCell, modelCell, P);

%% Optimization of the criterion

%  algorithm constants

dbglev   =  1;    %  debugging level
iterlim  = 50;    %  maximum number of iterations
conv     = 1e-7;  %  convergence criterion

theta_opt = Lsmooth_Opt(yCell, XbasisCell, ...
                        modelCell, P, conv, iterlim, dbglev);

disp(['theta = ',num2str(theta_opt')])

% [BwtCell_opt, AwtCell_opt] = BAwtvec2cell(theta_opt, BwtCell, AwtCell);
% 
% [SSE, DSSE, D2SSE, XfdParCell_opt, ISE, df, gcv] = ...
%                      Lsmooth(yCell, XbasisCell, ...
%                               P, BwtCell_opt, AwtCell_opt, UfdCell);

[SSE, DSSE, D2SSE, XfdParCell_opt, ISE, df, gcv] = ...
                     Lsmooth(yCell, XbasisCell, ...
                              modelCell, P);

postfd_0 = getfd(XfdParCell_opt{1});

%% Optimize the fit for a range of P-values

Pvec      = [0.50, 0.73, 0.88, 0.95, 0.98, 0.99];
nP        = length(Pvec);
ntheta    = length(theta_opt);
thetastore = zeros(ntheta,nP);
dfstore    = zeros(ntheta,1);
gcvstore   = zeros(ntheta,1);

for iP = 1:nP
    Pi = Pvec(iP);
    theta_opti = Lsmooth_Opt(yCell, XbasisCell, modelCell, Pi, ...
                    conv, iterlim, dbglev);
    modelCell_opti = BAwtvec2cell(theta_opti, modelCell);
    [SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv] = ...
                     Lsmooth(yCell, XbasisCell, modelCell_opti, P);
    thetastore(:,iP) = theta_opti;
    dfstore(iP)      = df;
    gcvstore(iP)     = gcv;
end

% display the optimal parameter values

disp(['Stiffness = ',num2str(thetastore(1,:))]) 
disp(['Damping   = ',num2str(thetastore(2,:))])

% period = 9.3 msec for 4th stiffness coef.

% display degrees of freedom and gcv values

disp([Pvec',dfstore, gcvstore])

%% Evaluate the fit for the minimum-gcv parameter values

iP = 6;
theta6 = thetastore(:,iP);
modelCell6 = BAwtvec2cell(theta6, modelCell);
P6 = Pvec(iP);
[SSE, DSSE, D2SSE, XfdParCell, ISE, df, gcv, Rmat, Smat] = ...
                     Lsmooth(yCell, XbasisCell, modelCell6, P6);

disp(['SSE = ', num2str(SSE)])
disp(['df  = ', num2str(df)])
disp(['gcv = ', num2str(gcv)])
disp(['DSSE = ',num2str(DSSE')])

postfd_6 = getfd(XfdParCell{1});

tfine = linspace(postrng(1),postrng(2),101)';
     
postvec_0 = eval_fd(tfine, postfd_0);
postvec_6 = eval_fd(tfine, postfd_6);

figure(3)
phdl=plot(tfine, postvec_0, 'r-', tfine, postvec_6, 'b-');
set(phdl, 'LineWidth', 2)
legend('\fontsize{16} \rho = 0.50', '\fontsize{16} \rho = 0.99', ...
       'Location', 'SouthWest')
hold on
phdl=plot(postt, posty, 'bo', ...
          [0,46], [0,0], 'b:');
set(phdl, 'LineWidth', 2)
hold off
axis([0,46,-1.0,1.5])
xlabel('\fontsize{16} Time (milliseconds)')
ylabel('\fontsize{16} Acceleration (cm/msec^2)')
text(30,1.3,'\fontsize{16} \rho    =  0.99')
text(30,1.1,'\fontsize{16} \beta_0 = -0.062')
text(30,0.9,'\fontsize{16} \beta_1 =  0.039')

%  evaluate the slope of the solution

nfine = 101;
tfine = linspace(postrng(1),postrng(2),nfine)';

postfine   = eval_fd(tfine, postfd_4);
Dpostfine  = eval_fd(tfine, postfd_4, 1);
D2postfine = eval_fd(tfine, postfd_4, 2);
Lpostfine  = D2postfine - theta4(1)*postfine - theta4(2)*Dpostfine;

figure(4)
subplot(2,2,1)
plot(tfine, postfine,   '-', [impact,impact], [-1.00,1.50], 'b--', ...
    [0,60], [0,0], 'r:')
subplot(2,2,2)
plot(tfine, Dpostfine,  '-', [impact,impact], [ -.30, .30], 'b--', ...
    [0,60], [0,0], 'r:')
subplot(2,2,3)
plot(tfine, D2postfine, '-', [impact,impact], [ -.10, .10], 'b--', ...
    [0,60], [0,0], 'r:')
subplot(2,2,4)
plot(tfine, Lpostfine,  '-', [impact,impact], [ -.10, .10], 'b--', ...
    [0,60], [0,0], 'r:')

%% Explore the basis system defined by Rmat
% We calculate the eigenvalues and eigenvectors of Rmat in ascending order.
% The matrix of eigenvectors multiplying the basis matrix produces a new
% orthogonal basis system, the R-basis functions, for representing the 
% variation within and betweenestimated functions.
% The first two eigenvectors are associated with near-zero eigenvalues, and
% show the kernel of the differential operator L.  

tobs = postt;
[V,D] = eig(Rmat);
[Dsort,Isort] = sort(diag(D),'ascend');
Vsort = V(:,Isort);
Xbasismat     = eval_basis(tobs, postbasis);
Rbasismat     = Xbasismat*Vsort;
Xbasismatfine = eval_basis(tfine, postbasis);
Rbasismatfine = Xbasismatfine*Vsort;

%  plot the eigenvalues

figure(5)
subplot(1,1,1)
phdl = plot(1:nbasis, log10(Dsort), 'o-');
set(phdl, 'LineWidth', 2)

%  plot the first two  basis functions

figure(5)
subplot(1,1,1)
phdl = plot(tfine, Rbasismatfine(:,1:2), '-', ...
            [0,60], [0,0], 'r:');       
set(phdl, 'LineWidth', 2)
axis([0,60,-0.5,0.5])
xlabel('\fontsize{16} Time (milliseconds)')
ylabel('\fontsize{16} R-function')
legend('\fontsize{16} R function 1', ...
       '\fontsize{16} R function 2')

% plot the next three

figure(6)
subplot(1,1,1)
phdl = plot(tfine, Rbasismatfine(:,3:5), '-', ...
            [0,60], [0,0], 'r:');       
set(phdl, 'LineWidth', 2)
axis([0,60,-0.5,0.55])
xlabel('\fontsize{16} Time (milliseconds)')
ylabel('\fontsize{16} R-function')
legend('\fontsize{16} R function 3', ...
       '\fontsize{16} R function 4', ...
       '\fontsize{16} R function 5', ...
       'Location', 'NorthWest')

%% Plot the fits for successive bases
% As we add more and more and more R-basis functions we see how the fitted 
% functions are re-constructed.  
% About 20 basis functions in this case produces a root-mean-squared-error 
% of about 2.0, which was what we used togenerate the data.

%  compute root mean squared errors for successive fits

nRbasis = size(Rmat,1);
RMSEsave = zeros(nRbasis,1);
for i=1:nRbasis
    Zmat = Rbasismat(:,1:i);
    Bvec = Zmat\posty;
    yhat = Zmat*Bvec;
    RMSE = sqrt(mean(mean((posty - yhat).^2)));
    RMSEsave(i) = RMSE;
end

%  plot the iRMSE values

figure(7)
index = 1:nRbasis;
phdl = plot(index, RMSEsave(index), 'o-');
set(phdl, 'LineWidth', 2)
axis([1,17,0,0.6])
xlabel('\fontsize{16} Number of R functions')
ylabel('\fontsize{16} Root-mean-squared-error')

figure(8)
index=1:nRbasis;
for i=index
    Zmat = Rbasismat(:,1:i);
    Bvec = Zmat\posty;
    yhat = Zmat*Bvec;
    subplot(2,1,1)
    phdl = plot(tfine, Rbasismatfine(:,i), 'b-');
    set(phdl, 'LineWidth', 2)
    title(['\fontsize{16} R-basis function ',num2str(i), ...
        ',  Complexity ',num2str(Dsort(i))])
    subplot(2,1,2)
    phdl = plot(tobs, posty, 'bo', tobs, yhat, 'r-');
    set(phdl, 'LineWidth', 2)
    xlabel('\fontsize{16} Time (milliseconds)')
    ylabel('\fontsize{16} Acceleration (cm/msec^2)')
    title(['\fontsize{16} RMSE = ',num2str(RMSEsave(i))])
    pause
end

% -------------------------------------------------------------------------








