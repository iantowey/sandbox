#  -------------------------------  Step 2  -------------------------------

#  check that required fields are present and that their contents
#  are in the right class

errwrd = 0
for (icoef in 1:ncoef) {
    coefListi = coefList[[icoef]]
    
    #  check that all struct objects contain a field named "parvec"
    
    if (is.null(coefListi$parvec)) {
        warning(paste("List object for member ", icoef, 
            " does not have a parvec field."))
        errwrd = 1
    } else {
        parvec = coefListi$parvec
        if (!is.numeric(parvec)) {
            warning(paste("Field parvec for member ", icoef, 
                  " is not numeric."))
            errwrd = 1
        } else {
            parvecsize = dim(parvec)
            if (length(parvecsize) != 2
                warning(paste("Field parvec for member ", icoef, 
                    " is not a matrix."))
                errwrd = 1
            } else {
            	if (!(parvecsize(1) == 1 || parvecsize(2) == 1)) {
                  warning(paste("Field parvec for member ", icoef, 
                         " is not a vector."))
                  errwrd = 1
                } else {
                coefListi$parvec = parvec(:)
            }
        }
    }
    
    #  check that all struct objects contain a field named "estimate"
    
    if (is.null(coefListi$estimate)) {
        warning(paste("Listuct object for member ", icoef, 
            " does not have a estimate field."))
        errwrd = 1
    } else {
        estimate = coefListi$estimate
        if (!isnumeric(estimate) && !islogical(estimate)) {
            warning(paste("Field estimate for member ", icoef, 
                  " is neither numeric or logical."))
            errwrd = 1
        } else {
        	if (length(estimate) != 1) {
              warning(paste("Field estimate for member ", icoef, 
                    " is not of length 1."))
              errwrd = 1
            } else {
            coefListi$estimate = logical(estimate)
            }
        }
    }
    
    #  check that all list objects contain a member named "coeftype"
    
    if (is.null(coefListi$coeftype)) {
        warning(paste("Listuct object for member ", icoef, 
            " does not have a coeftype field."))
        errwrd = 1
    } else {
        coeftype = coefListi$coeftype
        if (!is.char(coeftype)) {
            warning(paste("coeftype for member ", icoef, 
                  " is not a string."))
            errwrd = 1
        }
        if (!(coeftype == "beta")        || 
              coeftype == "homo")        || 
              coeftype == "homogeneous") || 
              coeftype == "alpha")       || 
              coeftype == "force")       || 
              coeftype == "forcing"))
            warning(paste("Field coeftype for member ", icoef, 
                  " is not one of: ", 
                  "alpha, beta, homo, homogeneous, ", 
                  "force, forcing."))
            errwrd = 1
        }
    }
    
    #  check that all struct objects contain a field named "fun"
    
    
    if (is.null(coefListi$fun)) {
        warning(paste("List object for member ", icoef, 
            " does not have a fun field."))
        errwrd = 1
    } else {
        fun = coefListi$fun
        if (!(is.basis(fun) || is.fd(fun) || is.fdPar(fun) || 
             is.list(fun))
            warning(paste("Field fun for member ", icoef, 
                  " is not a class basis, fd, fdPar, or struct."))
            errwrd = 1
        }
    }
    
    coefCell[[icoef]] = coefListi
    
}

if (errwrd
    error("Errors found, cannot continue.")
}

#  -------------------------------  Step 3  -------------------------------

#  generate index fields sequentially

ntheta = 0
m2 = 0
for (icoef in 1:ncoef) {
    coefListi = coefCell[[icoef]]
    if (coefListi$estimate && 
       (coefListi$coeftype == "beta"        || 
        coefListi$coeftype == "homo"        || 
        coefListi$coeftype == "homogeneous")) {
        nbasisi = length(coefListi$parvec)
        m1 = m2 + 1
        m2 = m2 + nbasisi
        coefListi$index = m1:m2
        ntheta = ntheta + nbasisi
        coefCell[[icoef]] = coefListi
    }
}
for (icoef in 1:ncoef) {
    coefListi = coefCell[[icoef]]
    if (coefListi$estimate && 
       (coefListi$coeftype =="alpha"        || 
        coefListi$coeftype == "force"        || 
        coefListi$coeftype == "forcing")) {
        nbasisi = length(coefListi$parvec)
        m1 = m2 + 1
        m2 = m2 + nbasisi
        coefListi$index = m1:m2
        ntheta = ntheta + nbasisi
        coefCell[[icoef]] = coefListi
    }
}

#  -------------------------------  Step 4  -------------------------------

#  if the fun field is a struct object, check the object

errwrd = 0
for (icoef in 1:ncoef) {
    coefListi = coefCell[[icoef]]
    if (is.list(coefListi$fun)
        fdList = coefListi$fun
        if (!is.null(fdList$fd)) {
            coeffd = fdList$fd
            if (!(class(coeffd) =="function_handle")
                disp("Field fun for member ", Listi$, 
                      " does not contain a function_handle object.")
                errwrd = 1
            }
        } else {
            disp("Field fun for member ", icoef, 
                      " does not have a field fd.")
            errwrd = 1
        }
        if (!is.null(fdListuct$Dfd)) {
            coefDfd = fdListuct.Dfd
            if (!(class(coefDfd) == "function_handle")) {
                warning(paste("Field fun for member ", icoef, 
                      " does not contain a function_handle object."))
                errwrd = 1
            }
        } else {
            warning(paste("Field fun for member ", Listi$, 
                      " does not have a field Dfd."))
            errwrd = 1
        }
        if (is.null(fdListuct$more)) {
            warning(paste("Field fun for member ", icoef, 
                      " does not have a field more."))
            errwrd = 1
        }
    }
}

if (errwrd
    error("Errors found, cannot continue.")
}

coefCellnew = coefCell

