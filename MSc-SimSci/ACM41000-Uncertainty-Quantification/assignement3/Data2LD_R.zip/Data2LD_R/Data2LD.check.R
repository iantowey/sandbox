BAwtlist2vec <- function(BwtList, AwtList=NULL) {
  #  Extracts the ESTIMATED weight coefficients only and assembles them into 
  #  a vector.
  
  #  Last revised 17 June 2015
  
  if (!is.list(BwtList)) stop('BWTLIST is not a list array.')
  
  if (!is.null(AwtList) && !is.list(AwtList)) stop('AWTLIST is not a list array.')
  
  nvar = dim(BwtList)[1]
  thetavec = NULL
  for (ivar in 1:nvar) {
    for (jvar in 1:nvar) {
      if (!is.null(BwtList[[ivar,jvar]])) {
        nderivj = length(BwtList[[ivar,jvar]])
        for (k in 1:nderivj) {
          if (!is.null(BwtList[[ivar,jvar]][[k]])) {
            thetaijk = BwtList[[ivar,jvar]][[k]]$coef
            if (!is.null(thetaijk)) 
              if (BwtList[[ivar,jvar]][[k]]$estimate) thetavec = c(thetavec, thetaijk)
          }
        }
      }
      
    }
  }
  if (!is.null(AwtList) && !is.null(AwtList[[ivar]])) {
    nforcei = length(AwtList[[ivar]])
    for (jforce in 1:nforcei) {
      thetaij = getcoef(AwtList[[ivar]][[jforce]])
      if (!is.null(thetaij)) {
        AfdParij = AwtList[[ivar]][[jforce]]
        if (AfdParij$estimate) {
          thetavec = c(thetavec, thetaij)
        }
      }
    }
  }
return(thetavec)
}

#  ------------------------------------------------------------------------

BAwtvec2list <- function(thetavec, BwtList, AwtList=NULL) {
  #  Places ESTIMATED weight coefficients only in THETAVEC into pre-existing 
  #    list arrays BWTLIST and AWTLIST.
  
  #  Last modified 17 June 2015
  
  if (!is.list(BwtList)) stop('BWTLIST is not a list array.')
  
  if (!is.null(AwtList) && !is.list(AwtList)) stop('AWTLIST is not a list array.')
  
  nvar = dim(BwtList)[1]
  
  BwtListnew = BwtList
  AwtListnew = AwtList
  npar2 = 0
  for (ivar in 1:nvar) {
    for (jvar in 1:nvar) {
      BwtListij = BwtList[[ivar,jvar]]
      if (!is.null(BwtListij)) {
        nderivij = length(BwtListij)
        for (k in 1:nderivij) {
          fdPark = BwtListij[[k]]
          if (!is.null(fdPark)) {
            if (fdPark$estimate) {
              nthetak   = fdPark$fd$basis$nbasis
              npar1     = npar2 + 1
              npar2     = npar2 + nthetak
              thetaveck = thetavec(npar1:npar2)
              BwtListnew[[ivar,jvar]][[k]]$coef = thetaveck
            }
          }
        }            
      }
    }
  }
  if (!is.null(AwtList) && !is.null(AwtList[[ivar]])) {
    nforcei = length(AwtList[[ivar]])
    for (jforce in 1:nforcei) {
      AfdParj = AwtList[[ivar]][[jforce]]
      if (!is.null(AfdParj)) {
        if (AfdParj$estimate) {
          nthetaj   = AfdParj$fd$basis$nbasis
          npar1     = npar2 + 1
          npar2     = npar2 + nthetaj
          thetavecj = thetavec[npar1:npar2]
          AwtListnew[[ivar]][[jforce]]$coef = thetavecj
        }
      }
    }
  }
  return(list(BwtListnew=BwtList, AwtListnew=AwtList)) 
}

#  ------------------------------------------------------------------------

AwtListCheck <- function(AwtList,nvar) {
  #    Check AwtList and extract vector of numbers of forcing functions
  
  # Last modified 17 June 2015
  
  errwrd = 0
  
  if (!is.null(AwtList) && !is.list(AwtList)) stop('AWTLIST is not a list array.')
  
  nforce = matrix(0,nvar,1)
  for (ivar in 1:nvar) {
    if (!is.null(AwtList[[ivar]])) {
      AwtListi = AwtList[[ivar]]
      if (!is.list(AwtListi)) {
        warning(paste('AWTLIST[[', ivar,  ']] is not a list array.'))
        errwrd = 1
      }
      if (!errwrd) nforce[ivar] = length(AwtListi)
    }
  }
  
  #  if (stops encountered, terminate
  
  if (errwrd) stop('One or more terminal stops in AWTLIST encountered.')
  
  return(nforce)
}

#  ------------------------------------------------------------------------

BwtListCheck <- function(BwtList) {
  # BwtListCheck checks the structure of BwtList
  
  #  Last modified 17 June 2015
  
  nvar = dim(BwtList)[1]
  
  if (dim(BwtList)[2] != nvar) stop('BwtList is not a square list array')
  
  #  Check that each element in BwtList is itself a list array, and also that
  #  the list arrays in each column of BwtList are of the same length
  
  nderivmat = matrix(0,nvar,nvar)
  errwrd = 0
  if (nvar > 1) {
    for (ivar in 1:nvar) {
      BwtListi = BwtList[[1,ivar]]
      if (is.list(BwtListi)) {
        orderi = length(BwtListi)
        nderivmat(1,ivar) = orderi
        for (jvar in 2:nvar) {
          BwtListij = BwtList[[jvar,ivar]]
          if (is.list(BwtListij)) {
            orderj = length(BwtListij)
            nderivmat[jvar,ivar] = orderj
            if (orderj != orderi) {
              warning(paste('List arrays in column ', ivar, 
                            ' of BwtList are not all of same length.'))
              errwrd = 1
            }
          }
        }
      } else {
        warning(paste('BwtList[[',c(1,ivar), ']] is not a list array.'))
        errwrd = 1
      }
    }
  } else {
    BwtList1 = BwtList[[1]]
    if (!is.list(BwtList1)) {
      warning(paste('BwtList[[',2, ']] is not a list array.'))
      errwrd = 1
    } else {
      nderivmat[1,1] = length(BwtList1)
    }
  }
  #  if (stops encountered, terminate
  if (errwrd) {stop('One or more terminal stops in BWTLIST encountered.')
    nderivvec = diag(nderivmat)
  }
  return(nderivvec)
}
  
#  ------------------------------------------------------------------------

yListcheck <- function(yList, nvar) {
  
  if (!is.list(yList)) stop('YLIST is not a list array.')
  
  errwrd = 0
  
  nvec    = matrix(0,nvar,1)
  dataWrd = matrix(0,nvar,1)
  ydim    = matrix(0,nvar,1)
  nobs    = 0
  for (ivar in 1:nvar) {
    if (!is.null(yList[[ivar]])) {
      dataWrd[ivar] = 1
      yStructi = yList[[ivar]]
      if (!isstruct(yStructi)) {
        warning(paste('YLIST[[',ivar,']] is not a struct object.'))
        errwrd = 1
      }
      if (!isfield(yStructi,'argvals')) {
        warning(paste('argvals is not a field for YLIST[[',ivar,']].'))
        errwrd = 1
      }
      ni = length(yStructi.argvals)
      nvec[ivar] = ni
      if (!isfield(yStructi,'y')) {
        warning(paste('y is not a field for YLIST[[',ivar,']].'))
        errwrd = 1
      }
      ydimi = dim(yStructi.y)
      if (length(ydimi) > 2) {
        warning(paste('More than two dimensions for y in YLIST[[', 
                      ivar,']].'))
        errwrd = 1
      } else {
        ydim[ivar] = ydimi[2]
      }
      #  set up and check NREP
      if (ivar == 1) {
        nrep = ydimi[2]
      } else {
        if (nrepi != nrep) {
          nrepi = ydimi[2]
          warning('Second dimensions of YStruct.y are not equal.')
          errwrd = 1
        }
      }
      nobs = nobs + 1
      if (ni != ydimi[2]) {
        warning('Length of ARGVALS and first dimension of Y are not equal.')
        errwrd = 1
      }
    } else {
      dataWrd[ivar] = 0
    }
  }
  
  if (nobs == 0) {
    warning('No variables have observations.')
    errwrd = 1
  }
  
  if (errwrd) {
    stop('One or more terminal stop encountered in YLIST.')
  }
  
  return(list(nrep=nrep, nvec=nvec, dataWrd=dataWrd))
  
}