#  test tensor functions

setwd('/Users/michellecarey/Documents/Jim_GitHub/Convert_Matlab_2R')
dyn.load("loop.so")

#  define two constant bases and two bspline bases with 5 basis functions

rng = c(0,1)

library("fda")
basis1 = create.constant.basis(rng)
basis2 = create.bspline.basis(rng,5)
basis3 = basis2
basis4 = basis1

bmat1 = eval.basis(rng, basis1)
bmat2 = eval.basis(rng, basis2)
bmat3 = eval.basis(rng, basis3)
bmat4 = eval.basis(rng, basis4)

#  compute tensor with default value for wvec.  
#  should be an array with dimensions 1, 5, 5, and 1

wvec = rep(1,basis1$nbasis*basis2$nbasis*basis3$nbasis*basis4$nbasis);

source("InnerLoop.R")
tensor1 = InnerLoop(bmat1, bmat2, bmat3, bmat4, wvec)

#  Compute tensor with constant value for wvec.
#  I'm a bit concerned about argument wvec ... in Mat's code it seems to be
#  a scalar, as here, and not indexed.  If it is a vector, it would have to be
#  big enough for all forseeable index values, and it doesn't look like this 
#  would happen.

