BAtensorfn <- function(XbasisList, modelList, coefList) {
  #  Set up BATENSORCELL of size NVAR by NVAR defining products of   
  #  derivative terms and forcing terms in LX.
  #  Each cell BATENSORCELL{i.1,i.2} contains a cell array of dimensions
  #        NFORCE.{j.1} and NDERIVVEC.{l} + 1.
  #  Each cell BATENSORCELL{i.1,i.2}{j.1,l.2} contains the inner product 
  #  X basis functions for variable i.2,
  #  variable weight basis functions for variable i.2, 
  #  basis functions for forcing function j.1 and variable i.1
  #  forcing weight basis for forcing function j.1 and variable i.1.
  #  This version assumes that all forcing functions U have the same basis.
  
  #  Last modified 19 November 2015
  
  rng     = XbasisList[[1]]$rangeval
  Wbasism = create.constant.basis(rng)
  
  #  set up the structure of BAtensorList
  
  nvar = length(modelList)
  BAtensorList = vector("list", nvar)
  for (ivar in 1:nvar) {
    modelListi = modelList[[ivar]]
    nallXterm  = modelListi$nallXterm
    nallFterm  = modelListi$nallFterm
    Xbasisi    = XbasisList[[ivar]]
    Xtypei     = Xbasisi$type
    nXbasisi   = Xbasisi$nbasis
    if (nallFterm > 0) {
      nX = nallXterm + 1
      BAtensorList[[ivar]] = vector("list", nX)
      for (jorder in 1:nX) {
        BAtensorList[[ivar]][[jorder]] = vector("list",nallFterm)
      }
      order = modelListi$order
      for (jforce in 1:nallFterm) {
        modelListij = modelListi$FList[[jforce]]
        ncoefj    = modelListij$ncoef
        coefListj = coefList[[ncoefj]]
        AfdParj   = coefListj$fdPar
        Abasisj   = AfdParj$fd$basis
        Atypej    = Abasisj$type
        Ubasisj   = modelListij$Ufd$basis
        Utypej    = Ubasisj$type
        nUbasisj  = Ubasis$nbasis
        if (Atypej == "const" && Utypej == "bspline" && Xtypei == "bspline") {
          print(c(jforce,order))
          print(Xbasisi)
          print(Ubasisj)
          XWXWmatij = inprod(Xbasisi, Ubasisj, order, 0)
          XWXWmatij = matrix(t(XWXWmatij), nXbasisi*nUbasisj, 1)
        } else {
          XWXWmatij = inprod.TPbasis3(Xbasisi, Wbasism, Ubasisj, Abasisj, 
                                      order, 0, 0, 0)
        }
        BAtensorList[[ivar]][[nX]][[jforce]] = XWXWmatij                
        for (iw in 1:nallXterm) {
          modelListiw = modelListi$XList[[iw]]
          ncoefw      = modelListiw$ncoef
          coefListw   = coefList[[ncoefw]]
          WfdParw     = coefListw$fdPar
          Wbasisw    = WfdParw$fd$basis
          derivative = modelListiw$derivative
          Xbasisw    = XbasisList[[modelListiw$variable]]
          Wtypew     = WfdParw$fd$basis$type
          Xtypew     = Xbasisw$type
          nXbasisw   = Xbasisw$nbasis
          if (Wtypew == "const"   &&Atypej  == "const" &&
              Xtypew == "bspline" && Utypej == "bspline") {
            XWXWmatwj = inprod(Xbasisw, Ubasisj, derivative, 0)
            XWXWmatwj = matrix(t(XWXWmatwj), nXbasisw*nUbasisj, 1)
          } else {
            XWXWmatwj  = inprod.TPbasis3(Xbasisw, Wbasisw, 
                                         Ubasisj, Abasisj, derivative, 0, 0, 0)
          }
          BAtensorList[[ivar]][[iw]][[jforce]] = XWXWmatwj
        }
      }
    }
  }
  
  return(BAtensorList)
  
}
