Data2LD.Opt <- function(yList, XbasisList, modelList, coefList, rhoMat, 
                     conv = 1e-6, iterlim = 20, dbglev = 1, parMap = diag(rep(1,npar)), 
                     wtvec = rep(1,nvar), load.tensor = FALSE) {
  
  #  Data2LD.OPT optimizes a parameter vector theta defining a 
  #    linear differential operator object used to smooth a set of data.
  #
  #  Arguments:
  #  YCELL     an array containing values of curves
  #               If the array is a matrix, rows must correspond to argument
  #               values and columns to replications, and it will be assumed
  #               that there is only one variable per observation.
  #               If Y is a three-dimensional array, the first dimension
  #               corresponds to argument values, the second to replications,
  #               and the third to variables within replications.
  #               If Y is a vector, only one replicate and variable are 
  #               assumed.
  #  BASISCELL  A functional data object or a BASIS object.  If so, the 
  #               smoothing parameter LAMBDA is set to 0.
  #  MODELCELL  A cell aray of length NVAR. Each cell contains a 
  #                struct object with members:              
  #                Xcell  cell array of length number of homogeneous terms
  #                          Each cell contains a struct object with members:
  #                          WfdPar  a fdPar object for the coefficient
  #                          variable    the index of the variable
  #                          derivative  the order of its derivative
  #                          npar  if coefficient estimated, its location
  #                                   in the composite vector 
  #                Fcell  cell arrau of length number of forcing terms
  #                          Each cell contains a struct object with members:
  #                          AfdPar  an fdPar object for the coefficient
  #                          Ufd     an fd object for the forcing function
  #                          npar  if coefficient estimated, its location
  #                                   in the composite vector 
  #                order      the highest order of derivative
  #                name       a  tag for the variable
  #                nallXterm  the number of homogeneous terms
  #                nallFterm  the number of forcing functions
  #  COEFCELL  ... A cell array of length NCOEF.  Each cell contaions:
  #                fdPar ... an fdPar object that defines a coefficient 
  #                          function \beta(t) or \alpha(t) that multiplies a 
  #                          variable derivative value or a forcing function,
  #                          respectively, and also whether the coefficient
  #                          is to be estimated or held fixed.  Note that
  #                          a specified coefficient function may appear in
  #                          more than one place in a system of differential
  #                          equations, and can multiply either a variable
  #                          derivative value or a forcing function 
  #                          simultaneously.  However, the same function
  #                          cannot be fixed in place and estimated in
  #                          another.
  #                index ... a vector of integers inciding the position(s) in
  #                          the composite parameter vector \theta
  #                          occupied by the coefficients of the functional
  #                          data object (fd object) in the fdPar field.
  #  RHOMAT      A value in [0,1].  The data are weighted by P and the
  #               roughness penalty by 1-P.
  #  CONV      One convergence criterion, or a vector of two criteria.
  #               The first criterion is applied to the function change,
  #               and the second is applied to the gradient norm.
  #  ITERLIM   Maximum number of iterations allowed.
  #  DBGLEV    An integer controlling amount of output per iteration.
  #               Defaults to 1, which prints summary results for 
  #               each iteration.
  #  PARMAP    A rectangular matrix with number of rows equal to the
  #               number of parameters to be estimated as defined in
  #               BWTCELL, and number of columns equal to the number of 
  #               parameters less the number of linear constraints on the
  #               estimated parameters.  The columns of PARMAP must be
  #               orthnormal so that t(PARMAP) %*% PARMAP is an identity matrix.
  #               t(PARMAP) %*% THETA maps unconstrained parameters and the 
  #               corresponding gradient into   constrained parameter space.
  #               PARMAP %*% THETA  maps constrained parameters and the 
  #               corresponding gradient into unconstrained parameter space.
  #               PARMAP will usually be set up using the full QR 
  #               decomposition of a linear constraint coefficient matrix t(A)
  #               where the constraints are of the form A P = B, A and B 
  #               being known matrices.  An example of such a constraint
  #               that arises often is one where two estimated coefficients
  #               are constrained to be equal.  For example, if a vvariable 
  #               X involved in an equation the form a(x - x.0), where x.0
  #               is a fixed set point or defined target level for variable 
  #               X, then this would be set up as a.1 x + a.2 x.0, where
  #               coefficients a.1 and a.2 are constrained to be equal in
  #               magnitude but opposite in sign, or a.1 + a.2 = 0.  
  #  LOAD.TENSOR  If nonzero, attempt to load the cell arrays
  #                BtensorList, BAtensorList and AtensorList.  These must
  #                have set up before any call to Data2LD and saves as 
  #                .mat files with names BtensorList.mat, BAtensorList.mat
  #                and AtensorList.mat.  
  #                For information on how these are set up, see the functions 
  #                Btensorfn, BAtensorfn and Atensorfn.
  
  #  Returns:
  #  THETA.OPT    The optimal parameter values.
  #  BWTCELL.OPT  The corresponding optimal coefficients for the 
  #                  homogeneous terms in the differential equation
  #  AWTCELL.OPT  The corresponding optimal coefficients for the 
  #                  forcing terms in the differential equation
  
  #  Last modified 14 December 2016 by Jim Ramsay
  
  theta  = BAwtlist2vec(modelList, coefList)
  ntheta = length(theta)
  npar   = length(theta)
  
  nvar = length(yList)
  
  thetaCon = t(parMap) %*% theta  
  
  nparCon = length(thetaCon)
  climit = -2*matrix(1,2,nparCon)
  climit[2,] = -climit[2,]
  active  = 1:nparCon
  
  #  check rhoMat and get nopt
  
  rhodim = dim(as.matrix(rhoMat))
  nopt = rhodim[2]
  
  if (rhodim[1] != nvar) {
    stop(paste("The first dimension of RHOMAT is not equal to", 
               "the number of variables"))
  }
  
  #   Lists to contain results if more than a single set of rho's are involved
  
  thetastore = matrix(0,ntheta,nopt)
  dfstore    = matrix(0,nopt,1)
  gcvstore   = matrix(0,nopt,1)
  coefList.optList = vector("list", nopt)
  
  coefList.opti = coefList
  
  #  ------------------------------------------------------------------------
  #                  loop through rho vectors
  #  ------------------------------------------------------------------------
  
  for (iopt in 1:nopt) {
    
    rhoVeci = as.matrix(rhoMat)[,iopt]
    
    if (nopt > 1) {
      print(paste("Rho = ",t(rhoVeci)))
    }
    
    #  compute initial criterion value, gradient and hessian
    
    Data2LDList = Data2LD(yList, XbasisList, modelList, coefList.opti, rhoVeci,
                    wtvec, load.tensor)
    
    fvec    = Data2LDList$MSE
    grad    = Data2LDList$DpMSE
    gradCon = t(parMap) %*% grad
    
    fvecsum = sum(fvec)
    
    norm = sqrt(mean(gradCon^2))
    
    #  evaluate the initial update vector for correcting the initial theta
    
    deltac = -gradCon
    
    #  initialize iteration status arrays
    
    iternum = 0
    status = c(iternum, fvec, norm)
    if (dbglev >= 1) {
      cat("\nIter.   PENSSE\n")
      cat(iternum)
      cat("        ")
      cat(round(status[2],4))
      cat("      ")
      cat(round(status[3],4))
    } else {
      cat(".")
    }
    iterhist = matrix(0,iterlim+1,length(status))
    iterhist[1,]  = status
    if (iterlim == 0) { 
      return () 
    }
    
    #  -------  Begin main iterations  -----------
    
    MAXSTEPITER = 10
    MAXSTEP     = 5
    trial       = 1.0
    reset       = 0
    linemat     = matrix(0,3,5)
    thetaoldCon = thetaCon
    fvecsumold        = fvecsum
    gradoldCon  = gradCon
    dbgwrd      = dbglev >= 2
    if (length(conv) > 1) {
      slopecrit = conv[2]  
    } else {
      slopecrit = 1e-7
    }
    
    #  ---------------  beginning of optimization loop  -----------
    
    for (iter in 1:iterlim) {
      iternum = iternum + 1
      #  set logical parameters
      dblwrd <- c(FALSE,FALSE)
      limwrd <- c(FALSE,FALSE) 
      stpwrd <- FALSE
      ind    <- 0
      ips    <- 0
      #  compute slope
      linemat[2,1] = sum(deltac*gradoldCon)
      #  normalize search direction vector
      sdg          = sqrt(sum(deltac^2))
      deltac       = deltac/sdg
      linemat[2,1] = linemat[2,1]/sdg
      # initialize line search vectors
      linemat[,1:4] = matrix(c(0, linemat[2,1], fvecsum),3,1) %*% matrix(1,1,4)
      stepiter  = 0
      if (dbglev >= 2) {
        cat("\n")
        cat(paste("                 ", stepiter, "  "))
        cat(format(round(t(linemat[,1]),6)))
      }
      #  return with error condition if initial slope is nonnegative
      if (linemat[2,1] >= -slopecrit) {
        if (dbglev >= 2) { 
          print("Initial slope nonnegative.") 
          break
        }
      }
      #  return successfully if initial slope is very small
      if (linemat[2,1] >= -min(c(1e-3,conv))) {
        if (dbglev >= 2) { 
          print("Initial slope too small") 
          status = c(iternum, fvecsum, norm)
        }
        if (dbglev >= 1) {
          cat(format(round(status,4)))
          cat("\n")
        }
        coefListnew = coefList
        break
      }
      #  first step set to trial
      linemat[1,5] = trial
      #  ------------  begin line search iteration loop  ----------
      thetanewCon = thetaCon
      for (stepiter in 1:MAXSTEPITER) {
        #  check the step size and modify if limits exceeded
        result <- stepchk(linemat[1,5], thetaCon, deltac, limwrd, ind, 
                          climit, active, dbgwrd)
        linemat[1,5] <- result$step
        ind          <- result$ind
        limwrd       <- result$limwrd
        # break if limit hit twice in a row
        if (ind == 1) { 
          thetanew   = theta
          fvecsumnew = fvecsum
          gradnew    = grad
          gradnewCon = t(parMap) %*% gradnew
          break 
        } 
        #  break if current step size too small
        if (linemat[1,5] <= 1e-7) {
          if (dbglev >= 2) {
            cat("\nStepsize too small:  ")
            cat(linemat[1,5])
            cat("\n")
          }
          thetanew   = theta
          fvecsumnew = fvecsum
          gradnew    = grad
          gradnewCon = t(parMap) %*% gradnew
          break
        }
        #  update parameter vector
#         print(paste("linemat[1,5] =",linemat[1,5]))
#         print(t(deltac))
        thetanewCon = thetaCon + linemat[1,5]*deltac
        #  ---------  update function, gradient and hessian  -----------
        thetanew = parMap %*% thetanewCon
#         print(t(thetanew))
        coefListnew = BAwtvec2list(thetanew, coefList)
#         ncoef = length(coefListnew)
#         for (icoef in 1:ncoef) {
#           print(coefListnew[[icoef]]$fdPar$fd$coef)
#         }
        Data2LDList    = Data2LD(yList, XbasisList, modelList, coefListnew, 
                           rhoVeci, wtvec, load.tensor)
        fvecnew     = Data2LDList$MSE
        gradnew     = Data2LDList$DpMSE
        hessmatnew  = Data2LDList$D2ppMSE
        gradnewCon  = t(parMap) %*% gradnew
        fvecsumnew  = sum(fvecnew)
        #  -------------------------------------------------------------
        linemat[3,5] = fvecsumnew
        #  compute new directional derivative
        linemat[2,5] = sum(deltac*gradnewCon)
        if (dbglev >= 2) {
          cat("\n")
          cat(paste("                 ", stepiter, "  "))
          cat(format(round(t(linemat[,5]),6)))
        }
        #  compute next line search step, also testing for convergence
        result  <- stepit(linemat, ips, dblwrd, MAXSTEP)
        linemat <- result[[1]]
        ips     <- result[[2]]
        ind     <- result[[3]]
        dblwrd  <- result[[4]]
        trial  = linemat[1,5]
        #  ind == 0 implies convergence
        if (ind == 0 || ind == 5) { 
          break 
        }
      }
      #  ------------  end line search iteration loop  ----------
      thetaCon = thetanewCon
      theta    = thetanew
      fvecsum  = fvecsumnew
      gradCon  = gradnewCon
      #  test for function value made worse
      if (fvecsum > fvecsumold) {
        #  Function value worse  warn and terminate
        if (dbglev >= 2) {
          cat("Criterion increased: ")
          cat(format(round(c(fvecsumold, fvecsum),4)))
          cat("\n")
        }
        #  reset parameters and fit
        thetaCon = thetaoldCon
        fvecsum  = fvecsumold
        deltac   = gradCon
        if (dbglev > 2) {
          for (i in 1:nbasis) cat(round(theta[i],4))
          cat("\n")
        }
        if (reset == 1) {
          #  This is the second time in a row that this
          #     has happened   quit
          if (dbglev >= 2) { 
            cat("Reset twice, terminating.\n")
            cat("Convergence not attained.\n")
          }
          #  return current status of optimization
          break
        } else {
          reset = 1
        }
      } else {
        #  function value has not increased,  check for convergence
        RMSgrad = sqrt(mean(gradCon^2))
        if (length(conv) > 1) {
          convtest = fvecsumold - fvecsum < conv[1] && RMSgrad < conv[2]
        } else {
          convtest = fvecsumold - fvecsum < conv
        }
        if (convtest) {
          norm   = sqrt(mean(gradCon^2))
          status = c(iternum, fvecsum, norm)
          if (dbglev >= 1) {
            cat("\n")
            cat(iternum)
            cat("        ")
            cat(round(status[2],4))
            cat("      ")
            cat(round(status[3],4))
          }
          #  return current status of optimization
          break
        }
        #  update old parameter vectors and fit structure
        thetaoldCon = thetaCon
        fvecsumold  = fvecsum
        gradoldCon  = gradCon
        hessmatCon  = t(parMap) %*% hessmatnew %*% parMap
        #  update the line search direction vector
        deltac      = -solve(hessmatCon,gradCon)
        reset       = 0
      }
      norm   = sqrt(mean(gradCon^2))
      status = c(iternum, fvecsum, norm)
      iterhist[iter+1,] = status
      if (dbglev >= 1) {
        cat("\n")
        cat(iternum)
        cat("        ")
        cat(round(status[2],4))
        cat("      ")
        cat(round(status[3],4))
      }
      if (dbglev >= 1 && iter == iterlim) {
        cat(
          "\nMaximum iterations reached but convergence not attained.\n")
      }
    }
  
    #  ---------------  end of optimization loop  -----------
  
    Data2LDList    = Data2LD(yList, XbasisList, modelList, coefListnew, 
                       rhoVeci, wtvec, load.tensor)
    fvecnew     = Data2LDList$MSE
    gradnew     = Data2LDList$DpMSE
    hessmatnew  = Data2LDList$D2ppMSE
    XfdParListi = Data2LDList$XfdParList
    dfi         = Data2LDList$df
    gcvi        = Data2LDList$gcv
  
    #  return current status of optimization
  
    theta.opt    = theta
    coefList.opt = coefList

  }
  
  return(list(theta.opt=theta.opt, coefList.opt=coefList.opt))
  
}

