
setwd("~/Documents/R/Data2LD")

library("fda")

###  A toy example:  
#  Dx(t) <- -beta x(t) + alpha u(t) where x(0) <- 0, and 
#  u(t) <- 0 over [0,1] and 1 over [1,5]

rm(list=ls())  #  A good idea when debugging

#  load required packages

library("fda")
library("R.cache")

#  identify C code

dyn.load("loop.so")

#  source functions not in the fda package

source("coefcheck.R")
source("modelcheck.R")
source("yListcheck.R")
source("stepchk.R")
source("stepit.R")
source("BAwtlist2vec.R")
source("BAwtvec2list.R")
source("Data2LD.R")
source("Data2LD.R.R")
source("Data2LD.S.R")
source("Data2LD.ISE.R")
source("Data2LD.Opt.R")
source("BAwtvec2list.R")
source("BAwtlist2vec.R")

#  set true parameter values

beta0  <- 1
alpha0 <- 1

#  Set range of t and sampling points

rng  <- c(0,5)
N    <- 26
tvec <- matrix(seq(0,5,len=N),N,1)

#  Set up errorless value of function x(t)

xvec0 <- matrix(0,N,1)
xvec0[tvec >= 1] <- (alpha0/beta0)*(1 - exp(-beta0*(tvec[tvec>=1]-1)))

# plot the errorless data

plot(tvec, xvec0, type="l")

## set up the data shared with Matlab in a list object with named members "argvals" and "y"
yList1 = vector("list",1)
yList1$argvals = tvec;

yList1$y = c(
  -0.0280, 
  0.1514, 
  0.0040, 
  -0.0762, 
  0.0507, 
  0.0343, 
  0.1434, 
  0.3328, 
  0.3797, 
  0.5799, 
  0.7041, 
  0.6348, 
  0.5698, 
  0.8254, 
  0.6581, 
  0.8816, 
  0.8100, 
  0.9226, 
  0.9229, 
  0.9067, 
  1.0955, 
  0.8385, 
  0.9584, 
  0.8003, 
  1.2128, 
  0.9764)

##  Define the List array containing the data

yList <- vector("list",1)
yList[[1]] <- yList1

##  Set up spline basis of order 4 with three knots at 1 to
#  allow estimated Dx(t) to be discontinuous at 1 
#  but x(t) to be continuos

Xknots  <- c(0,1,1,1,2,3,4,5)
Xnbasis <- 10
Xnorder <- 4
Xbasis  <- create.bspline.basis(rng, Xnbasis, Xnorder, Xknots)

plot(Xbasis)

#  Plot a trial function using this basis.  These coefficients are not
#  what will be estimated later.

Xcoef <- matrix(0,Xnbasis,1)
Xcoef[5:Xnbasis,] <- 1
Xfd <- fd(Xcoef, Xbasis)

plot(Xfd)

#  Set up List array basisList

XbasisList    <- vector("list",1)
XbasisList[[1]] <- Xbasis

##  Set up the forcing function u(t) 
#   Here a step function that steps from 0 to 1 at time 1$

Uknots  <- c(0,1,5)
Unbasis <- 2
Unorder <- 1
Ubasis  <- create.bspline.basis(rng, Unbasis, Unorder, Uknots)

plot(Ubasis)

prodval = inprod(Ubasis, Ubasis, 0, 0)

Ucoef <- matrix(c(0,1),2,1)
Ufd   <- fd(Ucoef, Ubasis)

plot(Ufd)

##  Define the coefficient List array 
#  Both alpha and beta coefficient functions will be constant$

conbasis <- create.constant.basis(rng)

#  Set up the fdPar object for beta

betafd    <- fd(-1,conbasis)
Lfdobj    <- 0
lambda    <- 0
estimate  <- TRUE
betafdPar <- fdPar(betafd, Lfdobj, lambda, estimate)

#  Set up the fdPar object for alpha

alphafd    <- fd(1,conbasis)
Lfdobj     <- 0
lambda     <- 0
estimate   <- TRUE
alphafdPar <- fdPar(alphafd, Lfdobj, lambda, estimate)

coefList1 = list(fun =  betafdPar, parvec = 1, estimate = TRUE, coeftype = "beta")
coefList2 = list(fun = alphafdPar, parvec = 1, estimate = TRUE, coeftype = "alpha")

coefList <- vector("list",2)
coefList[[1]] <- coefList1
coefList[[2]] <- coefList2

#  Run a check on the coefficient List array

coefcheckList <- coefcheck(coefList)
coefList <- coefcheckList$coefList 
ntheta   <- coefcheckList$ntheta

print(paste('ntheta = ',ntheta))

##  Set up the model List array

#  The List object in List array Xlist

XtermList = list(ncoef = 1, derivative = 0, variable = 1, estimate = 1)

XList <- vector("list",1)
XList[[1]] <- XtermList

#  The List object in List array Flist

FtermList <- list(ncoef = 2, Ufd = Ufd, estimate = 1)

FList <- vector("list",1)
FList[[1]] <- FtermList

#  Set up the List object to be loaded into the model List array
#  each field contains a List array containing a List object

modelList1 <- list(XList = XList, FList = FList, name = "x", 
                   order = 1, index = 1:2, nallXterm = 1, nallFterm = 1)

#  Set up the model List array

modelList    <- vector("list",1)
modelList[[1]] <- modelList1

#  Run a check on modelList

modelList <- modelcheck(modelList, coefList)

##  Set up the cell arrays containing the four-way tensor products

source("Btensorfn.R")
source("BAtensorfn.R")
source("Atensorfn.R")

BtensorList  = Btensorfn( XbasisList, modelList, coefList)
BAtensorList = BAtensorfn(XbasisList, modelList, coefList)
AtensorList  = Atensorfn(             modelList, coefList)

##  Evaluate the objective function using function Data2LD

#  Set the value of \rho to a value that is 
#  greater or equal to 0 and less than 1

rhoVec <- 0.5  #  moderate smoothing

#  Remove a previously cached file if any aspect of the analysis has
#  been altered

#  file.remove(findCache(key=list("Data2LDcacheKey")))

Data2LDList <- Data2LD(yList, XbasisList, modelList, coefList, rhoVec)
      
MSE     = Data2LDList$MSE 
DpMSE   = Data2LDList$DpMSE
D2ppMSE = Data2LDList$D2ppMSE
df      = Data2LDList$df
gcv     = Data2LDList$gcv
ISE     = Data2LDList$ISE

#  display the results

print(MSE)
print(DpMSE)
print(D2ppMSE)
print(df)
print(gcv)
print(ISE)

#  Plot the current solution along with the data

XfdParList = Data2LDList$XfdParList

Xfdhat <- XfdParList[[1]]$fd

plotfit.fd(xvec0, tvec, Xfdhat)

cvechat <- Xfdhat$coef

print("coefficients defining x(t):")
print(cvechat)

##  Now add some noise to the true values of x(t)

##  Optimize the fit to the data using light smoothing

#  set optimization parameters

conv    = 1e-6
iterlim = 20
dbglev  = 2

OptList <- Data2LD.Opt(yList, XbasisList, modelList, coefList, rhoVec, conv, iterlim, dbglev)

theta.opt = OptList$theta.opt

print("Estimated theta:")
print(round(theta.opt,4))

##  Evaluate the fit

#  load the estimated parameter values into coefList

coefList.opt <- BAwtvec2list(theta.opt, coefList)

Data2LDList <- Data2LD(yList, XbasisList, modelList, coefList.opt, rhoVec)

MSE  = Data2LDList$MSE 
DMSE = Data2LDList$DpMSE

XfdParList = Data2LDList$XfdParList

#  print the initial error sum of squares and gradient

print(paste('SSE <- ',MSE))

print(paste('DSSE <- ',t(DMSE)))

#  Plot the current solution along with the data

Xfdhat <- XfdParList[[1]]$fd
yvec = yList[[1]]$y

plotfit.fd(yvec, tvec, Xfdhat)

rhoVec <- 0.999  

coefList0 = coefList.opt

OptList <- Data2LD.Opt(yList, XbasisList, modelList, coefList0, rhoVec, conv, iterlim, dbglev)

#  load the estimated parameter values into coefList

coefList.opt <- BAwtvec2list(theta.opt, coefList)

Data2LDList <- Data2LD(yList, XbasisList, modelList, coefList.opt, rhoVec)

MSE  = Data2LDList$MSE 
DMSE = Data2LDList$DpMSE

XfdParList = Data2LDList$XfdParList

#  print the initial error sum of squares and gradient

print(paste('SSE <- ',MSE))

print(paste('DSSE <- ',t(DMSE)))

#  Plot the current solution along with the data

Xfdhat <- XfdParList[[1]]$fd
yvec = yList[[1]]$y

plotfit.fd(yvec, tvec, Xfdhat)

