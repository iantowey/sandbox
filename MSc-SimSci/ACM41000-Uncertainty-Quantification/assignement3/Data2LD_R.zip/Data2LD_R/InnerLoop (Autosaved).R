InnerLoop <- function( in1, in2, in3, in4, wvec=1){
#InnerLoop Summary of this function goes here
#   Detailed explanation goes here
# Need to dyn.load("loop.so")

output_args = .Call("loop", in1, in2, in3, in4, wvec);

return(output_args)
}
 
