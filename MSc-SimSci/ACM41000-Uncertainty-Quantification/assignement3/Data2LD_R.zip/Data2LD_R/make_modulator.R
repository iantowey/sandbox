make.modulator <- function(funobj, parvec, estimate=1, name="beta") {
if (!is.function(funobj) && 
    !isa.basis(funobj)   && 
    !isa.fd(funobj)      && 
    !isa.fdPar(funobj))
    stop(paste("FUNOBJ is not a function handle, basis, fd object or ",
          "a basis object."))
modList$fun      -> funobj
modList$parvec   -> parvec
modList$estimate -> estimate
modList$name     -> name

return(modList = modList)

}