inprodwx <- function(nbasisv, nWbasisv, nbasisx, nWbasisx, 
                     Bvecv, Bvecx, Btensvx) {
  Rmatvx = matrix(0,nbasisv,nbasisx)
  ncum   = cumprod(c(nWbasisx, nbasisx, nWbasisv, nbasisv))
  for (i in 1:nbasisv) {
    for (k in 1:nbasisx) {
      Rmatvx[i,k] = 0
      for (j in 1:nWbasisv) {
        for (l in 1:nWbasisx) {
          ijkl = (i-1)*ncum[3] + 
            (j-1)*ncum[2] + 
            (k-1)*ncum[1] + l
          Rmatvx[i,k] = Rmatvx[i,k] + 
            Btensvx[ijkl]*Bvecv[j]*Bvecx[l]
        }
      }
    }
  }
  
  return(Rmatvx)
  
}
