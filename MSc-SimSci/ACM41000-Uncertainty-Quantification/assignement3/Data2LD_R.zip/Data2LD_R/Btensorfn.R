Btensorfn <- function(XbasisList, modelList, coefList) {
  #  Set up BTENSORList defining homogeneous part of LX  
  #  This is a List array of length NVAR
  #    Each List BTENSORList[[i1]] contains a square List array of order 
  #      NALLXTERM+1.
  #      Each List BTENSORList[[i1}[[j1]][[j2]] contains the tensor product
  #      of the coefficient basis functions for basis i in term j1, 
  #         the derivative order j of the X basis functions in term j1,
  #         the derivative order j of the X basis functions in term j2,
  #         the coefficient basis functions for basis i in term j2,
  #         j1, j2 = 1,...,NALLXTERM+1 where
  #         j1, j2 = NALLXTERM+1 is for the mth derivative of the X basis
  #         functions.
  
  #  Last modified 17 November 2015
  
  rng     = XbasisList[[1]]$rangeval
  Wbasism = create.constant.basis(rng)
  Wfdm    = fd(1,Wbasism)
  WfdParm = fdPar(Wfdm, 0, 0, FALSE)
  
  #  set up the structure of BtensorList
  
  nvar = length(modelList)
  BtensorList = vector("list", nvar)
  for (ivar in 1:nvar) {
    modelListi = modelList[[ivar]]
    #  set up a two-dimensiional list object within each member of BtensorList
    nX = modelListi$nallXterm+1
    BtensorListi = vector("list",nX)
    for (ivar in 1:nvar) {
      BtensorListi[[ivar]] = vector("list",nvar)
    }
    BtensorList[[ivar]] = BtensorListi
    #  loop through derivative orders from 1 to nderiv
    nderiv = nX
    for (iw in 1:nderiv) {        
      if (iw < nderiv) {
        modelListiw = modelListi$XList[[iw]]
        ncoefw      = modelListiw$ncoef
        coefListw   = coefList[[ncoefw]]
        WfdParw     = coefListw$fdPar
        Xbasisw     = XbasisList[[modelListiw$variable]]
        jw          = modelListiw$derivative
      } else {
          WfdParw = WfdParm
          Xbasisw = XbasisList[[ivar]]
          jw = modelListi$order
      }
      Wbasisw  = WfdParw$fd$basis
      Wtypew   = WfdParw$fd$basis$type
      Xtypew   = Xbasisw$type
      nXbasisw = Xbasisw$nbasis
      #  loop through derivative orders from 1 to nderiv inside outer loop
      for (ix in 1:nderiv) {
        if (ix < nderiv) {
          modelListix = modelListi$XList[[ix]]
          ncoefx    = modelListix$ncoef
          coefListx = coefList[[ncoefx]]
          WfdParx   = coefListx$fdPar
          Xbasisx   = XbasisList[[modelListix$variable]]
          jx        = modelListix$derivative
        } else {
          WfdParx = WfdParm
          Xbasisx = XbasisList[[ivar]]
          jx      = modelListi$order
        }
        Wbasisx  = WfdParx$fd$basis
        Wtypex   = WfdParx$fd$basis$type
        Xtypex   = Xbasisx$type
        nXbasisx = Xbasisx$nbasis
        if (Wtypew == "const"   && Wtypex == "const"   && 
            Xtypew == "bspline" && Xtypex == "bspline" ) {
          XWXWmatij = inprod(Xbasisw, Xbasisx, jw, jx)
          XWXWmatij = matrix(XWXWmatij, nXbasisw*nXbasisx, 1)
        } else {
        #  -----------------evaluate using inprod.TPbasis3  -----------------------
          XWXWmatij = inprod.TPbasis3(Xbasisw, Wbasisw, Xbasisx, Wbasisx, 
                                    jx, 0, jw, 0)
        }
        #  ------------------------------------------------------------------------
        BtensorList[[ivar]][[ix]][[iw]] = XWXWmatij
      }
    }
  }
  
  return(BtensorList) 
    
}
