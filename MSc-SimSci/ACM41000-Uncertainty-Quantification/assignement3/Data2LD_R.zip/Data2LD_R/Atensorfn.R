Atensorfn <- function(modelList, coefList) {
  #  Set up ATENSORCELL of length NVAR defining products of forcing terms.
  #  Each celll AtensorList[[ivar]] is a cell of size nforcei by nforcei.
  
  #  Last modified 13 December 2016
  
  nvar = length(modelList)
  AtensorList = vector("list", nvar)
  for (ivar in 1:nvar) {
    modelListi = modelList[[ivar]]
    if (modelListi$nallFterm > 0) {
      nforce = modelListi$nallFterm
      if (nforce > 0) {
        for (jv in 1:nforce) {
          modelListiv = modelListi$FList[[jv]]
          ncoefv    = modelListiv$ncoef
          coefListv = coefList[[ncoefv]]
          AfdParv   = coefListv$fun
          Ufdv      = modelListiv$Ufd
          Abasisv   = AfdParv$fd$basis
          Atypev    = Abasisv$type
          nAbasisv  = Abasisv$nbasis
          Ubasisv   = Ufdv$basis
          Utypev    = Ubasisv$type
          nUbasisv  = Ubasisv$nbasis
          for (jx in 1:nforce) {
            modelListix = modelListi$FList[[jx]]
            ncoefx    = modelListix$ncoef
            coefListx = coefList[[ncoefx]]
            AfdParx   = coefListx$fun
            Ufdx      = modelListix$Ufd
            Abasisx   = AfdParx$fd$basis
            Atypex    = Abasisx$type
            nAbasisx  = Abasisx$nbasis
            Ubasisx   = Ufdx$basis
            Utypex    = Ubasisx$type
            nUbasisx  = Ubasisx$nbasis
            if (Atypev == "const"   && Atypex == "const" &&
                Utypev == "bspline" && Utypex == "bspline") {
              XWXWmatij = inprod(Ubasisv, Ubasisx, 0, 0)
              XWXWmatij = matrix(XWXWmatij, nUbasisv*nUbasisx, 1)
            } else {
              XWXWmatij = inprod.TPbasis3(Ubasisv, Abasisv, 
                                          Ubasisx, Abasisx, 
                                          jv-1, 0, 0, 0)
            }
            if (nforce == 1) {
              AtensorList[[ivar]] = list(XWXWmatij)
            } else {
              AtensorList[[ivar]][[jx]][[jv]] = XWXWmatij
            }
          }
        }
      } else {
        AtensorList[[ivar]] = NULL
      }
      
    }
      
  }
  return(AtensorList)
  
}
    