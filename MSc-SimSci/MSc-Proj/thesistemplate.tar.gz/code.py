def g(y):
    return y*y*y
