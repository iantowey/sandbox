#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <stdlib.h>
#include <stdlib.h>
#include <stdio.h>
#include <omp.h>

typedef struct {
    long seed;
    float val;
} rand_tuple;


#endif // MAIN_H_INCLUDED
