﻿#include <assignment2.h>

void randomarray_tests();
void bubblesort_tests();
void bubblesort_input_tests();
void search_tests();
void chopsearch_tests();
void benchmark_native_test();
void benchmark_chop_test();